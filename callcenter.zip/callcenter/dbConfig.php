<?php  
    // define("DB_HOST", 'localhost');  
    // define("DB_USER", 'test2');  
    // define("DB_PASSWORD", 'test2');  
    // define("DB_DATABSE", "leykart");  
	// define("DB_HOST", '127.0.0.1');  
	
	// define("DB_HOST", '172.25.26.3');
    // define("DB_PORT", '3306');  
    // define("DB_USER", 'MagentoQA');  
    // define("DB_PASSWORD", 'Mag#17User');  
    // define("DB_DATABSE", "callcenter"); 
	
	
	define("DB_HOST", '172.25.28.7');  
    define("DB_PORT", '3306');  
    define("DB_USER", 'magentouser');  
    define("DB_PASSWORD", 'ras13aEW_f');  
    define("DB_DATABSE", "callcenter"); 
?> 