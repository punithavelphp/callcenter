<?php
      session_start();
   
   $result = $_SESSION['result'];
   
   $result_array = json_decode($result);
  // print_r($result_array);
?>
<html">
   
   <head>
      <title>Welcome </title>
   </head>
   
   <body>
      <h1>Welcome Page</h1> 
	  
      <h2><a href = "logout.php">Sign Out</a></h2>
	  
	  <div>
	  <p>First Name: <?php echo $result_array->firstname; ?></p>
	  <p>Last Name: <?php echo $result_array->lastname; ?></p>
	  <p>User Name: <?php echo $result_array->username; ?></p>
	  <p>Email: <?php echo $result_array->email; ?></p>
	  </div>
   </body>
   
</html>
