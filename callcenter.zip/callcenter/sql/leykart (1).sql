-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 14, 2017 at 08:05 AM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 7.1.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `leykart`
--

-- --------------------------------------------------------

--
-- Table structure for table `idostk_caller_type`
--

CREATE TABLE `idostk_caller_type` (
  `id` int(11) NOT NULL,
  `caller_type` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `idostk_caller_type`
--

INSERT INTO `idostk_caller_type` (`id`, `caller_type`) VALUES
(1, 'User'),
(2, 'Seller'),
(3, 'DP');

-- --------------------------------------------------------

--
-- Table structure for table `ostk_action_taken`
--

CREATE TABLE `ostk_action_taken` (
  `id` int(11) NOT NULL,
  `caller_type` varchar(20) NOT NULL,
  `issue_category` varchar(220) NOT NULL,
  `action` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ostk_action_taken`
--

INSERT INTO `ostk_action_taken` (`id`, `caller_type`, `issue_category`, `action`) VALUES
(1, '2', 'Account modification', 'Call Sales POC and inform.\nSales POC contact: <Mobile No.>'),
(2, '2', 'SAP issues', 'Call IT POC and inform. Patch the call between IT POC and Seller.\nIT POC contact: <Mobile No.>'),
(3, '2', 'Parts out of stock', '1. From the Seller, get the Order Number and(or) the individual Suborder Numbers for which the parts are out of stock.\n2.Get the estimated delivery time for Rush Order and note it down in comments.\n3.Get Customer details by inputting the Order/Suborder Number.\n4. Call Customer and check if he wants to cancel or place a VOR order.\n5a. If customer asks for rush order, call seller and ask him to place a rush order.\n5b. If customer asks for cancellation, select the Suborder Numbers which he wants to cancel.\n6. Call the Seller ,DP and inform the order cancellation requests and  that an email will be sent after authorization of cancellation requests. '),
(4, '2', 'Pickup delayed', '1. From the Seller, get the Order Number and(or) the individual Suborder Numbers. \n2. Get the AWB number by inputting the Order/Suborder Number.\n2. Call Delivery Provider POC and get estimated pickup time.\n3. Inform Seller the pickup time and also note in down in the comments section.\nDelivery Provider1 POC: <Mobile No.>\n Delivery Provider2 POC: <Mobile No.>'),
(5, '3', 'Pickup delayed', '1. From the DP,get the  Order Number and(or) the individual Suborder Numbers. \n2. Get the Seller Details by inputting the Order/Suborder Number.\n2. From the DP, Get estimated pickup time and also note in down in the comments section.\n3. Inform Seller the pickup time.'),
(6, '1', 'Delivery delayed', '1. Select Track Order button next to the particular Suborder. The shipping provider webpage will open. Input the AWB number and get current location of the package. \n2. Call Delivery Provider POC and get estimated delivery time.\n3. Inform User the delivery time. If he wants to cancel, note in the comments that a new request will be created for cancellation, close this ticket and raise a new ticket for cancellation\nDelivery Provider POC: <Mobile No.>'),
(7, '1', 'Cancel order', '1. From the User, get the Order Number and(or) the individual Suborder Numbers. \n2. Input Order/Suborder Number(s) and select the suborders that have to be cancelled. \n3. Enter the Cancellation reason for each suborder.\n4. Call the Seller ,DP and inform the order cancellation requests and  that an email will be sent after authorization of cancellation requests. \n\n '),
(8, '1', 'Replacement/Return', 'In the comments section, enter: \n1. Reason for return/replacement\n2. Suborder number(s)\n\n '),
(9, '1', 'Partial refund', 'In the comments section, enter: \n1. Reason for return/replacement\n2. Suborder number(s) and quantity to be cancelled\n\n '),
(10, '1', 'Partial replacement', 'In the comments section, enter: \n1. Reason for return/replacement\n2. Suborder number(s) and quantity to be replaced\n\n '),
(11, '1', 'Status of refunds', '1. Call payments POC to understand the reason for delay and call back user.  Payments POC: <Mobile No.>'),
(12, '1', 'Status of replacement', '1.  From the User, get the Order Number and(or) the individual Suborder Numbers.\n2. Get Seller details against the particular Suborder Number.\n2. Call Seller, get the Replacement Order Number, get the AWB number and shipping provider used for the replacement order and note down in comments.\n3. Call the User to update.'),
(13, '1', 'Dispute regarding cancellation/ return/ replacement', '1. Select the sub category for the dispute                                                                         2. Call respective POC to understand the reason for the dispute raised by the user.  <respective> POC: <Mobile No.>'),
(14, '1', 'Complaints', '1. Select the sub category for the Complaints.     \n2. Elaborate the complaint in the comments section.');

-- --------------------------------------------------------

--
-- Table structure for table `ostk_feedback_option`
--

CREATE TABLE `ostk_feedback_option` (
  `serialNo` int(5) NOT NULL,
  `feedback_question_id` int(11) NOT NULL,
  `options` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ostk_feedback_option`
--

INSERT INTO `ostk_feedback_option` (`serialNo`, `feedback_question_id`, `options`) VALUES
(1, 1, 'Satisfied'),
(2, 1, 'Good'),
(3, 1, 'Very Good'),
(4, 3, 'Yes'),
(5, 3, 'No'),
(8, 2, 'Satisfied'),
(9, 2, 'Good'),
(10, 4, '1'),
(13, 2, 'Very Good'),
(14, 5, 'Satisfied'),
(15, 5, 'Good'),
(16, 5, 'Very Good'),
(17, 6, 'Satisfied'),
(18, 6, 'Good'),
(19, 6, 'Very Good'),
(20, 7, 'Yes'),
(21, 7, 'No'),
(22, 8, '1');

-- --------------------------------------------------------

--
-- Table structure for table `ostk_feedback_question`
--

CREATE TABLE `ostk_feedback_question` (
  `serialNo` int(5) NOT NULL,
  `feedback_type` int(11) NOT NULL,
  `question_type` varchar(45) DEFAULT NULL,
  `questions` varchar(264) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ostk_feedback_question`
--

INSERT INTO `ostk_feedback_question` (`serialNo`, `feedback_type`, `question_type`, `questions`) VALUES
(1, 1, 'rating', 'Leykart App functionality and working'),
(2, 1, 'rating', 'Part Identification functionality'),
(3, 1, 'option+comment', 'Did you get what you wanted (regarding spare parts range in leykart Yes/No if any thing to be added need to be mentioned in comment box)'),
(4, 1, 'rating', 'Delivery Service Time & Condition'),
(5, 2, 'option', 'Are you satisfied with the product'),
(6, 2, 'option', 'Are you satisfied with the Services'),
(7, 2, 'option', 'Any suggestion you would like to give'),
(8, 2, 'rating', 'How much would you rate us in scale of 5');

-- --------------------------------------------------------

--
-- Table structure for table `ostk_feedback_response`
--

CREATE TABLE `ostk_feedback_response` (
  `feedback_response_id` int(11) NOT NULL,
  `submitted_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `order_number` varchar(30) DEFAULT NULL,
  `feedback_type` int(16) NOT NULL,
  `feedback_question_id` int(11) DEFAULT NULL,
  `feedback_option_id` int(11) DEFAULT NULL,
  `feedback_comment` varchar(300) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ostk_feedback_response`
--

INSERT INTO `ostk_feedback_response` (`feedback_response_id`, `submitted_time`, `order_number`, `feedback_type`, `feedback_question_id`, `feedback_option_id`, `feedback_comment`) VALUES
(9, '2017-11-20 14:31:58', '000003037', 1, 1, 4, ''),
(10, '2017-11-20 14:31:58', '000003037', 1, 2, 4, ''),
(11, '2017-11-20 14:31:58', '000003037', 1, 3, 23, 'cdcsdcsdcsdc'),
(12, '2017-11-20 14:31:58', '000003037', 1, 4, 3, ''),
(13, '2017-11-21 11:26:09', '000003073', 1, 1, 4, ''),
(14, '2017-11-21 11:26:09', '000003073', 1, 2, 4, ''),
(15, '2017-11-21 11:26:09', '000003073', 1, 4, 5, ''),
(16, '2017-11-21 11:26:09', '000003073', 1, 3, 23, 'sdasdascas');

-- --------------------------------------------------------

--
-- Table structure for table `ostk_feedback_type`
--

CREATE TABLE `ostk_feedback_type` (
  `type_id` int(11) NOT NULL,
  `feedback_type` varchar(9) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ostk_feedback_type`
--

INSERT INTO `ostk_feedback_type` (`type_id`, `feedback_type`) VALUES
(1, 'Regular'),
(2, 'Cancelled');

-- --------------------------------------------------------

--
-- Table structure for table `ostk_issue_category`
--

CREATE TABLE `ostk_issue_category` (
  `id` int(11) NOT NULL,
  `issue_category` varchar(220) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ostk_issue_category`
--

INSERT INTO `ostk_issue_category` (`id`, `issue_category`) VALUES
(1, 'Account modification'),
(2, 'SAP issues'),
(3, 'Parts out of stock'),
(4, 'Pickup delayed'),
(5, 'Delivery delayed'),
(6, 'Cancel order'),
(7, 'Replacement/Return'),
(8, 'Partial refund'),
(9, 'Partial replacement'),
(10, 'Status of refunds'),
(11, 'Status of replacement'),
(12, 'Dispute regarding cancellation/ return/ replacement'),
(13, 'Complaints');

-- --------------------------------------------------------

--
-- Table structure for table `ostk_poc_detail`
--

CREATE TABLE `ostk_poc_detail` (
  `serial_no` int(11) NOT NULL,
  `poc_category` int(11) NOT NULL,
  `seller_id` int(11) NOT NULL,
  `seller_name` varchar(25) NOT NULL,
  `poc_name` varchar(25) NOT NULL,
  `poc_contact` int(11) NOT NULL,
  `poc_email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ostk_poc_detail`
--

INSERT INTO `ostk_poc_detail` (`serial_no`, `poc_category`, `seller_id`, `seller_name`, `poc_name`, `poc_contact`, `poc_email`) VALUES
(1, 322567, 12, 'js retail', 'Madan', 2147483647, 'example1@gmail.com'),
(2, 322569, 13, 'ms factory', 'yadav', 2147483647, 'example2@gmail.com'),
(3, 322569, 14, 'trs automobile', 'kunal', 2147483647, 'example3@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `ostk_staff`
--

CREATE TABLE `ostk_staff` (
  `staff_id` int(11) UNSIGNED NOT NULL,
  `dept_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `role_id` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `username` varchar(32) NOT NULL DEFAULT '',
  `firstname` varchar(32) DEFAULT NULL,
  `lastname` varchar(32) DEFAULT NULL,
  `passwd` varchar(128) DEFAULT NULL,
  `backend` varchar(32) DEFAULT NULL,
  `email` varchar(128) DEFAULT NULL,
  `phone` varchar(24) NOT NULL DEFAULT '',
  `phone_ext` varchar(6) DEFAULT NULL,
  `mobile` varchar(24) NOT NULL DEFAULT '',
  `signature` text NOT NULL,
  `lang` varchar(16) DEFAULT NULL,
  `timezone` varchar(64) DEFAULT NULL,
  `locale` varchar(16) DEFAULT NULL,
  `notes` text,
  `isactive` tinyint(1) NOT NULL DEFAULT '1',
  `isadmin` tinyint(1) NOT NULL DEFAULT '0',
  `isvisible` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `onvacation` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `assigned_only` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `show_assigned_tickets` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `change_passwd` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `max_page_size` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `auto_refresh_rate` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `default_signature_type` enum('none','mine','dept') NOT NULL DEFAULT 'none',
  `default_paper_size` enum('Letter','Legal','Ledger','A4','A3') NOT NULL DEFAULT 'Letter',
  `extra` text,
  `permissions` text,
  `created` datetime NOT NULL,
  `lastlogin` datetime DEFAULT NULL,
  `passwdreset` datetime DEFAULT NULL,
  `updated` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ostk_staff`
--

INSERT INTO `ostk_staff` (`staff_id`, `dept_id`, `role_id`, `username`, `firstname`, `lastname`, `passwd`, `backend`, `email`, `phone`, `phone_ext`, `mobile`, `signature`, `lang`, `timezone`, `locale`, `notes`, `isactive`, `isadmin`, `isvisible`, `onvacation`, `assigned_only`, `show_assigned_tickets`, `change_passwd`, `max_page_size`, `auto_refresh_rate`, `default_signature_type`, `default_paper_size`, `extra`, `permissions`, `created`, `lastlogin`, `passwdreset`, `updated`) VALUES
(1, 1, 1, 'leykart1', 'pankaj', 'kumar', '$2a$08$FSu83QaxhARu02l69XoyteqbnHb7jnl6PW1e.Pz.0XtYiKUFboIca', NULL, 'pankja.kumar55@infosys.com', '', NULL, '', '', NULL, NULL, NULL, NULL, 1, 1, 1, 0, 0, 0, 0, 25, 0, 'none', 'Letter', '{\"browser_lang\":\"en_US\"}', '{\"user.create\":1,\"user.edit\":1,\"user.delete\":1,\"user.manage\":1,\"user.dir\":1,\"org.create\":1,\"org.edit\":1,\"org.delete\":1,\"faq.manage\":1,\"emails.banlist\":1}', '2017-06-30 12:46:07', '2017-08-22 19:29:06', '2017-06-30 12:46:07', '2017-08-22 19:29:06');

-- --------------------------------------------------------

--
-- Table structure for table `ostk_view_ticket`
--

CREATE TABLE `ostk_view_ticket` (
  `serialNo` int(7) NOT NULL,
  `ticketNo` varchar(50) NOT NULL,
  `ticketid` int(11) NOT NULL,
  `ticketStatus` varchar(20) NOT NULL,
  `orderNo` varchar(10) NOT NULL,
  `raisedBy` varchar(64) NOT NULL,
  `raisedDate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `lastAttendedBy` varchar(64) DEFAULT NULL,
  `LastAttendedDate` timestamp NULL DEFAULT NULL,
  `issueCategoryId` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ostk_view_ticket`
--

INSERT INTO `ostk_view_ticket` (`serialNo`, `ticketNo`, `ticketid`, `ticketStatus`, `orderNo`, `raisedBy`, `raisedDate`, `lastAttendedBy`, `LastAttendedDate`, `issueCategoryId`) VALUES
(1, '345670', 0, 'open', '1233', '12', '2017-09-21 19:18:44', 'rohan', '2017-09-21 19:18:44', 'sap issue'),
(2, '345670', 0, 'open', '1233', '12', '2017-09-21 19:18:44', 'rohan', '2017-09-21 19:18:44', 'sap issue'),
(3, '34560', 0, 'open', '1233', '12', '2017-09-21 19:18:44', 'rohan', '2017-09-21 19:18:44', 'sap issue'),
(4, '34561', 0, 'open', '1233', '10', '2017-09-21 19:18:44', 'rohan', '2017-09-21 19:18:44', 'sap issue'),
(5, '34561', 0, 'open', '1233', '10', '2017-09-21 19:18:44', 'rohan', '2017-09-21 19:18:44', 'sap issue'),
(6, '34561', 0, 'open', '1233', '10', '2017-09-21 19:18:44', 'rohan', '2017-09-21 19:18:44', 'sap issue'),
(7, '34561', 0, 'open', '1233', '10', '2017-09-21 19:18:44', 'rohan', '2017-09-21 19:18:44', 'sap issue'),
(8, '34561', 0, 'open', '1233', '10', '2017-09-21 19:18:44', 'rohan', '2017-09-21 19:18:44', 'sap issue'),
(9, '34561', 0, 'open', '1233', '10', '2017-09-21 19:18:44', 'rohan', '2017-09-21 19:18:44', 'sap issue'),
(10, '0', 0, 'Open', '15', '0', '2017-09-21 12:27:14', 'Ashwin', '2017-09-21 12:27:14', 'Replacement/Return'),
(11, 'AL_SD_Test_000042', 0, 'Open', '18', '0', '2017-09-21 12:33:12', 'Ashwin', '2017-09-21 12:33:12', 'Parts out of stock'),
(12, 'AL_SD_Test_000043', 0, 'Open', '19', '0', '2017-09-22 06:31:29', 'Ashwin', '2017-09-22 06:31:29', 'Partial refund'),
(13, 'AL_SD_Test_000044', 0, 'Open', '1515', '0', '2017-09-26 10:30:19', 'Ashwin', '2017-09-26 10:30:19', 'Status of replacement'),
(14, 'AL_SD_Test_000045', 0, 'Open', '25', '0', '2017-09-26 12:28:34', 'Ashwin', '2017-09-26 12:28:35', 'Partial replacement'),
(15, 'AL_SD_Test_000047', 0, 'Open', '24', '0', '2017-09-27 07:42:49', 'Ashwin', '2017-09-27 07:42:49', 'SAP issues'),
(16, 'AL_SD_Test_000048', 0, 'Open', '25', '0', '2017-09-27 07:48:20', 'Ashwin', '2017-09-27 07:48:21', 'Account modification'),
(17, 'AL_SD_Test_000054', 0, 'Open', '97', '0', '2017-09-28 13:26:43', 'Ashwin', '2017-09-28 13:26:43', 'Cancel Order'),
(18, 'AL_SD_Test_000055', 0, 'Open', '48', '0', '2017-10-04 05:37:27', 'Ashwin', '2017-10-04 05:37:27', 'Cancel Order'),
(19, 'AL_SD_Test_000056', 0, 'Open', '52', '0', '2017-10-04 08:37:03', 'Ashwin', '2017-10-04 08:37:03', 'Cancel Order'),
(20, 'AL_SD_Test_000057', 142, 'Open', '79', '0', '2017-10-04 11:45:41', 'Ashwin', '2017-10-04 11:45:41', 'Cancel Order'),
(21, 'AL_SD_Test_000058', 143, 'Open', '74', '0', '2017-10-04 12:39:35', 'Ashwin', '2017-10-04 12:39:35', 'Cancel Order'),
(22, 'AL_SD_Test_000059', 144, 'Open', '75', '0', '2017-10-04 12:42:01', 'Ashwin', '2017-10-04 12:42:01', 'Cancel Order'),
(23, 'AL_SD_Test_000060', 145, 'Open', '34', '0', '2017-10-05 06:31:18', 'Ashwin', '2017-10-05 06:31:18', 'Cancel Order'),
(24, 'AL_SD_Test_000068', 153, 'Open', '1324', '0', '2017-10-07 12:01:41', 'Ashwin', '2017-10-07 12:01:41', 'Partial refund'),
(25, 'AL_SD_Test_000069', 154, 'Open', '1324', '0', '2017-10-07 12:01:47', 'Ashwin', '2017-10-07 12:01:47', 'Partial refund'),
(26, 'AL_SD_Test_000070', 155, 'Open', '12', '0', '2017-10-07 12:56:23', 'Ashwin', '2017-10-07 12:56:23', 'Account modification'),
(27, 'AL_SD_Test_000072', 157, 'Open', '127', '0', '2017-10-07 13:50:34', 'Ashwin', '2017-10-07 13:50:34', 'Cancel Order');

-- --------------------------------------------------------

--
-- Table structure for table `upload_files`
--

CREATE TABLE `upload_files` (
  `id` int(10) NOT NULL,
  `path` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `upload_files`
--

INSERT INTO `upload_files` (`id`, `path`) VALUES
(0, 'uploadedData/instructions.txt'),
(2, 'uploadedData/idostk_caller_type.csv'),
(1, 'uploadedData/callcentertable1.sql'),
(3, 'uploadedData/callcenterv1.3.sql'),
(4, 'uploadedData/Conference.svt');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `idostk_caller_type`
--
ALTER TABLE `idostk_caller_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ostk_action_taken`
--
ALTER TABLE `ostk_action_taken`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ostk_feedback_option`
--
ALTER TABLE `ostk_feedback_option`
  ADD PRIMARY KEY (`serialNo`),
  ADD KEY `feedback_question_id` (`feedback_question_id`);

--
-- Indexes for table `ostk_feedback_question`
--
ALTER TABLE `ostk_feedback_question`
  ADD PRIMARY KEY (`serialNo`),
  ADD KEY `feedback_type` (`feedback_type`);

--
-- Indexes for table `ostk_feedback_response`
--
ALTER TABLE `ostk_feedback_response`
  ADD PRIMARY KEY (`feedback_response_id`),
  ADD KEY `feedback_question_id` (`feedback_question_id`),
  ADD KEY `feedback_option_id` (`feedback_option_id`),
  ADD KEY `feedback_type` (`feedback_type`);

--
-- Indexes for table `ostk_feedback_type`
--
ALTER TABLE `ostk_feedback_type`
  ADD PRIMARY KEY (`type_id`);

--
-- Indexes for table `ostk_issue_category`
--
ALTER TABLE `ostk_issue_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ostk_poc_detail`
--
ALTER TABLE `ostk_poc_detail`
  ADD PRIMARY KEY (`serial_no`);

--
-- Indexes for table `ostk_staff`
--
ALTER TABLE `ostk_staff`
  ADD PRIMARY KEY (`staff_id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD KEY `dept_id` (`dept_id`),
  ADD KEY `issuperuser` (`isadmin`);

--
-- Indexes for table `ostk_view_ticket`
--
ALTER TABLE `ostk_view_ticket`
  ADD PRIMARY KEY (`serialNo`,`ticketNo`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `idostk_caller_type`
--
ALTER TABLE `idostk_caller_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `ostk_action_taken`
--
ALTER TABLE `ostk_action_taken`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `ostk_feedback_option`
--
ALTER TABLE `ostk_feedback_option`
  MODIFY `serialNo` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `ostk_feedback_question`
--
ALTER TABLE `ostk_feedback_question`
  MODIFY `serialNo` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `ostk_feedback_response`
--
ALTER TABLE `ostk_feedback_response`
  MODIFY `feedback_response_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `ostk_issue_category`
--
ALTER TABLE `ostk_issue_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `ostk_poc_detail`
--
ALTER TABLE `ostk_poc_detail`
  MODIFY `serial_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `ostk_staff`
--
ALTER TABLE `ostk_staff`
  MODIFY `staff_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `ostk_view_ticket`
--
ALTER TABLE `ostk_view_ticket`
  MODIFY `serialNo` int(7) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `ostk_feedback_option`
--
ALTER TABLE `ostk_feedback_option`
  ADD CONSTRAINT `ostk_feedback_option_ibfk_1` FOREIGN KEY (`feedback_question_id`) REFERENCES `ostk_feedback_question` (`serialNo`);

--
-- Constraints for table `ostk_feedback_question`
--
ALTER TABLE `ostk_feedback_question`
  ADD CONSTRAINT `ostk_feedback_question_ibfk_1` FOREIGN KEY (`feedback_type`) REFERENCES `ostk_feedback_type` (`type_id`);

--
-- Constraints for table `ostk_feedback_response`
--
ALTER TABLE `ostk_feedback_response`
  ADD CONSTRAINT `ostk_feedback_response_ibfk_1` FOREIGN KEY (`feedback_question_id`) REFERENCES `ostk_feedback_question` (`serialNo`),
  ADD CONSTRAINT `ostk_feedback_response_ibfk_2` FOREIGN KEY (`feedback_option_id`) REFERENCES `ostk_feedback_option` (`serialNo`),
  ADD CONSTRAINT `ostk_feedback_response_ibfk_3` FOREIGN KEY (`feedback_type`) REFERENCES `ostk_feedback_type` (`type_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
