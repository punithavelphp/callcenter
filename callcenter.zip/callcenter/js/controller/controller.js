app.controller("popupcntrl", ['$scope', '$rootScope', '$uibModal', function ($scope, $rootScope, $uibModal) {
        // $scope.data = data
        // $scope.popupclose = function($scope){
        // //$scope.modalInstances.dismiss('cancel')
        // //console.log("pop up closed "  )
        // console.log(popupcount)
        // modalInstances.close(false);
        // popupcount = 0
        // console.log(popupcount)

        // };

        $scope.popupclose = function () {
            //$scope.modalInstances.dismiss('cancel')
            //console.log($scope.countpop)
            //console.log($rootScope.modalInstances)
            $rootScope.modalInstances[$scope.countpop].close(false);
            //$rootScope.modalInstances[$scope.countpop].dismiss("cancel");
            // $rootScope.modalInstances[$scope.countpop].result.catch(function (resp) {
            // console.log(resp)
            // if (['cancel', 'backdrop click', 'escape key press'].indexOf(resp) === -1){
            // //console.log(resp)
            // throw resp;
            // }
            // })
            $rootScope.modalInstances.splice($scope.countpop, 1)
            //console.log($rootScope.modalInstances)
            $rootScope.popupcount--;

        };

        // listen for the event in the relevant $scope
        $scope.$on('ticketsubmitEvent', function (event, data) {
            //console.log(event ); // 'Data to send'
            //modalInstances.close(false);
            $rootScope.modalInstances[$scope.countpop].close(false);
            $rootScope.modalInstances.splice($scope.countpop, 1)
            //console.log($rootScope.modalInstances)
            $rootScope.popupcount--;
        });
    }])


app.controller("indexcntrl", ['$scope', '$q', '$rootScope', '$state', '$uibModal', 'USER_ROLES', 'authenticationSvc',
    'userInfosvc', '$location', 'focus', 'OSTicket_ConstantApi', 'Leykart_DatabaseConstant', 'fetchdatabase',
    'errorcodesrv', '$sessionStorage', 'ConvertJsonToCsvSrv',
    function ($scope, $q, $rootScope, $state, $uibModal, USER_ROLES, authenticationSvc, userInfosvc,
            $location, focus, OSTicket_ConstantApi, Leykart_DatabaseConstant, fetchdatabase, errorcodesrv, $sessionStorage,
            ConvertJsonToCsvSrv)
    {

        //indexNavgService.navShowValue  = false;
        $scope.navShowValue = false;
        //console.log("refrshed " + $location.url().split("/")[1] );

        $scope.elementFocus = function (id) {
            // do something awesome
            focus(id);
        };

        $scope.resourceTabClick = function (value) {
            $scope.showResourceButton = value;
        }

        $scope.setHighlightActiveTab = function (name) {
            $scope.highlightActiveTab = name;

        }

        if ($location.url().split("/")[1] === 'login')
            $scope.setHighlightActiveTab('createnewticket');
        else
        {
            $scope.resourceTabClick(true)
            $scope.setHighlightActiveTab($location.url().split("/")[1]);
        }//anitha

        $scope.setnavshow = function (value) {
            //console.log(value)
            $scope.navShowValue = value;
            //console.log($sessionStorage.userInfo)
            if ($scope.helpTopicId) {
                //console.log("helptopic present")
            } else
            if ($sessionStorage.userInfo != null) {
                $scope.helpTopicFun().then(function (value) {
                    if (value) {
                        $scope.loading = false;
                    }
                });
            }
        }

        $scope.currentUser = null;
        $scope.userRoles = USER_ROLES;
        $scope.isAuthorized = "";

        $scope.setCurrentUser = function (user) {
            $scope.currentUser = user;
        };


        $scope.homepage = function () {
            $state.go("createnewticket");
        }

        $scope.redirectTo = function (name) {
            $state.go(name);
            // console.log("redirectTo function " + templateRelatedDataSrvc.getHighlightActiveTab());
            $scope.setHighlightActiveTab(name);

        }

        $scope.admin = function (name) {
            //alert(" do u wanna see feedbacks");

            $state.go("admin.viewopenticket");
        }

        $scope.partscatalouge = function (name) {
            //alert(" do u wanna see partscatalouge");

            var url = '/#' + $state.href('partscatalouge', {parameter: name});
            window.open(url, '_blank');
            //$state.go("partscatalouge");
        }
        $scope.instructionmanual = function (name) {
            //alert(" do u wanna see instructionmanual");
            var url = '/#' + $state.href('instructionmanual', {parameter: name});
            window.open(url, '_blank');
            //$state.go("instructionmanual");
        }
        $scope.viewpocdetail = function (name) {
            //alert(" do u wanna see viewpocdetail");
            //$scope.setnavshow(true);
            //$scope.loading =true
            // Start of getting poc detail from local database
            //$state.go("viewpocdetail");
            var url = '/#' + $state.href('viewpocdetail', {parameter: name});
            window.open(url, '_blank');

        }
        $scope.orderdetails = function (name) {
            //alert(" do u wanna see orderdetails");
            var url = '/#' + $state.href('orderdetails', {parameter: name});
            window.open(url, '_blank');
            //$state.go("orderdetails");
        }

        //var popupcount = 0
        //var modalInstances =[]

        $rootScope.popupcount = 0
        $rootScope.modalInstances = []

        $scope.popupopen = function (name, data, $scope) {

            //$scope.countpop =0
            //var modalInstances =null
            $scope.data = data
            $scope.countpop = $rootScope.popupcount
            $rootScope.popupcount++
            //console.log(typeof data)
            // if(popupcount == 0){
            // popupcount = 1
            var model = $uibModal.open({
                templateUrl: 'templates/' + name + '.html',
                scope: $scope,
                controller: 'popupcntrl'
            })
            $rootScope.modalInstances.push(model)
            // }
            // else
            // return
        }

        // ticket creator
        $scope.getcreatorindex = function (ticket) {
            for (let indx in ticket.event_info) {
                if (ticket.event_info[indx].data == '{"claim":true}') {
                    $scope.creatorindx = indx;
                    return;
                }
            }
            $scope.creatorindx = undefined;
        }

        $scope.$on('ticketsubmitEvent', function (event, data) {
            //console.log(event ); // 'Data to send'
            modalInstances.close(false);
            popupcount = 0
        });

        $scope.sort = function (keyname) {
            //console.log("indexcntrl sort")
            $scope.sortKey = keyname;   //set the sortKey to the param passed
            $scope.reverse = !$scope.reverse; //if true make it false and vice versa
        }

        $scope.logout = function () {
            authenticationSvc.logout()
            $scope.highlightActiveTab = '';
            $state.go("login");
        }

        $scope.getUserName = function () {
            //console.log("getUsername")
            return userInfosvc.userInfo[0].username;
        }

        // $scope.getUserRole = function(){
        // //console.log("getUserrole")
        // return userInfosvc.userInfo[0].role;
        // }
        //console.log(new Date());
        $scope.downloadExcel = function (exceldata, excelname) {
            //console.log(exceldata)
            var csvString = ConvertJsonToCsvSrv.ConvertToCSV(exceldata);
            var a = $('<a/>', {
                style: 'display:none',
                href: 'data:application/octet-stream;base64,' + btoa(csvString),
                download: excelname + '.csv'
            }).appendTo('body')
            a[0].click()
            a.remove();
        }



        $scope.userroleMenu = "";
        $scope.getUserRole = function () {
            //console.log("user role")
            if (userInfosvc.userInfo[0].role == "Agent") {
                return "agent";
            } else {
                return "admin";
            }
            //return userInfosvc.userInfo[0].role;

        }


        // start of getting help topic 
        $scope.helpTopicFun = function () {
            var deferred = $q.defer();
            var data = {
                "luser": userInfosvc.returnUserInfo()[0].username,
                "lpasswd": userInfosvc.returnUserInfo()[0].pass,
                "request_data": "helptopic",
                "application_name": "LeyKart APP",
                "depart_name": "L1 Support - Leykart"
            }
            $scope.loading = true
            //var path = OSTicket_ConstantApi.l1agenturlpath;
            //var header = OSTicket_ConstantApi.Header
            var path = Leykart_DatabaseConstant.osticketurl;
            //authenticationSvc.login('POST',OSTicket_ConstantApi.Apiendpoint,path,data,header)
            fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, path, 'l1agent', data)
                    .then(function (response) {
                        //console.log(response)
                        if (response.data == null || response.data == "") {
                            var msg = errorcodesrv.checkcode(response.status)
                            if (msg !== "")
                                var popupdata = msg
                            else
                                var popupdata = "There Is No  Help Topic To Display"
                            $scope.popupopen('generalpopup', popupdata, $scope)
                            $scope.loading = false
                        } else {
                            $scope.helpTopicId = response.data[0].topic_id
                            $scope.loading = false
                        }
                        deferred.resolve(true);
                    },
                            function (response) {
                                console.log("Error response received  while getting L2 and L3 details from os ticket ")
                                console.log(response)
                                var msg = errorcodesrv.checkcode(response.status)
                                if (msg !== "")
                                    var popupdata = msg
                                else
                                    var popupdata = "Error Response Received  While Getting Help Topics From Os Ticket "
                                $scope.popupopen('generalpopup', popupdata, $scope)
                                deferred.reject(false);
                            })
            return deferred.promise;
        }
        //helpTopicFun()
        // end  of getting help topic 

    }])


app.controller("signincntrl", ['$scope', '$state', '$rootScope', 'AUTH_EVENTS', 'authenticationSvc', 'fetchdatabase', 'OSTicket_ConstantApi', '$sessionStorage', 'errorcodesrv', 'Leykart_DatabaseConstant',
    function ($scope, $state, $rootScope, AUTH_EVENTS, authenticationSvc, fetchdatabase, OSTicket_ConstantApi, $sessionStorage, errorcodesrv, Leykart_DatabaseConstant) {
        $scope.loading = false;
        // $scope.getUserRole()
        $scope.setnavshow(false);
        $scope.resourceTabClick(false)

        $scope.credentials = {"luser": "", "lpasswd": "", "depart_name": "L1 Support - Leykart"};
        //"depart_name":"L1 Support"
        //,"depart_name":"L1 Support - Leykart"
        //$scope.credentials = {"luser": "Ashwin","lpasswd": "password"};
        //$scope.credentials = {"luser": "keerthana","lpasswd": "password"};

        // start of os ticket log in
        $scope.login = function () {
            $scope.loading = true
            var data = $scope.credentials;
            //var path = OSTicket_ConstantApi.authenticationurlpath;
            var path = Leykart_DatabaseConstant.osticketurl;
            //var header = OSTicket_ConstantApi.Header
            //authenticationSvc.login('POST',OSTicket_ConstantApi.Apiendpoint,path,data,header)
            //authenticationSvc.login('POST',Leykart_DatabaseConstant.Apiendpoint,path,data,header)
            fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, path, 'login', data)
                    .then(function (response) {
                        //console.log(" sign in content received   ");
                        //console.log(response);
                        authenticationSvc.verifyuser(response.data, data.lpasswd)
                                .then(function (SwitchToState) {
                                    $scope.helpTopicFun().then(function (value) {
                                        if (value) {

                                        }
                                    });
                                    $scope.loading = false
                                    $rootScope.$broadcast(AUTH_EVENTS.loginSuccess);
                                    //console.log("ready to goto   " + SwitchToState );
                                    $state.go(SwitchToState);
                                    $sessionStorage.somevalue = $scope.credentials.lpasswd
                                }
                                , function (response) {
                                    console.log("failure response received from authenticationSvc verifyuser function")
                                });
                    }, function (response) {
                        var popupdata = ""
                        $scope.loading = false
                        $rootScope.$broadcast(AUTH_EVENTS.loginFailed);
                        if (response.data && response.data == " ") {
                            var msg = errorcodesrv.checkcode(response.status)
                            if (msg !== "")
                                popupdata = msg
                            else
                                popupdata = "Login Error"
                        } else
                            popupdata = response
                        // $scope.popupclose()
                        $scope.popupopen('generalpopup', popupdata, $scope)
                        $scope.credentialType = "Please Enter A Valid Username And Password";
                        //console.log(response);
                    })
            // end of os ticket log in

        };
        $scope.elementFocus('username')

    }])



app.controller("createnewticketcntrl", ['$scope', '$state', '$q', '$rootScope', 'fetchdatabase', 'authenticationSvc', 'OSTicket_ConstantApi',
    'Leykart_DatabaseConstant', 'magento_ConstantApi', 'removingVerifiedItemSrvc', 'userInfosvc', 'DeliveryProvider', 'OSTicket_IpForTicketCreation', 'errorcodesrv', 'ProconnectPath',
    function ($scope, $state, $q, $rootScope, fetchdatabase, authenticationSvc, OSTicket_ConstantApi,
            Leykart_DatabaseConstant, magento_ConstantApi, removingVerifiedItemSrvc, userInfosvc, DeliveryProvider, OSTicket_IpForTicketCreation, errorcodesrv, ProconnectPath) {

        //$scope.getUserRole()
        $scope.resourceTabClick(true)
        $scope.setnavshow(true);
        $scope.setHighlightActiveTab('createnewticket');
        $scope.helpTopicFun();
        $scope.actiontaken = [];
        $scope.callerDetails = {"callermobNo": '', "calleruniqueNo": ''}
        var userinfo = userInfosvc.returnUserInfo()[0]
        //console.log(userinfo)
        $scope.warning1 = "";
        $scope.warning2 = "";
        // get caller type from database
        var dataObj = null;
        fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, Leykart_DatabaseConstant.urlpath, 'callerType', dataObj)
                .then(function (response) {
                    //console.log(response.data)
                    //response.data = $filter('orderBy')(response.data, 'id', true)
                    //console.log(response.data)
                    $scope.selectedCallerType = response.data[0]
                    $scope.callersType = response.data;
                }, function (error) {
                    console.log("error in getting callers type")
                    console.log(error)
                });
        $scope.accountModificationRequest = function (customer) {
            $scope.loading = true;
            var el_notif = document.getElementById("notif");
            var el_ticket = document.getElementById("ticket");
            el_ticket.style.visibility = 'hidden';
            var para = document.createElement("P");
            var t = document.createTextNode("Loading...");
            para.appendChild(t);
            el_notif.appendChild(para);
            el_notif.style.visibility = 'visible';
            var re = {mob: ''};
            re.mob = new RegExp("^[0-9]{10}$");
            console.log(re.mob.test("" + customer.mobile_no))
            //re.email=/^([a-zA-Z0-9_\-\.]+)@((([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4})(\]?)$/
            re.email = /^\w+([\.-_]?\w+)*@\w+([\.-]?\w+){1}(\.(com|in)){1}$/i
            console.log(re.email.test(customer.Email))
            if (!re.mob.test("" + customer.mobile_no)) {
                $scope.warning1 = "Enter valid mobile number";
            } else if (!re.email.test(customer.Email)) {
                $scope.warning2 = "Enter valid email id";
            }
            var userinfo = userInfosvc.returnUserInfo()[0]
            var path = Leykart_DatabaseConstant.osticketurl;
            var data = {"name": customer.Name,
                "email": customer.Email,
                "phone": customer.mobile_no,
                "comment": customer.comment,
                "subject": "Account modification#NA",
                "message": "Name : " + customer.Name + " | Email : " + customer.Email + " | Mobile No : " + customer.mobile_no + " | Address : " + customer.Address
                        + " | SAP ID: " + customer.sap_id + " | DBM ID: " + customer.dbm_id + " | GST NO: " + customer.gst_no,
                // "ip"  : '125.22.193.148',
                "topicId": $scope.helpTopicId, // 27
                "laykartappsubcategory": "Account modification",
                "TicketType": "Operations",
                "priority": "2"
            };
            fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, path, 'createticket', data)
                    .then(function (ticketnumber) {
                        //console.log(response)
                        //console.log("ticketNo  received from os ticket")
                        //$scope.loading =false
                        if (ticketnumber.data[0] != null) {
                            //var para=document.createElement("P");
                            var t1 = document.createTextNode("Ticket number " + ticketnumber.data[0] + " created");
                            //para.appendChild(t);
                            //el_notif.appendChild(para);
                            //el_ticket.style.visibility='hidden';
                            var data = {
                                "luser": userinfo.username,
                                "lpasswd": userinfo.pass,
                                //"helptopic":"27", 
                                "helptopic": $scope.helpTopicId,
                                "ticket_number": ticketnumber.data[0],
                                "status": "",
                                "staff_id": "",
                                "from_date": "",
                                "to_date": ""
                            }
                            //console.log(data)
                            // callimg os ticket to fetch ticket details
                            var path = Leykart_DatabaseConstant.osticketurl;
                            //authenticationSvc.login('POST',OSTicket_ConstantApi.Apiendpoint, path, data, OSTicket_ConstantApi.Header)
                            fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, path, 'viewticket', data)
                                    .then(function (response) {
                                        //console.log(response)
                                        // calling transfer function to transfer ticket to that person

                                        // these 5 lines is comented for time being

                                        $scope.assignTo = {}
                                        $scope.assignTo.staff_id = userInfosvc.returnUserInfo()[0].staff_id
                                        $scope.ticketToTransferOrAssign = []
                                        $scope.ticketToTransferOrAssign.push({'index': response.data[0]})
                                        var data = {
                                            "luser": userInfosvc.returnUserInfo()[0].username,
                                            "lpasswd": userInfosvc.returnUserInfo()[0].pass,
                                            "ticket_id": response.data[0].ticket_id,
                                            "update_type": "AssigntoStaff",
                                            "message": "Assign ticket from API",
                                            "assignto": userInfosvc.returnUserInfo()[0].staff_id
                                        }
                                        //console.log(data)
                                        //var count = 0
                                        var path = Leykart_DatabaseConstant.osticketurl;
                                        //authenticationSvc.login('POST',OSTicket_ConstantApi.Apiendpoint,path,data,header)
                                        fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, path, 'updateticketAssign', data)
                                                .then(function (response) {
                                                    if (response.data == 'true') {
                                                    }
                                                    ;
                                                    para.removeChild(para.childNodes[0]);
                                                    para.appendChild(t1);
                                                    el_notif.style.visibility = 'visible';
                                                    //btn.disabled=false;
                                                    //load.style.visibility="hidden";
                                                    $scope.loading = false;
                                                });
                                    })
                            $scope.sendSmsCallCenter(customer.mobile_no, ticketnumber.data[0], 1);
                        }
                    });
        }
        $scope.sendSmsCallCenter = function (mobileNumber, ticketNumber, modf) {
            if (modf == 1) {
                var today_date = new Date();
                var today = ((today_date.getDate() < 10) ? "0" : "") + today_date.getDate()
                        + "/" + (((today_date.getMonth() + 1) < 10) ? "0" : "")
                        + (today_date.getMonth() + 1) + "/" + today_date.getFullYear() + ", "
                        + ((today_date.getHours() < 10) ? "0" : "") + today_date.getHours()
                        + ":" + ((today_date.getMinutes() < 10) ? "0" : "") + today_date.getMinutes();
                //var textmessage = "Thank you for contacting us. The reference no. for your Leykart query is (" + ticketNumber +"), registered on " + today + "."
                var textmessage = "Dear <User>, Thank you for contacting us. The reference no. for your Leykart query is " + ticketNumber + " registered on " + today + ". Thank you";
            }
            if (modf == 2) {
                //var textmessage = "Dear <User>, request " + ticketNumber +" Closed successfully. Thank you";
                var textmessage = "Dear <User>, Your Leykart query with reference no. (" + ticketNumber + ") has been resolved and closed successfully. Thank you";
            }

            var data = {"mobileNo": mobileNumber, "message": textmessage};

            /*fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, Leykart_DatabaseConstant.urlpath, 'sendSmsCallCenter',data)
             .then(function(response) {
             $scope.popupopen('generalpopup',JSON.stringify(response),$scope);
             }, function(response) {
             $scope.popupopen('generalpopup', JSON.stringify(response), $scope);
             }
             );*/
            var path = 'sendsmsforticket';
            authenticationSvc.login('POST', magento_ConstantApi.Apiendpoint, path, data)
                    .then(function (response) {
                        console.log(response);
                        //$scope.popupopen('generalpopup',JSON.stringify(response),$scope);
                    }, function (response) {
                        console.log(response);
                        //$scope.popupopen('generalpopup','test',$scope);
                    });
        }


        $scope.PartListRequest = function (parts, customer)
        {
            $scope.loading = true;
            var el_notif = document.getElementById("notif");
            var el_ticket = document.getElementById("ticket");

            el_ticket.style.visibility = 'hidden';
            var para = document.createElement("P");
            var t = document.createTextNode("Loading...");
            para.appendChild(t);

            el_notif.appendChild(para);
            el_notif.style.visibility = 'visible';

            var userinfo = userInfosvc.returnUserInfo()[0]
            var path = Leykart_DatabaseConstant.osticketurl;
            var data = {
                "name": customer.Name,
                "email": customer.Email,
                "phone": customer.mobile_no,
                "subject": "Part Listing#NA",
                "message": "Name : " + customer.Name + " | Email : " + customer.Email + " | Mobile No : " + customer.mobile_no + " | Address : " + customer.Address + " | Part number: " + parts.partNumber + " | Chassis Number :" + parts.chassisNumber + " | Model number : " + parts.modelNumber + " | Registration Number : " + parts.RegistrationNumber + " | Aggregate : " + parts.aggregate,
                // "ip"  : '125.22.193.148',
                "topicId": $scope.helpTopicId, // 27
                "laykartappsubcategory": "Part Listing",
                "TicketType": "Operations",
                "priority": "2"
            };
            fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, path, 'createticket', data)
                    .then(function (ticketnumber)
                    {
                        //$scope.loading =false
                        if (ticketnumber.data[0] != null)
                        {
                            $scope.sendSmsCallCenter(customer.mobile_no, ticketnumber.data[0], 1);
                            //var para=document.createElement("P");
                            var t1 = document.createTextNode("Ticket number " + ticketnumber.data[0] + " created");
                            //para.appendChild(t);
                            //el_notif.appendChild(para);
                            //el_ticket.style.visibility='hidden';
                            var data = {
                                "luser": userinfo.username,
                                "lpasswd": userinfo.pass,
                                //"helptopic":"27", 
                                "helptopic": "27",
                                "ticket_number": ticketnumber.data[0],
                                "status": "",
                                "staff_id": "",
                                "from_date": "",
                                "to_date": ""
                            }
                            //console.log(data)
                            // callimg os ticket to fetch ticket details
                            var path = Leykart_DatabaseConstant.osticketurl;
                            //authenticationSvc.login('POST',OSTicket_ConstantApi.Apiendpoint, path, data, OSTicket_ConstantApi.Header)
                            fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, path, 'viewticket', data)
                                    .then(function (response)
                                    {
                                        //console.log(response)
                                        // calling transfer function to transfer ticket to that person			
                                        // these 5 lines is comented for time being

                                        $scope.assignTo = {}
                                        $scope.assignTo.staff_id = userInfosvc.returnUserInfo()[0].staff_id
                                        $scope.ticketToTransferOrAssign = []
                                        $scope.ticketToTransferOrAssign.push({'index': response.data[0]})
                                        var data = {
                                            "luser": userInfosvc.returnUserInfo()[0].username,
                                            "lpasswd": userInfosvc.returnUserInfo()[0].pass,
                                            "ticket_id": response.data[0].ticket_id,
                                            "update_type": "AssigntoStaff",
                                            "message": "Assign ticket from API",
                                            "assignto": userInfosvc.returnUserInfo()[0].staff_id
                                        }
                                        //console.log(data)
                                        //var count = 0
                                        var path = Leykart_DatabaseConstant.osticketurl;
                                        //authenticationSvc.login('POST',OSTicket_ConstantApi.Apiendpoint,path,data,header)
                                        fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, path, 'updateticketAssign', data)
                                                .then(function (response)
                                                {
                                                    if (response.data == 'true') {
                                                    }
                                                    ;
                                                    para.removeChild(para.childNodes[0]);
                                                    para.appendChild(t1);
                                                    el_notif.style.visibility = 'visible';
                                                    //btn.disabled=false;
                                                    //load.style.visibility="hidden";
                                                    $scope.loading = false;
                                                });
                                    })
                        }
                    });
        }
        $scope.selectedIssueType = {};
        $scope.getCustomerGroups = function () {
            fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, Leykart_DatabaseConstant.urlpath, 'getCustomerGroups', null).then(function (response) {
                if (response.data.indexOf('<script>') == -1) {
                    $scope.customerGroups = response.data;
                }
            });
        }
        $scope.getCustomerGroups();
        // Start of clear button functionality
        $scope.resetform = function () {
            //console.log("called")
            $scope.callerDetails.callermobNo = ''
            $scope.callerDetails.calleruniqueNo = ''
            //$scope.customerinfo.Name = ''
            //$scope.customerinfo.mobile_no= $scope.customerinfo.Email=$scope.customerinfo.Type=$scope.customerinfo.Address=''
            $scope.customerinfo = []
            $scope.customerpastorder = []
            $scope.customercurrentorder = []
            $scope.customer_email = ""
            $scope.searchText = ''
            $scope.suborderss = ''
            $scope.actiontaken = ''
            $scope.partlist = []
            //$scope.selectedIssueType = ''
        }
        // end of clear button functionality
        $scope.openAccountModForm = function (customerinfo) {
            $scope.warning1 = "";
            $scope.warning2 = "";
            if (customerinfo != null && customerinfo != undefined && customerinfo.Email != "") {
                $scope.popupopen('modifyaccountpopup', null, $scope);
            } else {
                $scope.popupopen('generalpopup', 'Please enter the customer mobile number', $scope);
            }
        }
        $scope.openPartListform = function (partlist, customerinfo) {
            $scope.partlist = [];
            $scope.warning1 = "";
            $scope.warning2 = "";
            if (customerinfo != null && customerinfo != undefined && customerinfo.Email != "") {
                $scope.popupopen('partlistpopup', null, $scope);
            } else {
                $scope.popupopen('generalpopup', 'Please enter the customer mobile number', $scope);
            }
        }
        // get Issue type   from  Leykart database
        $scope.getissue = function (id_of_caller) {
            $scope.resetform();
            $scope.customerinfo.Email = '';
            $scope.customerinfo.mobile_no = '';
            var dataObj = {}
            dataObj.caller_id = id_of_caller;
            fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, Leykart_DatabaseConstant.urlpath, 'IssueType', dataObj)
                    .then(function (response) {
                        //console.log(response)
                        $scope.issueType = response.data;
                        $scope.issueType.push({'caller_type': "1", 'issue_category': "Select"})
                        $scope.selectedIssueType = $scope.issueType[$scope.issueType.length - 1]
                    }, function (error) {
                        console.log("error in getting IssueType type")
                        console.log(error)
                    });
        }
        $scope.getissue(1)
        // $scope.disablecreateticketbutton=function(){
        // 	console.log($scope.selectedIssueType)
        // 	if($scope.selectedIssueType.issue_category == 'Select')
        // 		return true
        // }

        $scope.clearform = function () {
            $scope.callerDetails.callermobNo = ''
            $scope.callerDetails.calleruniqueNo = ''
        }

        $scope.checkorderstatus = function (stats) {
            /*console.log(/cancel/.test(stats.toLowerCase()) || !$scope.selectedIssueType ||($scope.selectedIssueType && $scope.selectedIssueType.issue_category != 'Cancel order')||($scope.selectedIssueType && $scope.selectedIssueType.issue_category != 'Return/Replacement'));
             return /cancel/.test(stats.toLowerCase()) || !$scope.selectedIssueType ||(($scope.selectedIssueType && $scope.selectedIssueType.issue_category != 'Cancel order')&&($scope.selectedIssueType && $scope.selectedIssueType.issue_category != 'Return/Replacement'))*/
            /*   console.log(/cancel/.test(stats.toLowerCase()) || !$scope.selectedIssueType ||($scope.selectedIssueType && ($scope.selectedIssueType.issue_category != 'Cancel order'&&$scope.selectedIssueType.issue_category != 'Replacement/Return/Damage/short supply')))*/
            if (stats == "Delivered" && $scope.selectedIssueType.issue_category == 'Replacement/Return/Damage/short supply') {
                return false;
            } else if ((stats != "Delivered" && stats != "Return Inititated" && stats.indexOf("Refund") == -1 && stats.indexOf("Return") == -1 && stats.indexOf("Cancel") == -1) && $scope.selectedIssueType.issue_category == 'Cancel order') {
                return false;
            } else
                return true;
            /*return /cancel/.test(stats.toLowerCase()) || !$scope.selectedIssueType ||($scope.selectedIssueType && ($scope.selectedIssueType.issue_category != 'Cancel order'&&$scope.selectedIssueType.issue_category != 'Replacement/Return/Damage/short supply'))*/
        }

        $scope.disableCallerEdit = function () {
            //console.log($scope.selectedCallerType.caller_type == 'User')
            if ($scope.selectedCallerType && $scope.selectedCallerType.caller_type == 'User') {
                //console.log($scope.customerinfo.Type)
                return true
            } else
                return false
        }

        // get Issue Type From Os Ticket 
        // function IssueCategory(){
        // var path = OSTicket_ConstantApi.l1agenturlpath ;             //    '/api/http.php/masterdata.json' ;
        // var data = {
        // "luser": userinfo.username,
        // "lpasswd": userinfo.pass,
        // "request_data": "subcategory_values",
        // "application_name": "LeyKart App"
        // }
        // console.log(data)
        // //calling os ticket for creating ticket
        // authenticationSvc.login('POST',OSTicket_ConstantApi.Apiendpoint, path, data, OSTicket_ConstantApi.Header)
        // .then(function(response){
        // //console.log(JSON.parse(response.data['13'].configuration).choices)

        // if(response.data == null || response.dat == ''){
        // var popupdata = "No Data Received From Os Ticket Regarding Issue Category"
        // $scope.popupopen('generalpopup',popupdata,$scope)	
        // }
        // else{
        // issue = fetchdatabase.convertStringToJsonObject(JSON.parse(response.data['13'].configuration).choices)
        // $scope.issueType = issue
        // console.log($scope.issueType)
        // var dataObj =issue;
        // fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, Leykart_DatabaseConstant.urlpath, 'issueCategory', dataObj)
        // .then(function(response){
        // console.log(response)
        // if(response.data == "   true"){
        // console.log("successfully stored issue type in leykart database")
        // //if(response.length>0)	
        // }
        // else{
        // console.log("Issue Type Not Able Store In Local Database")
        // }
        // },function(error){
        // console.log("Error In Storing IssueType type In Local Leykart Database")
        // console.log(error)
        // });

        // }

        // },function(response){
        // console.log(response)
        // var popupdata = "Error in getting Sub Category From Os Ticket"
        // $scope.popupopen('generalpopup',popupdata,$scope)

        // })
        // }
        // IssueCategory()



        // get action to be Taken type from database
        $scope.actionTakenfun = function () {
            // let dataObj ={'callertypeId':$scope.selectedCallerType.caller_type,'isuuecateg':$scope.selectedIssueType.issue_category};
            //console.log($scope.selectedCallerType.id)
            //console.log($scope.selectedIssueType.issue)
            if ($scope.selectedCallerType && $scope.selectedIssueType) {
                let dataObj = {'callertypeId': $scope.selectedIssueType.caller_type, 'isuuecateg': $scope.selectedIssueType.issue_category};
                fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, Leykart_DatabaseConstant.urlpath, 'actionToBeTaken', dataObj)
                        .then(function (response) {
                            //console.log(response)
                            if (response.length > 0) {
                                $scope.actiontaken = response;
                                //if(response.length>0)	
                            } else {
                                //console.log("else"+$scope.actiontaken)
                                $scope.actiontaken = []
                                $scope.actiontaken.push("No action to be taken present");
                                //console.log($scope.actiontaken)
                            }

                        }, function (response) {
                            //console.log(response)
                            $scope.actiontaken = [];
                            $scope.actiontaken.push("Error in fetching data from leykart database");
                        });

                //getting issue prioriy
                fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, Leykart_DatabaseConstant.urlpath, 'getIssuePriority', dataObj)
                        .then(function (response) {

                            if (response.data[0].priority_id.length > 0) {
                                var selected_issue_pri_id = response.data[0].priority_id;

                                var data = {
                                    "luser": userInfosvc.returnUserInfo()[0].username,
                                    "lpasswd": userInfosvc.returnUserInfo()[0].pass,
                                    "request_data": "prioritylist",
                                    "application_name": "LeyKart",
                                    "depart_name": "L1 Support - Leykart"
                                };
                                var path = Leykart_DatabaseConstant.osticketurl;

                                fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, path, 'l1agent', data)
                                        .then(function (response1) {
                                            if (response1.data == null || response1.data == "") {
                                                var msg = errorcodesrv.checkcode(response1.status)
                                                if (msg !== "")
                                                    var popupdata = msg;
                                                else
                                                    var popupdata = "There Is No Priority from os ticket";
                                                $scope.popupopen('generalpopup', popupdata, $scope)
                                                //$scope.loading = false
                                            } else {
                                                $scope.priority = response1.data;
                                                for (var i = 0; i < response1.data.length; i++) {
                                                    if (response1.data[i].priority_id == selected_issue_pri_id) {
                                                        $scope.priorityType = response1.data[i];
                                                    }
                                                }
                                            }
                                        }, function (response1) {
                                            var msg = errorcodesrv.checkcode(response1.status);
                                            if (msg !== "")
                                                var popupdata = msg;
                                            else
                                                var popupdata = "Error Response Received  While Getting Priority list from os ticket";
                                            $scope.popupopen('generalpopup', popupdata, $scope);
                                        });
                            } else {
                                alert('empty response for priority');
                            }

                        }, function (response) {
                            //console.log(response)
                            //$scope.actiontaken= [];
                            //$scope.actiontaken.push("Error in fetching data from leykart database");
                        });
                if ($scope.selectedIssueType.issue_category == 'Account modification') {
                    $scope.openAccountModForm($scope.customerinfo);
                }
                if ($scope.selectedIssueType.issue_category == 'Part Listing') {
                    $scope.openPartListform($scope.partlist, $scope.customerinfo);
                }
            } else {
                $scope.actiontaken = [];
                $scope.actiontaken.push('please select the caller type and issue category first ')
            }
        };

        //$scope.caller={};
        // start of getting current and past orders
        //$scope.callermobNo = 1234567891                 //918344503939

        $scope.currentPastOrders = function () {
            //console.log($scope.callermobNo)
            //console.log($scope.callerDetails.callermobNo)
            //console.log($scope.callerDetails.calleruniqueNo)

            $scope.suborderss = [];
            $scope.searchText = "";
            if ((typeof ($scope.callerDetails.callermobNo) == undefined || $scope.callerDetails.callermobNo == null || $scope.callerDetails.callermobNo == '') && (typeof ($scope.callerDetails.calleruniqueNo) == undefined || $scope.callerDetails.calleruniqueNo == null || $scope.callerDetails.calleruniqueNo == '')) {
                var popupdata = "Please Enter Mobile No Or Unique Id To Search"
                $scope.popupopen('generalpopup', popupdata, $scope)
                return
            }
            $scope.mainOrderID = '';
            arrayForTrackingVerifiedOrder = [];
            $scope.loading = true
            //console.log($scope.calleruniqueNo)
            var data = {}

            if ($scope.callerDetails.callermobNo != undefined && $scope.callerDetails.callermobNo != null && $scope.callerDetails.calleruniqueNo != undefined && $scope.callerDetails.calleruniqueNo != null) {
                //console.log("here")
                data.mobile_num = $scope.callerDetails.callermobNo
                data.unique_id = $scope.callerDetails.calleruniqueNo
            } else if (($scope.callerDetails.callermobNo != undefined || $scope.callerDetails.callermobNo != null) && (!$scope.callerDetails.calleruniqueNo || $scope.callerDetails.calleruniqueNo == null)) {
                //console.log("here1")
                data.mobile_num = $scope.callerDetails.callermobNo
                data.unique_id = "null"
            } else if ((!$scope.callerDetails.callermobNo || $scope.callerDetails.callermobNo == null) && ($scope.callerDetails.calleruniqueNo || $scope.callerDetails.calleruniqueNo != null)) {
                //console.log("here2")
                data.mobile_num = "null"
                data.unique_id = $scope.callerDetails.calleruniqueNo
            }
            // data.mobile_num = $scope.callermobNo
            // data.unique_id = $scope.calleruniqueNo
            //console.log(data)
            //console.log($scope.callermobNo)
            var path = 'getcurntpastorderurlpath';
            //var header = magento_ConstantApi.Headers
            authenticationSvc.login('POST', magento_ConstantApi.Apiendpoint, path, data)
                    .then(function (response) {
                        //console.log(response)
                        //console.log(response.data)
                        if (response.data.indexOf("Invalid Input - 2") >= 0) {
                            $scope.loading = false
                            $scope.customerinfo = []
                            $scope.customerpastorder = []
                            $scope.customercurrentorder = []
                            $scope.customer_email = ""
                            var popupdata = "Mobile Number Or Unique Id Doesn't Exist"
                            $scope.popupopen('generalpopup', popupdata, $scope)
                            $scope.elementFocus('mobno')
                        }
                        if (response.data != "Mobile Number Doesn't Match" && response.data != "Invalid Input - 2" && response.data) {
                            $scope.customerinfo = response.data[0].customer_info[0]
                            $scope.customerinfo.mobile_no = parseInt($scope.customerinfo.mobile_no);
                            $scope.customerpastorder = response.data[0].past
                            $scope.customercurrentorder = response.data[0].recent
                            $scope.customer_email = response.data[0].customer_info[0].Email
                        }
                        $scope.loading = false
                    },
                            function (response) {
                                $scope.loading = false
                                $scope.customerinfo = []
                                $scope.customerpastorder = []
                                $scope.customercurrentorder = []
                                $scope.customer_email = ""
                                console.log("Error In Getting customer Info ,Current Order And Past Order  Details ")
                                console.log(response)
                                var msg = errorcodesrv.checkcode(response.status)
                                if (msg !== "")
                                    var popupdata = msg
                                else
                                    var popupdata = 'Error Response Received While Getting Customer Info,Current and Past Order Details'
                                $scope.popupopen('generalpopup', popupdata, $scope)
                                $scope.loading = false
                            })

        }
        // end of current and past orders

        //start of past orders base on date
        $scope.PastOrders = function () {

            //alert($scope.calleruniqueNo +"  "+ $scope.callermobNo)
            //console.log($scope.callermobNo);    
            if (($scope.callermobNo == undefined && $scope.calleruniqueNo == undefined) || ($scope.callermobNo == '' && $scope.calleruniqueNo == '')) {
                //alert($scope.calleruniqueNo +"  "+ $scope.callermobNo)
                return
            }
            $scope.loading = true
            var data = {}
            if ($scope.callermobNo != 'undefined' && $scope.callermobNo != null && $scope.calleruniqueNo != 'undefined' && $scope.calleruniqueNo != null) {
                //console.log("here")
                data.mobile_num = $scope.callermobNo
                data.unique_id = $scope.calleruniqueNo
            } else if (($scope.callermobNo != 'undefined' || $scope.callermobNo != null) && (!$scope.calleruniqueNo || $scope.calleruniqueNo == null)) {
                //console.log("here1")
                data.mobile_num = $scope.callermobNo
                data.unique_id = "null"
            } else if ((!$scope.callermobNo || $scope.callermobNo == null) && ($scope.calleruniqueNo || $scope.calleruniqueNo != null)) {
                //console.log("here2")
                data.mobile_num = "null"
                data.unique_id = $scope.calleruniqueNo
            }
            // data.mobile_num = $scope.callermobNo
            // data.unique_id = $scope.calleruniqueNo
            //console.log(data)
            //console.log($scope.callermobNo)
            data.from_date = dateAsData.from_date
            data.to_date = dateAsData.to_date
            //console.log(data)
            var path = 'pastorderurlpath';
            //var header = magento_ConstantApi.Headers
            authenticationSvc.login('POST', magento_ConstantApi.Apiendpoint, path, data)
                    .then(function (response) {
                        console.log(response)
                        response.data = JSON.parse(response.data[0])
                        //console.log(response.data)
                        if (response.data === "Invalid Input - 2") {
                            // $scope.loading = false
                            // $scope.customerinfo = []
                            // $scope.customerpastorder = []
                            // $scope.customercurrentorder = []
                            // $scope.customer_email = ""
                            var popupdata = "Past Orders  Doesn't Exist Please check Mobile NO or Unique Id"
                            $scope.popupopen('generalpopup', popupdata, $scope)
                            // $scope.elementFocus('mobno')
                        } else if (response.data.length == 0) {
                            var popupdata = "Past Orders  Doesn't Exist For Given Date"
                            $scope.popupopen('generalpopup', popupdata, $scope)
                        } else if (response.data != "Mobile Number Doesn't Match" && response.data != "Invalid Input - 2") {
                            // $scope.customerinfo = response.data[0].customer_info[0]
                            $scope.customerpastorder = response.data
                            // $scope.customercurrentorder = response.data[0].recent
                            // $scope.customer_email = response.data[0].customer_info[0].Email
                        }

                        $scope.loading = false
                    },
                            function (response) {
                                // $scope.loading = false
                                // $scope.customerinfo = []
                                // $scope.customerpastorder = []
                                // $scope.customercurrentorder = []
                                // $scope.customer_email = ""
                                // console.log("Error In Getting customer Info ,Current Order And Past Order  Details ")
                                console.log(response)
                                var msg = errorcodesrv.checkcode(response.status)
                                if (msg !== "")
                                    var popupdata = msg
                                else
                                    var popupdata = 'Error Response Received While Getting Customer Info,Current and Past Order Details'
                                $scope.popupopen('generalpopup', popupdata, $scope)
                                $scope.loading = false
                            })
        }
        // end of past orders


        // var userinfo = userInfosvc.returnUserInfo()[0]
        // console.log(userinfo)

        // starat of initiate cancel odre
        $scope.initiatecancelOrder = function () {
            //$scope.disableCreateTicketButton("initiate");
            var btn = document.getElementById('createBtn');
            btn.disabled = true;
            var popupdata = ""
            //console.log("called function initiatecancelOrder")
            //console.log(arrayForTrackingVerifiedOrder)
            $scope.loading = true
            // if($scope.customerinfo == undefined || $scope.customerinfo.Name == undefined){
            // popupdata = "Please Provide valid Mobile No For Initiating Cancellation/Creating Ticket" 
            // $scope.popupopen('generalpopup',popupdata,$scope)
            // $scope.loading = false
            // return
            // }
            var chk = false;
            if (($scope.searchText != "" && $scope.searchText != null) || arrayForTrackingVerifiedOrder.length > 0 || $scope.suborderss.length > 0) {
                angular.forEach($scope.customerpastorder, function (past) {
                    if ($scope.mainOrderID == past.orderid) {
                        chk = true;
                    }
                });
                if (!chk) {
                    angular.forEach($scope.customercurrentorder, function (current) {
                        if ($scope.mainOrderID == current.orderid) {
                            chk = true;
                        }
                    });
                }

                if (!chk) {
                    if ($scope.customerinfo.customer_id == $scope.mainOrderCustomerID) {
                        chk = true;
                    }
                }
            } else
                chk = true;
            console.log("customer details id: " + $scope.customerinfo.customer_id);
            console.log("customer details id: " + $scope.mainOrderCustomerID);

            if (arrayForTrackingVerifiedOrder.length > 0) {

                var obj = 0
                if (!chk) {
                    var popupdata = "You cannot cancel this order as it is not placed by the current Customer."
                    $scope.popupopen('generalpopup', popupdata, $scope);
                    $scope.loading = false;
                    $scope.suborderss = [];
                    arrayForTrackingVerifiedOrder = [];
                    $scope.mainOrderID = ''
                    btn.disabled = false;
                    return;
                }
                function iterateover(obj) {
                    //console.log("inside cancellation order ticket")
                    //for(let i=0;i < arrayForTrackingVerifiedOrder.length;i++){
                    //console.log(arrayForTrackingVerifiedOrder[i])
                    var cstatus = ""
                    var comment = ""
                    var orderid = arrayForTrackingVerifiedOrder[obj].orderid
                    var canresn = arrayForTrackingVerifiedOrder[obj].cancelreason
                    // calling function to check whether admin approval is required or not
                    adminApprovalRequired(arrayForTrackingVerifiedOrder[obj]).then(function (respons) {
                        //console.log(respons);
                        var done = false;
                        if (respons == false) {
                            // directy approve the cancellation
                            done = true;
                            cstatus = "CANAPP"
                            comment = "Cancellation Approved "
                        } else if (respons == true) {
                            // initiate cancellation for order
                            done = true;
                            cstatus = "CANINI"
                            comment = "Cancellation Initiated "
                        } else {
                            var popupdata = 'Cancellation not applicable.'
                            if ($scope.selectedIssueType.issue_category == 'Replacement/Return/Damage/short supply') {
                                popupdata = 'Return/Replacement not applicable.'
                            }
                            done = false;
                            btn.disabled = false;
                            $scope.popupopen('generalpopup', popupdata, $scope);
                        }
                        //console.log(cstatus + "  "+ comment)
                        //return
                        var data = {"order": [{
                                    "orderid": orderid,
                                    "cancelreason": canresn,
                                    "cstatus": cstatus,
                                    "comment": comment,
                                    "cancel_charge": $scope.get_cancel_charge,
                                    "cancel_charge_without_handling": $scope.get_cancel_charge_without_handling,
                                    "handling_fee": $scope.get_handling_fee
                                }]}
                        var path = 'initiatecancelurlpath';
                        if (done && chk)
                            authenticationSvc.login('POST', magento_ConstantApi.Apiendpoint, path, data)
                                    .then(function (response) {
                                        //console.log(response)
                                        //var orderno = response.config.data.order[0].orderid
                                        //var cancellation_charge=response.data[0][0].orderdetails.cancellation_charge;
                                        var orderno = response.data[0][0].orderdetails.message.order_id
                                        //console.log(response.data[0][0].orderdetails.error_code)
                                        //console.log(response.data[0][0].orderdetails.status)
                                        if (response.data[0][0].orderdetails.error_code == 0) {
                                            //console.log("Successfully initiated cancellation for the order no " +orderno)
                                            popupdata = "Successfully Initiated Cancellation For The Order No " + orderno;
                                            //$scope.popupopen('generalpopup',popupdata,$scope)
                                            // creating ticket for the order whose  cancellation has been initiate
                                            //let subject = "Order Cancellation for order no "+orderno;
                                            let subject = $scope.selectedIssueType.issue_category + "#" + orderno;
                                            // heve to decide on   priority,topicid,fleetmanger
                                            createticket(popupdata, subject, orderno, 'CancelOrder', respons)
                                                    .then(function (response) {

                                                        obj++
                                                        //console.log(obj)
                                                        if (obj == arrayForTrackingVerifiedOrder.length) {
                                                            $scope.loading = false
                                                            //$scope.getcancelrequest()
                                                            //deferred.resolve(true);
                                                            setTimeout(function () {
                                                                $state.go($state.current, {}, {reload: true})
                                                                $scope.elementFocus('mobno');
                                                            }, 4000);

                                                        } else if (obj < arrayForTrackingVerifiedOrder.length) {
                                                            iterateover(obj)

                                                        }


                                                    }, function (response) {
                                                        setTimeout(function () {
                                                            $state.go($state.current, {}, {reload: true})
                                                            $scope.elementFocus('mobno');
                                                        }, 4000);
                                                        console.log("Error in creating ticket")
                                                        btn.disabled = false;
                                                    })

                                        } else {
                                            console.log("Error response received  while Initiating cancellation for order no " + orderno)
                                            var msg = errorcodesrv.checkcode(response.status)
                                            console.log(response)
                                            if (response.data[0][0].orderdetails.status == "error")
                                                var popupdata = response.data[0][0].orderdetails.message.message
                                            else if (msg !== "")
                                                var popupdata = msg
                                            else
                                                popupdata = "Error response received  while Initiating cancellation for order no " + orderno
                                            $scope.popupopen('generalpopup', popupdata, $scope)
                                            $scope.loading = false
                                            btn.disabled = false;
                                            //console.log(response)
                                        }
                                    },
                                            function (response) {
                                                console.log("Error response received  while Initiating cancellation for the order  ")
                                                console.log(response)
                                                var msg = errorcodesrv.checkcode(response.status)
                                                if (msg !== "")
                                                    var popupdata = msg
                                                else
                                                    popupdata = "Error response received  while Initiating cancellation for order no "
                                                $scope.popupopen('generalpopup', popupdata, $scope)
                                                $scope.loading = false
                                                btn.disabled = false;

                                            })
                        //}
                    })
                    $scope.loading = false;
                }
                iterateover(obj)
            } else {
                //console.log("inside general ticket")
                //let subject = "General Enquiry for order no "+$scope.searchText ;
                let srch = $scope.searchText ? $scope.searchText : 'NA'
                let subject = $scope.selectedIssueType.issue_category + "#" + srch;
                //console.log(subject)
                // heve to decide on   priority,topicid,fleetmanger
                if (chk) {
                    createticket(popupdata, subject, $scope.searchText, 'NormalTicket', true)
                            .then(function (response) {
                                setTimeout(function () {
                                    $state.go($state.current, {}, {reload: true})
                                    $scope.elementFocus('mobno');
                                }, 4000);
                            }, function (response) {
                                console.log("Error in creating ticket")
                            })
                } else {
                    var popupdata = "You cannot raise any ticket for the order as it is not placed by the current Customer."
                    $scope.popupopen('generalpopup', popupdata, $scope);
                    $scope.loading = false;
                    $scope.suborderss = [];
                    arrayForTrackingVerifiedOrder = [];
                    $scope.mainOrderID = ''
                    //btn.disabled=true;
                    return;
                }
            }
            //$scope.loading = false

        }

        function adminApprovalRequired(order) {
            var deferred = $q.defer();
            if ($scope.selectedIssueType.issue_category == "Replacement/Return/Damage/short supply" && order.orderStatus != 'Delivered') {
                deferred.resolve(null);
            } else if (order.cancelreason == 'LA' || order.cancelreason == 'LB') {
                if (order.orderStatus == 'Order Placed' || order.orderStatus == 'Packed' || order.orderStatus == 'In transit' || order.orderStatus == 'Shipped') {
                    deferred.resolve(true);
                } else if (order.orderStatus == 'Delivered') {
                    deferred.resolve(true);
                } else {
                    deferred.resolve(null);
                }
            } else if (order.cancelreason == 'LE' || order.cancelreason == 'LF' || order.cancelreason == 'LO' || order.cancelreason == 'LM' || order.cancelreason == 'LN') {
                if (order.orderStatus == 'Packed' || order.orderStatus == 'In transit' || order.orderStatus == 'Shipped') {
                    deferred.resolve(true);
                } else if (order.orderStatus == 'Delivered') {
                    deferred.resolve(true);
                } else {
                    deferred.resolve(null);
                }
            } else if (order.cancelreason == 'LC' || order.cancelreason == 'LD') {
                if (order.orderStatus == 'Order Placed' || order.orderStatus == 'Packed' || order.orderStatus == 'In transit' || order.orderStatus == 'Shipped') {
                    var tday = new Date();
                    var tday_1 = tday.getFullYear() + '-' + tday.getMonth() + '-' + tday.getDate();
                    angular.forEach($scope.suborderss, function (suborder) {
                        if (suborder.suborder_id == order.orderid) {
                            order.expected_arrival = new Date(suborder.expected_arrival);
                        }
                    })
                    if (tday > order.expected_arrival) {
                        deferred.resolve(true);
                    } else {
                        deferred.resolve(null);
                    }
                } else if (order.orderStatus == 'Delivered') {
                    deferred.resolve(true);
                } else {
                    deferred.resolve(null);
                }
            } else if (order.cancelreason == 'LG' || order.cancelreason == 'LH') {
                if (order.orderStatus == 'Delivered') {
                    deferred.resolve(true);
                } else {
                    deferred.resolve(null);
                }
            } else if (order.cancelreason == 'LK') {
                if (order.orderStatus == 'Delivered') {
                    deferred.resolve(true);
                } else {
                    deferred.resolve(null);
                }
            } else if (order.cancelreason == 'LI' || order.cancelreason == 'LJ' || order.cancelreason == 'LL') {
                if (order.orderStatus == 'Delivered') {
                    deferred.resolve(true);
                } else {
                    deferred.resolve(null);
                }
            }
            return deferred.promise;
        }

        // called by create new ticket button
        // $scope.createNewTicket = function (){
        // let subject = "General Enquiry for order no "+$scope.searchText ;
        // // heve to decide on   priority,topicid,fleetmanger
        // createticket(subject,$scope.searchText )
        // }

        // for creating ticket in osticket and leykart database
        // heve to decide on   priority,topicid,fleetmanger
        function createticket(popupdata, subject, orderno, ticketfor, adminapproval) {

            var deferred = $q.defer();
            //Start of data required for ticket creation
            if (!$scope.customerinfo.mobile_no || $scope.customerinfo.mobile_no == null || $scope.customerinfo.mobile_no.length < 10) {
                //console.log($scope.customerinfo.mobile_no)
                var popupdata = "Please enter the correct Mobile Number to create ticket";
                $scope.popupopen('generalpopup', popupdata, $scope)
                $scope.loading = false
                return
            }
            /*if($scope.customerinfo.Type!='Fleet Manager'&&$scope.customerinfo.Type!='Customer'&&$scope.customerinfo.Type!='Mechanic'&&$scope.customerinfo.Type!='Seller'&&$scope.customerinfo.Type!='Retailer'&&$scope.customerinfo.Type!='DP'){*/
            if ($scope.customerinfo.Type == '' || $scope.customerinfo.Type == null) {
                var popupdata = "Please select a Caller Type.";
                //$scope.customerinfo.Type='';
                $scope.popupopen('generalpopup', popupdata, $scope)
                $scope.loading = false
                return
            }
            if (!$scope.customerinfo.Name || $scope.customerinfo.Name == null) {
                //console.log($scope.customerinfo.Name)
                var popupdata = "Please Enter Name to create ticket";
                $scope.popupopen('generalpopup', popupdata, $scope)
                $scope.loading = false
                return
            }
            if (!$scope.customerinfo.Email || $scope.customerinfo.Email == null) {
                //console.log($scope.customerinfo.Email)
                var popupdata = "Please Enter Email Id in Email format to create ticket";
                $scope.popupopen('generalpopup', popupdata, $scope)
                $scope.loading = false
                return
            }
            if ($scope.selectedIssueType.issue_category == "Complaints" && ($scope.inputComments == '' || $scope.inputComments == null || $scope.inputComments == undefined)) {
                var popupdata = "Please enter your complaint in the comment box";
                $scope.popupopen('generalpopup', popupdata, $scope)
                $scope.loading = false
                return
            }

            //var reEmail = /^(?:[\w\!\#\$\%\&\'\*\+\-\/\=\?\^\`\{\|\}\~]+\.)*[\w\!\#\$\%\&\'\*\+\-\/\=\?\^\`\{\|\}\~]+@(?:(?:(?:[a-zA-Z0-9](?:[a-zA-Z0-9\-](?!\.)){0,61}[a-zA-Z0-9]?\.)+[a-zA-Z0-9](?:[a-zA-Z0-9\-](?!$)){0,61}[a-zA-Z0-9]?)|(?:\[(?:(?:[01]?\d{1,2}|2[0-4]\d|25[0-5])\.){3}(?:[01]?\d{1,2}|2[0-4]\d|25[0-5])\]))$/;
            //var reEmail= /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.(com|in))+$/;
            var reEmail = /^\w+([\.-_]?\w+)*@\w+([\.-]?\w+){1}(\.(com|in)){1}$/i;
            if (!$scope.customerinfo.Email.match(reEmail)) {
                var popupdata = "Please enter a valid email address";
                $scope.popupopen('generalpopup', popupdata, $scope)
                $scope.loading = false
                return
            }

            // console.log("normal return")
            // return
            //var name = userinfo.firstname ;
            //var userid = $scope.customerinfo.
            //var name = 'Munro' ;
            //var email = $scope.customer_email;
            var name = $scope.customerinfo.Name
            var email = $scope.customerinfo.Email
            var staffId = userinfo.staff_id
            var uname = userinfo.username
            var pass = userinfo.pass
            var phoneNo = $scope.customerinfo.mobile_no || $scope.callerDetails.callermobNo || $scope.callermobNo;
            var subject = subject;
            // var ip = OSTicket_IpForTicketCreation.ip; 
            var priority = $scope.priorityType.priority_id;
            var topicid = $scope.helpTopicId;
            var fleetmanger = fleetmanger
            var inputComments = $scope.inputComments
            if (ticketfor === 'CancelOrder')
                var ticketassignto = 'admin'
            else
                var ticketassignto = 'agent'

            // if($scope.selectedIssueType != undefined )
            // var selectedIssueType = $scope.selectedIssueType.issue_category  
            // else
            // var selectedIssueType = 'Cancel Order'
            //end of data required for ticket creation

            // it is working code uncomment it later on by prviding proper ticket no  as input to variable dataObject
            $scope.loading = true
            //var path = OSTicket_ConstantApi.createticketurlpath ;             //    '/api/http.php/tickets.json' ;
            var data = {"name": name,
                "email": email,
                "phone": phoneNo,
                "subject": subject,
                "message": inputComments || 'No Comments',
                // "ip"  : '125.22.193.148',
                "topicId": topicid, // 27
                "laykartappsubcategory": $scope.selectedIssueType.issue_category,
                "TicketType": "Operations",
                "priority": priority
            };
            //console.log(data)
            //calling os ticket for creating ticket
            var path = Leykart_DatabaseConstant.osticketurl;
            //authenticationSvc.login('POST',OSTicket_ConstantApi.Apiendpoint, path, data, OSTicket_ConstantApi.Header)
            fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, path, 'createticket', data)
                    .then(function (response) {
                        //console.log(response)
                        //console.log("ticketNo  received from os ticket")
                        //$scope.loading =false
                        if (response.data[0] != null) {
                            $scope.sendSmsCallCenter(phoneNo, response.data[0], 1);
                            //alert("Ticket created in os ticket with ticket no " + response.data)
                            popupdata = popupdata + "\nTicket created  with ticket no " + response.data[0]
                            //$scope.popupopen('generalpopup',popupdata,$scope)
                            //console.log("Ticket created in os ticket with ticket no  " + response.data)

                            //var path = OSTicket_ConstantApi.viewticketurlpath ; 
                            var data = {
                                "luser": uname,
                                "lpasswd": pass,
                                //"helptopic":"27", 
                                "helptopic": $scope.helpTopicId,
                                "ticket_number": response.data[0],
                                "status": "",
                                "staff_id": "",
                                "from_date": "",
                                "to_date": ""
                            }
                            //console.log(data)
                            // callimg os ticket to fetch ticket details
                            var path = Leykart_DatabaseConstant.osticketurl;
                            //authenticationSvc.login('POST',OSTicket_ConstantApi.Apiendpoint, path, data, OSTicket_ConstantApi.Header)
                            fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, path, 'viewticket', data)
                                    .then(function (response) {
                                        //console.log(response)
                                        // calling transfer function to transfer ticket to that person

                                        // these 5 lines is comented for time being

                                        $scope.assignTo = {}
                                        $scope.assignTo.staff_id = userInfosvc.returnUserInfo()[0].staff_id
                                        $scope.ticketToTransferOrAssign = []
                                        $scope.ticketToTransferOrAssign.push({'index': response.data[0]})
                                        ticketTransfer(response.data[0].ticket_id, ticketassignto)
                                                //$scope.ticketTransfer('assign',$scope)
                                                .then(function (resp) {
                                                    if (adminapproval == false) {
                                                        ticketClose(response.data[0].ticket_id, "call from callcenter API").then(function (re) {}, function (re) {
                                                            //console.log(re+"  "+"Error while closing ticket for order cancellation which dont require admin approval  ")
                                                        })
                                                    }

                                                    //ticketClose(response.data[0].ticket_id,"call from callcenter API").then(function(re){
                                                    //console.log(re)
                                                    //console.log(response)
                                                    //$scope.popupopen('generalpopup',popupdata,$scope)
                                                    //console.log(response.data[0])						// AL_SD_Test_000032
                                                    var details = response.data[0]
                                                    var dataObj = {'ticketid': details.ticket_id,
                                                        'ticketno': details.ticket_number,
                                                        'staff_id': details.staff_id,
                                                        'isuuecateg': $scope.selectedIssueType.issue_category,
                                                        'orderno': orderno,
                                                        'agentId': 4,
                                                        'comment': inputComments,
                                                        'created': details.created,
                                                        'status': details.status,
                                                        'lastatendedby': details.timeline[details.timeline.length - 1].poster,
                                                        'lastatendeddate': details.timeline[details.timeline.length - 1].created
                                                    }
                                                    // callimg leykart database to store ticket details				
                                                    fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, Leykart_DatabaseConstant.urlpath, 'createticket', dataObj)
                                                            .then(function (response) {
                                                                //console.log(response)
                                                                if (response.data == true || response.data == "  true" || response.data.indexOf("true") != -1) {
                                                                    //console.log("Ticket created successfully in leykart database")
                                                                    //$scope.loading =false
                                                                    //$scope.popupopen('generalpopup',"Ticket created successfully in leykart database",$scope)
                                                                    //console.log(popupdata)
                                                                    $scope.popupopen('generalpopup', popupdata, $scope)

                                                                    deferred.resolve(true);


                                                                    //$scope.resetform()
                                                                    //$state.go($state.current, {}, {reload: true});
                                                                    // $scope.popupopen('generalpopup',popupdata,$scope)
                                                                    //$scope.elementFocus('mobno')

                                                                }

                                                            }, function (response) {
                                                                console.log("ticket crated succesfully in Os ticket but Error occured while storing ticket detail in leykart database ")
                                                                console.log(response)
                                                                deferred.reject(false);
                                                                $scope.loading = false
                                                                //$state.reload();
                                                            })
                                                    // function call for closing the ticket for certain condition
                                                    // },function(re){
                                                    // 	console.log(re+"  "+"Error while closing ticket for order cancellation which dont require admin approval  ")
                                                    // })


                                                }, function (error) {
                                                    $scope.loading = false;
                                                    console.log(error);
                                                    console.log("Error in assigning ticket While Creating Ticket ")
                                                    deferred.reject(false);
                                                    ;
                                                })
                                    }, function (response) {
                                        $scope.loading = false
                                        console.log("ticket crated succesfully in Os ticket but Error occured while fetching ticket details from os ticket ")
                                        console.log(response)
                                        deferred.reject(false);
                                        //$state.reload();
                                    })

                        }
                    },
                            function (response) {
                                console.log("Error response received  while creating ticket in os ticket ")
                                console.log(response)
                                deferred.reject(false);
                                var msg = errorcodesrv.checkcode(response.status)
                                if (response.data && response.data !== "")
                                    var popupdata = response.data
                                else if (response)
                                    var popupdata = response
                                else if (msg !== "")
                                    var popupdata = msg
                                else
                                    popupdata = popupdata + "\nError Response Received  While Creating Ticket In Os Ticket "
                                $scope.popupopen('generalpopup', popupdata, $scope)
                                $scope.loading = false
                                //console.log(response)
                            })
            return deferred.promise;
        }

        // Start of assign ticket to person who created it
        function ticketTransfer(ticketId) {
            var deferred = $q.defer();
            //console.log("called ticketTransfer of create new ticket function ")	
            //var path = OSTicket_ConstantApi.updateticketurlpath;
            //var header = OSTicket_ConstantApi.Header
            //var count = 0
            //for(var i=0; i< ticketToTransferOrAssign.length;i++){
            var data = {
                "luser": userInfosvc.returnUserInfo()[0].username,
                "lpasswd": userInfosvc.returnUserInfo()[0].pass,
                "ticket_id": ticketId,
                "update_type": "AssigntoStaff",
                "message": "Assign ticket from API",
                "assignto": userInfosvc.returnUserInfo()[0].staff_id
            }
            //console.log(data)
            //var count = 0
            var path = Leykart_DatabaseConstant.osticketurl;
            //authenticationSvc.login('POST',OSTicket_ConstantApi.Apiendpoint,path,data,header)
            fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, path, 'updateticketAssign', data)
                    .then(function (response) {
                        if (response.data == 'true') {
                            //$scope.loading = false
                            //count++;
                            //$scope.ticketdetails = objct.remainingticket
                            //console.log("ticket assigned  successfully ")
                            //var popupdata = "ticket assigned  or transfered successfully "
                            //$scope.popupopen('generalpopup',popupdata,$scope)
                            // here we need to update our local data base also by changing the raised by
                            //if(count == ticketToTransferOrAssign.length)
                            deferred.resolve(true);
                        }
                    },
                            function (response) {
                                //$scope.ticketdetails = objct.remainingticket
                                //$scope.loading = false
                                console.log("Error response received  while Assigning  ticket  ")
                                console.log(response)
                                //var popupdata = response.statusText
                                //$scope.popupopen('generalpopup',popupdata,$scope)
                                deferred.reject(false);
                            })
            //}
            //console.log(count)

            return deferred.promise;
        }
        // end of assign ticket to person who created it

        // to close the ticket if admin approval is not required for order cancellation  
        function ticketClose(ticketid, message) {
            var deferred = $q.defer();
            var data = {}
            $scope.loading = true
            data = {
                "luser": userInfosvc.returnUserInfo()[0].username,
                "lpasswd": userInfosvc.returnUserInfo()[0].pass,
                "ticket_id": ticketid,
                "update_type": "Reply",
                "message": "Call From CallCenter API",
                "status": "closed"
            }
            //var path = OSTicket_ConstantApi.updateticketurlpath ;
            //$scope.$broadcast('ticketsubmitEvent', {obj: 'please close the popup event!'}) // send whatever you want
            //$scope.popupclose()
            //$scope.popupclose()
            var path = Leykart_DatabaseConstant.osticketurl;
            //authenticationSvc.login('POST',OSTicket_ConstantApi.Apiendpoint, path, data, OSTicket_ConstantApi.Header)
            fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, path, 'updateticketReply', data)
                    .then(function (response) {
                        //console.log(response)
                        if (response.status == 201)
                            //console.log("succesfully replied or noted for the ticket")
                            $scope.loading = false
                        //$scope.ticketGo();
                        var popupdata = "Ticket Created And Closed Successfully For Order Cancellation"
                        $scope.popupopen('generalpopup', popupdata, $scope)
                        deferred.resolve(true);
                    }, function (response) {
                        console.log("Error response received  from os ticket while updating ticket  ")
                        console.log(response)
                        var msg = errorcodesrv.checkcode(response.status)
                        if (msg !== "")
                            var popupdata = msg
                        else
                            var popupdata = "Error response received  from os ticket while updating ticket "
                        $scope.popupopen('generalpopup', popupdata, $scope)
                        // firing an event downwards ie to close model by calling popupcntrl  watch function
                        //$scope.$broadcast('ticketsubmitEvent', {obj: 'please close the popup event!'})   // send whatever you want
                        $scope.loading = false
                        deferred.reject(false);
                    })
            return deferred.promise;

        } // end of ticketSubmit for popup ticket

        // start of date setting and fetching
        var dateAsData = {
            "from_date": '',
            "to_date": ''
        }

        $scope.date = function (fromdate, todate) {
            //console.log(fromdate + "  "+ todate)
            dateAsData.from_date = fromdate.getDate() + '.' + (fromdate.getMonth() + 1) + '.' + fromdate.getFullYear();
            dateAsData.to_date = todate.getDate() + '.' + (todate.getMonth() + 1) + '.' + todate.getFullYear();

            //console.log(fromdate.getDate()+'.'+fromdate.getMonth()+'.'+fromdate.getFullYear())
            //console.log(todate.getDate()+'.'+todate.getMonth()+'.'+todate.getFullYear())
            $scope.PastOrders()

        }
        // end  of date

        // start of to get   order details of input order id 
        $scope.searchText = '';
        $scope.subOrderdetails = function () {
            $scope.loading = true
            var data = {"orderid": $scope.searchText}
            //var path = magento_ConstantApi.orderdetailurlpath+$scope.searchText;
            var path = 'orderdetailurlpath'
            //authenticationSvc.login('GET',magento_ConstantApi.Apiendpoint,path,null,magento_ConstantApi.Headers)
            authenticationSvc.login('POST', magento_ConstantApi.Apiendpoint, path, data)
                    .then(function (response) {
                        var suborder = []
                        //console.log(response.data[0])
                        if (response.data[0] == null || response.data[0] == "") {
                            $scope.suborderss = []
                            var msg = errorcodesrv.checkcode(response.status)
                            if (msg !== "")
                                var popupdata = msg
                            else
                                var popupdata = "Didnt Receive Any Detail From Server"
                            $scope.popupopen('generalpopup', popupdata, $scope)
                            $scope.loading = false
                        } else {
                            $scope.mainOrderID = response.data[0].parent_increment_id;
                            $scope.mainOrderCustomerID = response.data[0].customer_id;
                            // console.log($scope.mainOrderCustomerID);
                            for (var i = 0; typeof (response.data[0][i]) === 'object'; i++)
                                suborder.push(response.data[0][i])
                            $scope.suborderss = suborder;
                            arrayForTrackingVerifiedOrder = [];
                            reasonForCancellation()
                            $scope.loading = false
                        }

                        //var orderdetails = JSON.parse(response.data);
                        // calling function reason for cancellation

                    },
                            function (response) {
                                $scope.suborderss = [];
                                console.log("Error response received  while getting order details ")
                                var msg = errorcodesrv.checkcode(response.status)
                                if (msg !== "")
                                    var popupdata = msg
                                else
                                    var popupdata = "Error Response Received  While Getting Order Details From Server"
                                $scope.popupopen('generalpopup', popupdata, $scope)
                                $scope.loading = false
                                console.log(response)

                            })
        }
        // end of  order details of input order id 

        // start of  Sub order details of input order id
        $scope.suborderpopupopen = function (popuptype, suborderid) {
            $scope.loading = true
            //console.log(suborderid)
            //var path = magento_ConstantApi.orderdetailurlpath+suborderid;
            //authenticationSvc.login('GET',magento_ConstantApi.Apiendpoint,path,null,magento_ConstantApi.Headers)
            var data = {"orderid": suborderid}
            var path = 'orderdetailurlpath';
            authenticationSvc.login('POST', magento_ConstantApi.Apiendpoint, path, data)
                    .then(function (response) {
                        //console.log(response.data)
                        // var orderdetails = JSON.parse(response.data)
                        // console.log(orderdetails)
                        if (response.data[0] == null || response.data[0] == "") {
                            var msg = errorcodesrv.checkcode(response.status)
                            if (msg !== "")
                                var popupdata = msg
                            else
                                var popupdata = "Didnt Receive Any Detail From Server"
                            $scope.popupopen('generalpopup', popupdata, $scope)
                            $scope.loading = false
                        } else {
                            var suborder = []
                            $scope.orderdetails = response.data[0];
                            //console.log(response.data[0])
                            for (var i = 0; typeof (response.data[0][i]) === 'object'; i++)
                                suborder.push(response.data[0][i])
                            $scope.suborders = suborder;
                            $scope.showsearchbar = false;
                            $scope.popupopen(popuptype, response.data[0][0], $scope)
                            $scope.loading = false
                        }
                        // $scope.popupopen(popuptype,response.data[0][0],$scope)
                        // $scope.loading = false
                    },
                            function (response) {
                                console.log("Error response received  while getting sub order details ")
                                console.log(response)
                                var msg = errorcodesrv.checkcode(response.status)
                                if (msg !== "")
                                    var popupdata = msg
                                else
                                    var popupdata = "Error Response Received  While Getting Sub Order Details "
                                $scope.popupopen('generalpopup', popupdata, $scope)
                                $scope.loading = false

                            })
        }
        $scope.strpos = function (haystack, needle, offset) {


            var i = (haystack + '')
                    .indexOf(needle, (offset || 0))
            return i === -1 ? false : i
        }
        // Start of tracking order
        $scope.trackOrder = function (awbNo, dp_name) {
            strpos_proconnect = $scope.strpos(dp_name, 'proconnect');
            if (strpos_proconnect === false) {
                var url = DeliveryProvider.urlpath + awbNo;
            } else {
                var url = ProconnectPath.urlpath + '?order=' + awbNo;
            }
            if (awbNo != 'Not Generated !') {
                var url = url;
                window.open(url);
            } else {
                var popupdata = 'No Valid AWB#. Please verify your details.';
                $scope.popupopen('generalpopup', popupdata, $scope)
            }
        }
        // End of tracking order

        // start of to get Reason for cancellation 
        function reasonForCancellation() {
            //console.log("called reasonForCancellation")
            //var path = magento_ConstantApi.getcancelreasonurlpath;
            //authenticationSvc.login('GET',magento_ConstantApi.Apiendpoint,path,null,magento_ConstantApi.Headers)
            var data = {
                user_role: $scope.getUserRole()
            }
            var path = 'getcancelreasonurlpath';
            authenticationSvc.login('POST', magento_ConstantApi.Apiendpoint, path, data)
                    .then(function (response) {
                        //console.log( response.data[0])
                        if (response.data[0] == null || response.data[0] == "") {
                            var msg = errorcodesrv.checkcode(response.status)
                            if (msg !== "")
                                var popupdata = msg
                            else
                                var popupdata = "Didnt Receive Any Detail From Server"
                            $scope.popupopen('generalpopup', popupdata, $scope)
                            $scope.loading = false
                        } else {
                            $scope.reasonForCancel = response.data[0].reasons;
                            $scope.reasonForCancel.push({'reason_code': "", 'reason_description': "Select"})
                            $scope.selectedReason = $scope.reasonForCancel[$scope.reasonForCancel.length - 1]
                            $scope.loading = false
                        }
                        //$scope.reasonForCancel = response.data[0].reasons;
                        //console.log($scope.reasonForCancel)
                        // for (var i=0;typeof(orderdetails[i]) === 'object';i++)
                        // suborder.push(orderdetails[i])
                        // $scope.suborders = suborder;
                    },
                            function (response) {
                                console.log("Error response received  while getting Reason for cancellation ")
                                console.log(response)
                                var msg = errorcodesrv.checkcode(response.status)
                                if (msg !== "")
                                    var popupdata = msg
                                else
                                    var popupdata = "Error Response Received  While Getting Reason For Cancellation From Server"
                                $scope.popupopen('generalpopup', popupdata, $scope)
                                $scope.loading = false

                            })
        }
        // end of to get Reason for cancellation




        // Start of  storing the order to cancel  
        var arrayForTrackingVerifiedOrder = [];
        $scope.pushitemIndex = function (orderid, reasonOfCan, comment, status) {
            if (orderid && reasonOfCan) {
                arrayForTrackingVerifiedOrder.push({"orderid": orderid, "cancelreason": reasonOfCan, "cstatus": "CANINI", "comment": comment, "orderStatus": status})
                //console.log(arrayForTrackingVerifiedOrder)
            }

        }

        $scope.popitemIndex = function (orderid, reasonOfCan, comment) {
            var newArray = [];
            for (var i = 0; i < arrayForTrackingVerifiedOrder.length; i++) {
                // console.log(arrayForTrackingVerifiedOrder[i].index)
                if (arrayForTrackingVerifiedOrder[i].orderid === orderid)
                    continue
                else
                    newArray.push(arrayForTrackingVerifiedOrder[i])
            }
            arrayForTrackingVerifiedOrder = newArray;
            //console.log(arrayForTrackingVerifiedOrder)
        }

        // start of change cancel reason
        $scope.changecancelreason = function (orderid, reasonid, checkboxselected, comment, status) {
            //console.log(checkboxselected +"  "+ reasonid)
            if (typeof (reasonid) == 'undefined') {
                $scope.popitemIndex(orderid, reasonid, comment)
            }
            //console.log(checkboxselected +"  "+ reasonid)
            else if (typeof (checkboxselected) != 'undefined' && checkboxselected != false && orderNotAdded(orderid))
                arrayForTrackingVerifiedOrder.push({"orderid": orderid, "cancelreason": reasonid, "cstatus": "CANINI", "comment": comment, "orderStatus": status})
            if (arrayForTrackingVerifiedOrder.length > 0) {
                for (var i = 0; i < arrayForTrackingVerifiedOrder.length; i++) {
                    if (arrayForTrackingVerifiedOrder[i].orderid === orderid)
                        arrayForTrackingVerifiedOrder[i].cancelreason = reasonid
                }
            }
            //console.log(arrayForTrackingVerifiedOrder)
            if (reasonid != "" && reasonid != undefined) {
                $scope.loading = true;
                var path = "getcancelcharges";
                var data = {"orderid": orderid, "cancelreason": reasonid}
                authenticationSvc.login('POST', magento_ConstantApi.Apiendpoint, path, data)
                        .then(function (response) {
                            if (response.data[0].status == "success") {
                                $scope.get_cancel_charge = response.data[0].cancel_charge;
                                $scope.get_cancel_charge_without_handling = response.data[0].cancel_charge_without_handling;
                                $scope.get_handling_fee = response.data[0].handling_fee;
                                var popupdata = "The Cancellation charges are : INR " + response.data[0].cancel_charge;
                                $scope.popupopen('generalpopup', popupdata, $scope);
                            } else {
                                var popupdata = "Please enter valid data";
                                $scope.popupopen('generalpopup', popupdata, $scope);
                            }
                            $scope.loading = false;
                        }, function (response) {
                            var popupdata = "Error response received. Please try again in some time";
                            $scope.popupopen('generalpopup', popupdata, $scope);
                        })
            } else {
                var popupdata = "Please enter a valid cancel reason.";
                $scope.popupopen('generalpopup', popupdata, $scope);
            }
        }

        function orderNotAdded(orderid) {
            for (var i = 0; i < arrayForTrackingVerifiedOrder.length; i++) {
                if (arrayForTrackingVerifiedOrder[i].orderid === orderid)
                    return false
            }
            return true
        }
        // end  of change cancel reason

        //start of to disable cancel button
        $scope.checkarraylength = function () {
            if (arrayForTrackingVerifiedOrder.length > 0)
                return true
            else
                return false
        }
        //end of to disable cancel button

        $scope.resetArrayVerified = function () {
            arrayForTrackingVerifiedOrder = []
        }
        // end of storing the order to cancel



        // start of getting Priority 
        //$scope.priorityType = $scope.priority[1].priority_desc
        function priorityFun() {
            var data = {
                "luser": userInfosvc.returnUserInfo()[0].username,
                "lpasswd": userInfosvc.returnUserInfo()[0].pass,
                "request_data": "prioritylist",
                "application_name": "LeyKart",
                "depart_name": "L1 Support - Leykart"
            }
            //var path = OSTicket_ConstantApi.l1agenturlpath;
            //var header = OSTicket_ConstantApi.Header
            var path = Leykart_DatabaseConstant.osticketurl;
            //authenticationSvc.login('POST',OSTicket_ConstantApi.Apiendpoint,path,data,header)
            fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, path, 'l1agent', data)
                    .then(function (response) {
                        //console.log(response)
                        if (response.data == null || response.data == "") {
                            var msg = errorcodesrv.checkcode(response.status)
                            if (msg !== "")
                                var popupdata = msg
                            else
                                var popupdata = "There Is No  Help Topic To Display"
                            $scope.popupopen('generalpopup', popupdata, $scope)
                            //$scope.loading = false
                        } else {
                            $scope.priority = response.data
                            $scope.priorityType = response.data[1]
                        }
                    },
                            function (response) {
                                console.log("Error response received  while getting L2 and L3 details from os ticket ")
                                console.log(response)
                                var msg = errorcodesrv.checkcode(response.status)
                                if (msg !== "")
                                    var popupdata = msg
                                else
                                    var popupdata = "Error Response Received  While Getting Help Topics From Os Ticket "
                                $scope.popupopen('generalpopup', popupdata, $scope)
                            })
        }
        priorityFun()
        // end  of getting Priority 

        $scope.elementFocus('mobno')

        $scope.disableCreateTicketButton = function () {
            if ($scope.selectedIssueType) {
                if (($scope.selectedIssueType.issue_category == 'Select') ||
                        ($scope.selectedIssueType.issue_category == 'Cancel order' && checkArrayOfCancelOrders()) || ($scope.selectedIssueType.issue_category == 'Replacement/Return/Damage/short supply' && checkArrayOfCancelOrders()) || $scope.selectedIssueType.issue_category == 'Account modification') {
                    return true
                }
            }
        }
        //{"orderid":orderid,"cancelreason":reasonOfCan,"cstatus":"CANINI","comment":comment,"orderStatus":status}
        //selectedIssueType.issue_category == 'Select'
        function checkArrayOfCancelOrders() {
            if (arrayForTrackingVerifiedOrder.length == 0)
                return true;
            if (arrayForTrackingVerifiedOrder.length > 0) {
                for (let order of arrayForTrackingVerifiedOrder) {
                    if (order.reason_code == "")
                        return true
                }
            }

        }

    }])


app.controller('viewticketcntrl', ['$scope', '$q', '$filter', 'fetchdatabase', 'assignTransferTicketSrv', 'OSTicket_ConstantApi', 'authenticationSvc', 'userInfosvc', 'Leykart_DatabaseConstant', 'magento_ConstantApi', 'extractOrdernoSrv', 'errorcodesrv',
    function ($scope, $q, $filter, fetchdatabase, assignTransferTicketSrv, OSTicket_ConstantApi, authenticationSvc, userInfosvc, Leykart_DatabaseConstant, magento_ConstantApi, extractOrdernoSrv, errorcodesrv) {

        $scope.search = {"searchText": ''};
        var arrayForTrackingVerifiedOrder = []
        $scope.setnavshow(true);
        var dwnldTicketList;

        $scope.tickettype = "";

        //Start of  Setting Date
        var dateAsData = {"from_date": '', "to_date": ''}

        $scope.date = function (fromdate, todate) {
            if ($scope.tickettype == 'Open') {
                dateAsData.from_date = '';
                dateAsData.to_date = '';
            } else {
                dateAsData.from_date = fromdate.getFullYear() + '-' + (fromdate.getMonth() + 1) + '-' + fromdate.getDate() + ' ' + '00:00:00';
                dateAsData.to_date = todate.getFullYear() + '-' + (todate.getMonth() + 1) + '-' + todate.getDate() + ' ' + '23:59:59';
            }
            //console.log(dateAsData)
            $scope.ticketGo();
        }
        // end of setting the  Date

        // to fetch the table data
        $scope.ticketGo = function () {
            $scope.helpTopicFun().then(function (value) {
                if (value) {
                    if (dateAsData.from_date || $scope.tickettype == 'Open') {
                        $scope.loading = true
                        //console.log("staff id  "+userInfosvc.returnUserInfo()[0].staff_id)
                        var data = {
                            "luser": userInfosvc.returnUserInfo()[0].username,
                            "lpasswd": userInfosvc.returnUserInfo()[0].pass,
                            //"helptopic":"27", 
                            "helptopic": $scope.helpTopicId,
                            "ticket_number": "",
                            "status": "",
                            "staff_id": userInfosvc.returnUserInfo()[0].staff_id,
                            //"staff_id": "",
                            "from_date": dateAsData.from_date,
                            "to_date": dateAsData.to_date
                        }
                        //console.log(data)
                        //var path = OSTicket_ConstantApi.viewticketurlpath ;
                        var path = Leykart_DatabaseConstant.osticketurl;
                        //authenticationSvc.login('POST',OSTicket_ConstantApi.Apiendpoint, path, data, OSTicket_ConstantApi.Header)
                        fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, path, 'viewticket', data)
                                .then(function (response) {
                                    //console.log(response.data)

                                    if (response.data == 'null' || response.data == "") {
                                        var msg = errorcodesrv.checkcode(response.status)
                                        if (msg !== "")
                                            var popupdata = msg
                                        else
                                            var popupdata = "There Are No  Tickets To Display"
                                        $scope.ticketdetails = []
                                        $scope.popupopen('generalpopup', popupdata, $scope)
                                        $scope.loading = false
                                    } else {
                                        $scope.tabledata = response.data
                                        $scope.ticketdetails = response.data;
                                        $scope.loading = false
                                        $scope.ticketdetails = extractOrdernoSrv.extractorderno($scope.tabledata)
                                        //console.log($scope.ticketdetails)
                                        $scope.tabledata = extractOrdernoSrv.extractorderno($scope.tabledata)
                                        dwnldTicketList = $scope.tabledata;
                                        //console.log(dwnldTicketList)
                                    }

                                }, function (response) {
                                    console.log("Error response received  while getting ticket details from os ticket ")
                                    console.log(response)
                                    var msg = errorcodesrv.checkcode(response.status)
                                    if (msg !== "")
                                        var popupdata = msg
                                    else
                                        var popupdata = "Error Response Received  While Getting Ticket Details From Os Ticket "
                                    $scope.popupopen('generalpopup', popupdata, $scope)
                                    $scope.loading = false
                                })
                    } else {
                    }
                    //console.log("date not set")
                } else
                    console.log("error in getting helptopic")
            })


        }
        //$scope.ticketGo();

        // to filter the table data based on ticket no or order no
        $scope.filterRecords = function (searchText) {
            //console.log("called filterRecords")
            var basedOnTicketno = $filter('filter')($scope.tabledata, {ticket_number: searchText})
            var basedOnOrderno = $filter('filter')($scope.tabledata, {self_added_orderno: searchText})
            //$scope.ticketdetails = (basedOnTicketno.length <= 0) ? basedOnOrderno : basedOnTicketno
            $scope.ticketdetails = basedOnOrderno.concat(basedOnTicketno)
        }

        $scope.filterTicketType = function () {
            $scope.dateGo();
            dwnldTicketList = $filter('filter')($scope.tabledata, {status: $scope.tickettype})
            //console.log(dwnldTicketList)
        }
        $scope.calcualateAge = function (status, created, closed) {
            var created1 = new Date(created);
            var created2 = created1.getFullYear() + "-" + (created1.getMonth() + 1) + "-" + created1.getDate();
            var finalCreatedDate = new Date(created2);

            var closed1 = new Date(closed);
            var closed2 = closed1.getFullYear() + "-" + (closed1.getMonth() + 1) + "-" + closed1.getDate();
            var finalClosedDate = new Date(closed2);

            if (status == 'Open' || status == 'In-progress') {
                var endingDate = new Date();
                //var startingDate = new Date(created);   
                var timeDiff = Math.abs(finalCreatedDate.getTime() - endingDate.getTime());
                return(Math.ceil(timeDiff / (1000 * 3600 * 24)) - 1);
            } else if (status == 'Closed' || status == 'Resolved') {
                //var endingDate = new Date(closed);
                //var startingDate = new Date(created);
                var timeDiff = Math.abs(finalCreatedDate.getTime() - finalClosedDate.getTime());
                return(Math.ceil(timeDiff / (1000 * 3600 * 24)));
            } else {
                return '-';
            }

        }
        $scope.sendSmsCallCenter = function (mobileNumber, ticketNumber, modf) {
            if (modf == 1) {
                var today_date = new Date();
                var today = ((today_date.getDate() < 10) ? "0" : "") + today_date.getDate()
                        + "/" + (((today_date.getMonth() + 1) < 10) ? "0" : "")
                        + (today_date.getMonth() + 1) + "/" + today_date.getFullYear() + ", "
                        + ((today_date.getHours() < 10) ? "0" : "") + today_date.getHours()
                        + ":" + ((today_date.getMinutes() < 10) ? "0" : "") + today_date.getMinutes();
                var textmessage = "Thank you for contacting us. The reference no. for your Leykart query is (" + ticketNumber + "), registered on " + today + "."
                //"Dear <User>, request " + ticketNumber +" Created successfully. Thank you";
            }
            if (modf == 2) {
                //var textmessage = "Dear <User>, request " + ticketNumber +" Closed successfully. Thank you";
                var textmessage = "Dear <User>, Your Leykart query with reference no. (" + ticketNumber + ") has been resolved and closed successfully. Thank you";
            }

            var data = {"mobileNo": mobileNumber, "message": textmessage};

            /*fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, Leykart_DatabaseConstant.urlpath, 'sendSmsCallCenter',data)
             .then(function(response) {
             $scope.popupopen('generalpopup',JSON.stringify(response),$scope);
             }, function(response) {
             $scope.popupopen('generalpopup', JSON.stringify(response), $scope);
             }
             );*/
            var path = 'sendsmsforticket';
            authenticationSvc.login('POST', magento_ConstantApi.Apiendpoint, path, data)
                    .then(function (response) {
                        console.log(response);
                        //$scope.popupopen('generalpopup',JSON.stringify(response),$scope);
                    }, function (response) {
                        console.log(response);
                        //$scope.popupopen('generalpopup','test',$scope);
                    });
        }

        // start of   selece All functionality
        $scope.model = {
            selectedLabelList: []
        }
        $scope.isSelectAll = function () {
            //console.log("log")
            $scope.pushitemIndex(null, null, 'isSelectAll')
            $scope.model.selectedLabelList = [];
            if ($scope.master) {
                for (var i = 0; i < $scope.ticketdetails.length; i++) {
                    $scope.model.selectedLabelList.push($scope.ticketdetails[i].ticket_number);
                }
            }
            // else
            // $scope.master = false;

            for (var i = 0; i < $scope.ticketdetails.length; i++) {
                $scope.ticketdetails[i].selected = $scope.master
            }
        }

        $scope.isLabelChecked = function (checkboxValue) {
            if (checkboxValue)
                $scope.pushitemIndex(this.ticket, null, null)
            else
                $scope.popitemIndex(this.ticket, null)

            var _ticketno = this.ticket.ticket_number;
            if (this.ticket.selected) {
                $scope.model.selectedLabelList.push(_ticketno);
                if ($scope.model.selectedLabelList.length == $scope.ticketdetails.length)
                    $scope.master = true;
            } else {
                $scope.master = false;
                var index = $scope.model.selectedLabelList.indexOf(_ticketno);
                $scope.model.selectedLabelList.splice(index, 1);
            }

        }

        $scope.resetArrayVerified = function () {
            //console.log("called")
            arrayForTrackingVerifiedOrder = []
            //console.log(arrayForTrackingVerifiedOrder)
        }
        // End of  select All functionality


        // start of storing ticket which are to transfer and Assign 
        var arrayForTrackingVerifiedOrder = [];
        $scope.pushitemIndex = function (ticket, comment, functionCallFrom) {
            if (functionCallFrom === 'isSelectAll' && $scope.master == true) {
                arrayForTrackingVerifiedOrder = []
                for (var i = 0; i < $scope.ticketdetails.length; i++)
                    arrayForTrackingVerifiedOrder.push({'index': $scope.ticketdetails[i], 'comment': comment})
                //console.log(arrayForTrackingVerifiedOrder)
            }
            if (functionCallFrom === 'isSelectAll' && $scope.master == false) {
                arrayForTrackingVerifiedOrder = []
                //console.log(arrayForTrackingVerifiedOrder)
            }
            if (functionCallFrom == null) {
                arrayForTrackingVerifiedOrder.push({'index': ticket, 'comment': comment})
                //console.log(arrayForTrackingVerifiedOrder)
                $scope.selectedTicketLength = arrayForTrackingVerifiedOrder.length;
            }
        }

        $scope.popitemIndex = function (ticket, comment) {
            if ($scope.master == true)
                $scope.master = false
            var newArray = [];
            for (var i = 0; i < arrayForTrackingVerifiedOrder.length; i++) {
                // console.log(arrayForTrackingVerifiedOrder[i].index)
                if (arrayForTrackingVerifiedOrder[i].index.ticket_id === ticket.ticket_id)
                    continue
                else
                    newArray.push(arrayForTrackingVerifiedOrder[i])
            }
            arrayForTrackingVerifiedOrder = newArray;
            //console.log(arrayForTrackingVerifiedOrder)
            $scope.selectedTicketLength = arrayForTrackingVerifiedOrder.length;
        }
        // end of storing ticket which are to transfer and Assign 

        // start of transfer and assign ticket
        $scope.clicksubmit = function () {
            var calltype = ""
            $scope.loading = true
            //console.log(  "  called clickSubmit")
            //console.log($scope.selectedTicketLength)
            //var objct = assignTransferTicketSrv.ticketTransfer($scope,arrayForTrackingVerifiedOrder)
            //$scope.ticketdetails = objct.remainingticket
            //arrayForTrackingVerifiedOrder = [];
            //$scope.selectedTicketLength =  arrayForTrackingVerifiedOrder.length;

            // start of Assign ticket
            $scope.loading = true
            //console.log(arrayForTrackingVerifiedOrder)
            var ticketToTransferOrAssign = arrayForTrackingVerifiedOrder
            //var ticketToTransferOrAssign = objct.tickettobetransferOrAssign
            //var path = OSTicket_ConstantApi.updateticketurlpath;
            //var header = OSTicket_ConstantApi.Header
            //console.log($scope.transferTo)
            if ($scope.transferTo) {
                calltype = "transfer";
                //console.log("executed")
                for (var i = 0; i < ticketToTransferOrAssign.length; i++) {
                    ticketToTransferOrAssign[i].index.assignTo = {}
                    //console.log("executed")
                    ticketToTransferOrAssign[i].index.assignTo.staff_id = $scope.transferTo.staff_id
                }
            }
            //console.log($scope.assignTo)
            if ($scope.assignTo) {
                calltype = "assign";
                //console.log("executed")
                for (var i = 0; i < ticketToTransferOrAssign.length; i++) {
                    ticketToTransferOrAssign[i].index.assignTo = {}
                    ticketToTransferOrAssign[i].index.assignTo.staff_id = $scope.assignTo.staff_id
                }
            }
            $scope.ticketToTransferOrAssign = ticketToTransferOrAssign
            $scope.ticketTransfer(calltype, $scope)
                    .then(function (response) {
                        //console.log(response)
                        arrayForTrackingVerifiedOrder = [];
                        $scope.selectedTicketLength = []
                        $scope.loading = false
                        $scope.ticketGo()
                    }, function (response) {
                        //console.log(response)
                        $scope.loading = false;
                        //arrayForTrackingVerifiedOrder =[];
                        $scope.ticketGo()
                    })
        }

        // $scope.getcreatorindex =function(ticket){
        // 	var min=parseInt(ticket.event_info[0].id)+1
        // 	for(var i=0; i<ticket.event_info.length;i++){

        // 		if(ticket.event_info[i].id == min)
        // 			return i
        // 		//console.log(ticket.event_info)
        // 		//console.log("hello  " +i)
        // 	}
        // }
        $scope.ticketTransfer = function (calltype, $scope) {
            //console.log(" transfer function called")
            var data = [];
            var i = 0;

            var username = userInfosvc.returnUserInfo()[0].username
            var pass = userInfosvc.returnUserInfo()[0].pass
            var deferred = $q.defer();
            //console.log($scope.ticketToTransferOrAssign)	
            var count = 0
            //var path = OSTicket_ConstantApi.updateticketurlpath;
            //var header = OSTicket_ConstantApi.Header




            function iterateticket(i, calltype) {
                var typeofupdate = ""
                if (calltype === "assign") {
                    typeofupdate = "updateticketAssign"
                    data = {
                        "luser": username,
                        "lpasswd": pass,
                        "ticket_id": $scope.ticketToTransferOrAssign[i].index.ticket_id,
                        "update_type": "AssigntoStaff",
                        "message": "Assign ticket from API",
                        "assignto": $scope.ticketToTransferOrAssign[i].index.assignTo.staff_id
                                //"target_dept": ticketToTransferOrAssign[i].index.transferTo.staff_id
                    }
                } else if (calltype === "transfer") {
                    typeofupdate = "updateticketTransfer"
                    data = {
                        "luser": username,
                        "lpasswd": pass,
                        "ticket_id": $scope.ticketToTransferOrAssign[i].index.ticket_id,
                        "update_type": "Transfer",
                        //"message": "Assign ticket from API",
                        //"assignto": ticketToTransferOrAssign[i].index.assignTo.staff_id
                        "target_dept": $scope.transferTo.id
                    }
                }

                //console.log(data)
                //var count = 0
                var path = Leykart_DatabaseConstant.osticketurl;
                //authenticationSvc.login('POST',OSTicket_ConstantApi.Apiendpoint,path,data,header)
                fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, path, typeofupdate, data)
                        .then(function (response) {
                            if (response.data == 'true') {
                                //$scope.loading = false
                                i++;
                                //$scope.ticketdetails = objct.remainingticket
                                //console.log("Ticket assigned  or transfered successfully ")

                                //$scope.popupopen('generalpopup',popupdata,$scope)
                                //$scope.loading = false
                                // here we need to update our local data base also by changing the raised by
                                if (i == $scope.ticketToTransferOrAssign.length) {
                                    //console.log("Ticket assigned  or transfered successfully   " + i)

                                    $scope.loading = false
                                    if (calltype === "assign")
                                        var popupdata = "Ticket Assigned Successfully "
                                    else if (calltype === "transfer")
                                        var popupdata = "Ticket Transfered Successfully "
                                    $scope.popupopen('generalpopup', popupdata, $scope)
                                    deferred.resolve(true);
                                } else if (i < $scope.ticketToTransferOrAssign.length) {
                                    iterateticket(i, calltype)
                                }
                                //$scope.loading = false
                            }
                        },
                                function (response) {
                                    //$scope.ticketdetails = objct.remainingticket
                                    //$scope.loading = false
                                    console.log("Error response received  while Assigning or transfering  ticket  ")
                                    console.log(response)
                                    //var popupdata = response.statusText
                                    //$scope.popupopen('generalpopup',popupdata,$scope)
                                    deferred.reject(false);
                                })
                //setTimeout(function myFunction() {console.log('Timeout');}, 2000)
            }
            iterateticket(i, calltype)
            //console.log("outside function")

            return deferred.promise;


        }





        //end of transfer or assign the ticket

        // start of function for getting L1 agent names

        function l1agentnames() {
            var data = {
                "luser": userInfosvc.returnUserInfo()[0].username,
                "lpasswd": userInfosvc.returnUserInfo()[0].pass,
                "request_data": "L1UserAgent",
                "depart_name": "L1 Support - LeyKart"
            }
            //var path = OSTicket_ConstantApi.l1agenturlpath;
            //var header = OSTicket_ConstantApi.Header
            var path = Leykart_DatabaseConstant.osticketurl;
            //authenticationSvc.login('POST',OSTicket_ConstantApi.Apiendpoint,path,data,header)
            fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, path, 'l1agentOnly', data)
                    .then(function (response) {
                        if (response.data && response.data != "null") {
                            $scope.assignToList = response.data
                            $scope.assignToList.push({firstname: 'Select'})
                            $scope.assignTo = $scope.assignToList[$scope.assignToList.length - 1]
                            //$scope.assignTo ="Select"
                            //console.log(response.data)
                        }
                    },
                            function (response) {
                                console.log("Error response received  while getting L1 agent details from os ticket   ")
                                console.log(response)

                            })
        }
        l1agentnames()
        // end of function for getting L1 agent names

        // start of function for getting L2 And L3  Support names names
        function l2_3agentnames() {
            var data = {
                "luser": userInfosvc.returnUserInfo()[0].username,
                "lpasswd": userInfosvc.returnUserInfo()[0].pass,
                "request_data": "departmentList",
                "application_name": "LeyKart",
                "depart_name": "L1 Support - Leykart"

            }
            //var path = OSTicket_ConstantApi.l1agenturlpath;
            //var header = OSTicket_ConstantApi.Header
            var path = Leykart_DatabaseConstant.osticketurl;
            //authenticationSvc.login('POST',OSTicket_ConstantApi.Apiendpoint,path,data,header)
            fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, path, 'l1agent', data)
                    .then(function (response) {
                        //console.log(response.data)
                        $scope.transferToList = response.data
                        $scope.transferToList.push({name: 'Select'})
                        $scope.transferTo = $scope.transferToList[$scope.transferToList.length - 1]
                    },
                            function (response) {
                                console.log("Error response received  while getting L2 and L3 details from os ticket ")
                                console.log(response)

                            })
        }
        l2_3agentnames()

        // end of function forgetting L2 Nd L3 agent names

        // fetching ticket details from os ticket
        $scope.ticketdetail = function (name, ticketno, orderno) {
            //$scope.disableSubmit = tcktstatus == 'Closed'? true : false
            //$scope.posttype = 'Select'
            $scope.loading = true
            //var path = OSTicket_ConstantApi.viewticketurlpath ; 
            var data = {
                "luser": userInfosvc.returnUserInfo()[0].username,
                "lpasswd": userInfosvc.returnUserInfo()[0].pass,
                //"helptopic":"27",
                "helptopic": $scope.helpTopicId,
                "ticket_number": ticketno,
                "status": "",
                "staff_id": "",
                "from_date": "",
                "to_date": ""
            }
            var path = Leykart_DatabaseConstant.osticketurl;
            //authenticationSvc.login('POST',OSTicket_ConstantApi.Apiendpoint, path, data, OSTicket_ConstantApi.Header)
            fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, path, 'viewticket', data)
                    .then(function (response) {
                        //console.log(response.data[0])
                        $scope.ticketinfo = response.data[0]
                        $scope.popupopen('ticketdetails_viewticket', orderno, $scope)
                        $scope.loading = false
                    }, function (response) {
                        console.log("Error response received  while getting ticket details from os ticket ")
                        console.log(response)
                        $scope.loading = false
                    })
        } //end of  fetching ticket details from os ticket

        // start of  orderpopup for particular click of  order id
        $scope.orderOrsuborderpopupopen = function (popuptype, orderOrsuborderid) {
            if (orderOrsuborderid == "" || orderOrsuborderid == "NA" || orderOrsuborderid == undefined || orderOrsuborderid == null)
                return
            $scope.loading = true
            //console.log("called   "+orderOrsuborderid)
            //var path = magento_ConstantApi.orderdetailurlpath+orderOrsuborderid;
            //authenticationSvc.login('GET',magento_ConstantApi.Apiendpoint,path,null,magento_ConstantApi.Headers)
            var data = {"orderid": orderOrsuborderid}
            var path = 'orderdetailurlpath';
            authenticationSvc.login('POST', magento_ConstantApi.Apiendpoint, path, data)
                    .then(function (response) {
                        //console.log(response.data)
                        if (popuptype === "orderpopup") {
                            var suborder = []
                            $scope.orderdetails = response.data[0];
                            //console.log(response.data[0])
                            for (var i = 0; typeof (response.data[0][i]) === 'object'; i++)
                                suborder.push(response.data[0][i])
                            $scope.suborders = suborder;
                            $scope.showsearchbar = false;
                            $scope.popupopen(popuptype, response.data[0][0], $scope)
                            $scope.loading = false
                        }

                    },
                            function (response) {
                                console.log("Error response received  while getting sub order details ")
                                console.log(response)
                                var msg = errorcodesrv.checkcode(response.status)
                                if (msg !== "")
                                    var popupdata = msg
                                else
                                    var popupdata = "Error response received  while getting sub order details "
                                $scope.popupopen(popuptype, popupdata, $scope)
                                $scope.loading = false

                            })
        }
        // end of order pop up

        // Start   this function is called when submit button of ticket popup is clicked  
        $scope.ticketSubmit = function (ticketid, posttype, updatetype, message, ticketnumber = null) {
            var data = {}
            var typeofupdate = ""
            $scope.loading = true
            //console.log("ticketSubmit")
            //console.log(posttype)
            //console.log(updatetype)
            if (posttype != 'Select') {
                if (posttype === 'Reply') {
                    typeofupdate = "updateticketReply"
                    data = {
                        "luser": userInfosvc.returnUserInfo()[0].username,
                        "lpasswd": userInfosvc.returnUserInfo()[0].pass,
                        "ticket_id": ticketid,
                        "update_type": "Reply",
                        "message": message,
                        "status": "open"
                    }
                } else if (posttype === 'Note') {
                    typeofupdate = "updateticketNote"
                    data = {
                        "luser": userInfosvc.returnUserInfo()[0].username,
                        "lpasswd": userInfosvc.returnUserInfo()[0].pass,
                        "ticket_id": ticketid,
                        "update_type": "Note",
                        "title": "Title-2",
                        "message": message
                    }
                }
            } else if (updatetype != 'Select') {
                if (updatetype === 'Open') {
                    typeofupdate = "updateticketReply"
                    data = {
                        "luser": userInfosvc.returnUserInfo()[0].username,
                        "lpasswd": userInfosvc.returnUserInfo()[0].pass,
                        "ticket_id": ticketid,
                        "update_type": "Reply",
                        "message": message,
                        "status": "open"
                    }
                } else if (updatetype === 'Close') {
                    typeofupdate = "updateticketReply"
                    data = {
                        "luser": userInfosvc.returnUserInfo()[0].username,
                        "lpasswd": userInfosvc.returnUserInfo()[0].pass,
                        "ticket_id": ticketid,
                        "update_type": "Reply",
                        "message": message,
                        "status": "closed"
                    }
                } else if (updatetype === 'Resolve') {
                    typeofupdate = "updateticketReply"
                    data = {
                        "luser": userInfosvc.returnUserInfo()[0].username,
                        "lpasswd": userInfosvc.returnUserInfo()[0].pass,
                        "ticket_id": ticketid,
                        "update_type": "Reply",
                        "message": message,
                        "status": "resolved"
                    }
                }
            }
            //var path = OSTicket_ConstantApi.updateticketurlpath ;
            $scope.$broadcast('ticketsubmitEvent', {obj: 'please close the popup event!'}) // send whatever you want
            //$scope.popupclose()
            //$scope.popupclose()
            var path = Leykart_DatabaseConstant.osticketurl;
            //authenticationSvc.login('POST',OSTicket_ConstantApi.Apiendpoint, path, data, OSTicket_ConstantApi.Header)
            fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, path, typeofupdate, data)
                    .then(function (response) {
                        //console.log(response)
                        if (response.status == 201)
                            //console.log("succesfully replied or noted for the ticket")
                            $scope.loading = false
                        $scope.ticketGo();
                        var popupdata = "Ticket Updated Successfully";
                        //sending sms to customer while closing the ticket
                        if (updatetype === 'Close') {
                            $scope.sendSMSforClosingTicket(ticketnumber);
                        }
                        $scope.popupopen('generalpopup', popupdata, $scope)
                    }, function (response) {
                        console.log("Error response received  from os ticket while updating ticket  ")
                        console.log(response)
                        var msg = errorcodesrv.checkcode(response.status)
                        if (msg !== "")
                            var popupdata = msg
                        else
                            var popupdata = "Error response received  from os ticket while updating ticket "
                        $scope.popupopen('generalpopup', popupdata, $scope)
                        // firing an event downwards ie to close model by calling popupcntrl  watch function
                        //$scope.$broadcast('ticketsubmitEvent', {obj: 'please close the popup event!'})   // send whatever you want
                        $scope.loading = false
                    })



        } // end of ticketSubmit for popup ticket
        $scope.sendSMSforClosingTicket = function (ticketnumber) {
            var getTicketdata = {
                "luser": userInfosvc.returnUserInfo()[0].username,
                "lpasswd": userInfosvc.returnUserInfo()[0].pass,
                //"helptopic":"27",
                "helptopic": $scope.helpTopicId,
                "ticket_number": ticketnumber,
                "status": "",
                "staff_id": "",
                "from_date": "",
                "to_date": ""
            }
            var path = Leykart_DatabaseConstant.osticketurl;
            fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, path, 'viewticket', getTicketdata)
                    .then(function (response) {
                        var customer_mobile_number = response.data[0].phone;
                        $scope.sendSmsCallCenter(customer_mobile_number, ticketnumber, 2);

                    }, function (response) {
                        console.log("Error response received  while getting ticket details from os ticket ")
                        console.log(response)

                    })
        }

        // Start   this function is called when close button of ticket popup is clicked  
        $scope.closeTicket = function (ticketid, message) {
            var data = {}
            $scope.loading = true
            //console.log("ticketclosed")
            data = {
                "luser": userInfosvc.returnUserInfo()[0].username,
                "lpasswd": userInfosvc.returnUserInfo()[0].pass,
                "ticket_id": ticketid,
                "update_type": "Reply",
                "message": message,
                "status": "closed"
            }
            //var path = OSTicket_ConstantApi.updateticketurlpath ;
            //$scope.$broadcast('ticketsubmitEvent', {obj: 'please close the popup event!'}) // send whatever you want
            $scope.popupclose()
            var path = Leykart_DatabaseConstant.osticketurl;
            //authenticationSvc.login('POST',OSTicket_ConstantApi.Apiendpoint, path, data, OSTicket_ConstantApi.Header)
            fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, path, 'updateticketReply', data)
                    .then(function (response) {
                        //console.log(response)
                        if (response.status == 201)
                            //console.log("succesfully closed  the ticket")
                            $scope.loading = false
                        $scope.ticketGo();
                        var popupdata = "Ticket Closed Successfully"
                        $scope.popupopen('generalpopup', popupdata, $scope)
                    }, function (response) {
                        console.log("Error Response Received  From Os Ticket While Closing The ticket  ")
                        console.log(response)
                        var msg = errorcodesrv.checkcode(response.status)
                        if (msg !== "")
                            var popupdata = msg
                        else
                            var popupdata = "Error Response Received  From Os Ticket While Closing The ticket "
                        $scope.popupopen('generalpopup', popupdata, $scope)
                        // firing an event downwards ie to close model by calling popupcntrl  watch function
                        //$scope.$broadcast('ticketsubmitEvent', {obj: 'please close the popup event!'})   // send whatever you want
                        $scope.loading = false
                    })



        } // end of ticketclose for popup ticket

        // download ticket as excel
        $scope.downloadUsersList = function () {
            //console.log("called")
            var excellist = []
            $scope.tempList = dwnldTicketList;
            angular.forEach($scope.tempList, function (item) {
                var tempItem = {};
                Object.assign(tempItem, item);
                /*            angular.forEach(tempItem.event_info,function(jsonItem){
                 angular.forEach(jsonItem,function(value,key){
                 tempItem[key]=value;
                 });
                 })*/
                tempItem['caller_name'] = tempItem['enduser_name']
                delete(tempItem.enduser_name)
                var check = -1;
                angular.forEach(tempItem.timeline, function (jsonItem) {
                    angular.forEach(jsonItem, function (value, key) {
                        if (key == 'poster') {
                            check += 1;
                            if (check == 1) {
                                tempItem['Raised by'] = value;
                            }
                        }
                    });
                })
                tempItem['Last Attended By'] = tempItem.timeline.length - 1 == 0 ? 'NA' : tempItem.timeline[tempItem.timeline.length - 1].poster
                tempItem['Last Attended Date'] = tempItem.timeline[tempItem.timeline.length - 1].created
                delete(tempItem.event_info)
                delete(tempItem.timeline)
                delete(tempItem.user_id)
                //item.est_duedate= new Date(Date.parse(item.est_duedate));
                //item.created= new Date(Date.parse(item.created));
                excellist.push(tempItem)
            });
            $scope.downloadExcel(excellist, $scope.tickettype ? 'ticketList_' + $scope.tickettype : 'ticketList_All')
        }


    }])


app.controller('viewallordercntrl', ['$scope', '$filter', 'fetchdatabase', '$timeout', 'authenticationSvc', 'magento_ConstantApi', 'errorcodesrv', 'Leykart_DatabaseConstant', 'userInfosvc',
    function ($scope, $filter, fetchdatabase, $timeout, authenticationSvc, magento_ConstantApi, errorcodesrv, Leykart_DatabaseConstant, userInfosvc) {

        $scope.downloadOrderList = function () {

            //console.log("called")
            var load = document.getElementById("loading");
            load.style.visibility = "visible";
            $scope.orderlist = [];
            angular.forEach($scope.viewallorders, function (val, key) {
                $scope.orderlist.push({"Order Date": val.order_date, "Sub-order ID": val.suborder_id, "Order Type": val.order_type, "Status": val.suborder_status,
                    "SKU Number": val.sku_no, "SKU Name": val.sku_name, "Seller Name": val.seller_name, "Seller ID": val.seller_id,
                    "Expected Delivery Date": val.expected_arrival, "delivered_date": val.delivered_date, "delay_days": val.delay_days,
                    "State": val.state, "City": val.city, "Seller Mobile": val.seller_mobile, "Call Count": val.call_count, "Last Call Status": val.call_status, "Comments": val.comments});


            });
            $scope.downloadExcel($scope.orderlist, 'Orderlist');
            load.style.visibility = "hidden";
        }

        $scope.selectedItemvalue = '';
        $scope.selectedOrderStatus = 'all';
        $scope.switchOrderType = function (val) {
            var load = document.getElementById("loading");
            load.style.visibility = "visible";
            $scope.orderlist = [];
            $scope.selectedItemvalue = val;
            var selected_order_status = '';
            if ($scope.selectedOrderStatus != 'all') {
                selected_order_status = $scope.selectedOrderStatus;
            }
            $scope.viewallorders = $filter('filter')($scope.tabledata, {'order_type': $scope.selectedItemvalue, 'suborder_status': selected_order_status});

            load.style.visibility = "hidden";
            //console.log("called")

        }

        $scope.switchOrderStatus = function (val) {
            var load = document.getElementById("loading");
            load.style.visibility = "visible";
            $scope.selectedOrderStatus = val;
            if (val == 'all')
                val = '';
            $scope.viewallorders = $filter('filter')($scope.tabledata, {'suborder_status': val, 'order_type': $scope.selectedItemvalue});
            load.style.visibility = "hidden";
        }
        var pageid = $scope.bigCurrentPage;
        $scope.setComments = function (order) {
            var load = document.getElementById("loading");
            load.style.visibility = "visible";

            fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, Leykart_DatabaseConstant.urlpath, 'setverifystatus', {"module": "viewallordercomments", "order": order, "type": "upd"}).then(function (response) {
                var comments = "Comment Updated."
                $scope.popupopen('generalpopup', comments, $scope);
                $scope.viewallorderdetails(pageid, fromdate, todate);
                //$scope.loading=false;
                load.style.visibility = "hidden";
            });


        }
        $scope.setnavshow(true);
        var data = {
            "luser": userInfosvc.returnUserInfo()[0].username,
            "lpasswd": userInfosvc.returnUserInfo()[0].pass,
            "request_data": "helptopic",
            "application_name": "LeyKart",
            "depart_name": "L1 Support - Leykart"
        }
        $scope.getVerifyStatus = function () {
            fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, Leykart_DatabaseConstant.urlpath, 'getverifystatus', null).then(function (response) {
                $scope.verifyStatus = response.data;
            });
        }
        $scope.getVerifyStatus();
        $scope.setVerifyStatus = function (order, module = "viewallorder") {
            var load = document.getElementById("loading");
            load.style.visibility = "visible";
            if (order.selected_status != "" && order.selected_status != null && order.selected_status != undefined) {
                fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, Leykart_DatabaseConstant.urlpath, 'setverifystatus', {"module": module, "order": order, "type": "upd"}).then(function (response) {
                    var popupdata = "Call Status Updated."
                    $scope.popupopen('generalpopup', popupdata, $scope);
                    $scope.viewallorderdetails();
                    //$scope.loading=false;
                    load.style.visibility = "hidden";
                });
            } else {
                var popupdata = "Select a valid status and try again"
                $scope.popupopen('generalpopup', popupdata, $scope);
                //$scope.loading=false;
                load.style.visibility = "hidden";
        }

        }
        $scope.cancelCharges = null;
        $scope.getHelpTopicId = function () {
            var path = Leykart_DatabaseConstant.osticketurl;
            fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, path, 'l1agent', data)
                    .then(function (response) {
                        //console.log(response)
                        if (response.data == null || response.data == "") {
                            var msg = errorcodesrv.checkcode(response.status)
                            if (msg !== "")
                                var popupdata = msg
                            else
                                var popupdata = "There Is No  Help Topic To Display"
                            $scope.popupopen('generalpopup', popupdata, $scope)
                            $scope.loading = false
                        } else {
                            $scope.helpTopicId = response.data[0].topic_id
                            $scope.loading = false
                        }
                        //deferred.resolve(true);
                    },
                            function (response) {
                                console.log("Error response received  while getting L2 and L3 details from os ticket ")
                                console.log(response)
                                var msg = errorcodesrv.checkcode(response.status)
                                if (msg !== "")
                                    var popupdata = msg
                                else
                                    var popupdata = "Error Response Received  While Getting Help Topics From Os Ticket "
                                $scope.popupopen('generalpopup', popupdata, $scope)
                                //deferred.reject(false);
                            })
            //return deferred.promise;
        }
        $scope.getHelpTopicId();
        //Start of  setting and fetching the  Date
        var dateAsData = {
            "from_date": '',
            "to_date": '',
            "status": "",
            "page_num": '',
        }
        $scope.getCancelCharge = function (orderid, reasonid) {
            var path = "getcancelcharges";
            $scope.cancelCharges = null;
            if (reasonid != null || reasonid != "" || reasonid != undefined) {
                var data = {"orderid": orderid, "cancelreason": reasonid}
                authenticationSvc.login('POST', magento_ConstantApi.Apiendpoint, path, data)
                        .then(function (response) {
                            if (response.data[0].status == "success") {
                                $scope.get_cancel_charge = response.data[0].cancel_charge;
                                $scope.get_cancel_charge_without_handling = response.data[0].cancel_charge_without_handling;
                                $scope.get_handling_fee = response.data[0].handling_fee;
                                $scope.cancelCharges = response.data[0].cancel_charge;
                                //$scope.popupopen('generalpopup',popupdata,$scope);
                            } else {
                                //var popupdata="Please enter valid data";
                                //$scope.popupopen('generalpopup',popupdata,$scope);
                            }
                            $scope.loading = false;
                        }, function (response) {
                            var popupdata = "Error response received. Please try again in some time";
                            $scope.popupopen('generalpopup', popupdata, $scope);
                        })
            } else {
                var popupdata = "Please enter a valid cancel reason.";
                $scope.popupopen('generalpopup', popupdata, $scope);
            }
        }
        $scope.sendSmsCallCenter = function (mobileNumber, ticketNumber, modf) {
            if (modf == 1) {
                var today_date = new Date();
                var today = ((today_date.getDate() < 10) ? "0" : "") + today_date.getDate()
                        + "/" + (((today_date.getMonth() + 1) < 10) ? "0" : "")
                        + (today_date.getMonth() + 1) + "/" + today_date.getFullYear() + ", "
                        + ((today_date.getHours() < 10) ? "0" : "") + today_date.getHours()
                        + ":" + ((today_date.getMinutes() < 10) ? "0" : "") + today_date.getMinutes();
                var textmessage = "Thank you for contacting us. The reference no. for your Leykart query is (" + ticketNumber + "), registered on " + today + "."
                //"Dear <User>, request " + ticketNumber +" Created successfully. Thank you";
            }
            if (modf == 2) {
                //var textmessage = "Dear <User>, request " + ticketNumber +" Closed successfully. Thank you";
                var textmessage = "Dear <User>, Your Leykart query with reference no. (" + ticketNumber + ") has been resolved and closed successfully. Thank you";
            }

            var data = {"mobileNo": mobileNumber, "message": textmessage};
            /*fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, Leykart_DatabaseConstant.urlpath, 'sendSmsCallCenter',data)
             .then(function(response) {
             $scope.popupopen('generalpopup',JSON.stringify(response),$scope);
             }, function(response) {
             $scope.popupopen('generalpopup', JSON.stringify(response), $scope);
             }
             );*/
            var path = 'sendsmsforticket';
            authenticationSvc.login('POST', magento_ConstantApi.Apiendpoint, path, data)
                    .then(function (response) {
                        console.log(response);
                        //$scope.popupopen('generalpopup',JSON.stringify(response),$scope);
                    }, function (response) {
                        console.log(response);
                        //$scope.popupopen('generalpopup','test',$scope);
                    });
        }
        $scope.createticket = function (tickettype, order) {
            var loading = document.getElementById("loading");
            loading.style.visibility = "visible";
            var notif = document.getElementById("notif");
            var ticket = document.getElementById("ticket");
            ticket.style.visibility = "hidden";
            var para = document.createElement("P");
            var t = document.createTextNode("Loading...");
            para.appendChild(t);
            notif.appendChild(para);
            notif.style.visibility = "visible";
            var possible = null;
            var data;
            if (tickettype == 'Account modification') {
                data = {
                    "name": $scope.selectedOrder.customer_name,
                    "email": $scope.selectedOrder.customer_email,
                    "phone": $scope.selectedOrder.customer_mobile,
                    "subject": tickettype + "#NA",
                    "message": "Name: " + $scope.selectedOrder.customer_name + ", Email: " + $scope.selectedOrder.customer_email + ", Mobile: " + $scope.selectedOrder.customer_mobile + ", Address: " + $scope.selectedOrder.customer_address + ", SAP ID: " + $scope.selectedOrder.sapid
                            + ", DBM ID: " + $scope.selectedOrder.dbmid + ", GST Number: " + $scope.selectedOrder.gstno,
                    // "ip"  : '125.22.193.148',
                    "topicId": $scope.helpTopicId, // 27
                    "laykartappsubcategory": tickettype,
                    "TicketType": "Operations",
                    "priority": "2"
                }
            } else if (tickettype == 'Part Listing') {
                data = {
                    "name": $scope.selectedOrder.customer_name,
                    "email": $scope.selectedOrder.customer_email,
                    "phone": $scope.selectedOrder.customer_mobile,
                    "subject": tickettype + "#NA",
                    "message": "Name : " + $scope.selectedOrder.customer_name + " | Email : " + $scope.selectedOrder.customer_email + " | Mobile No : " + $scope.selectedOrder.customer_mobile + " | Address : " + $scope.selectedOrder.customer_address + " | Part number: " + $scope.selectedOrder.partNumber + " | Chassis Number :" + $scope.selectedOrder.chassisNumber + " | Model number : " + $scope.selectedOrder.modelNumber + " | Registration Number : " + $scope.selectedOrder.registrationNumber + " | Aggregate : " + $scope.selectedOrder.aggregate,
                    // "ip"  : '125.22.193.148',
                    "topicId": $scope.helpTopicId, // 27
                    "laykartappsubcategory": "Part Listing",
                    "TicketType": "Operations",
                    "priority": "2"
                };
            } else if (tickettype == 'Cancel order' || tickettype == 'Replacement/Return/Damage/short supply') {
                if ($scope.selectedIssueType.selected.issue_category == "Replacement/Return/Damage/short supply" && $scope.selectedOrder.suborder_status != 'Delivered') {
                    possible = null;
                } else if ($scope.selectedReason.selected.reason_code == 'LA' || $scope.selectedReason.selected.reason_code == 'LB') {
                    if ($scope.selectedOrder.suborder_status == 'Order Placed' || $scope.selectedOrder.suborder_status == 'Packed' || $scope.selectedOrder.suborder_status == 'In transit' || $scope.selectedOrder.suborder_status == 'Shipped') {
                        possible = true;
                    } else if ($scope.selectedOrder.suborder_status == 'Delivered') {
                        possible = true;
                    } else {
                        possible = null;
                    }
                } else if ($scope.selectedReason.selected.reason_code == 'LE' || $scope.selectedReason.selected.reason_code == 'LF' || $scope.selectedReason.selected.reason_code == 'LO' || $scope.selectedReason.selected.reason_code == 'LM' || $scope.selectedReason.selected.reason_code == 'LN') {
                    if ($scope.selectedOrder.suborder_status == 'Packed' || $scope.selectedOrder.suborder_status == 'In transit' || $scope.selectedOrder.suborder_status == 'Shipped') {
                        possible = true;
                    } else if ($scope.selectedOrder.suborder_status == 'Delivered') {
                        possible = true;
                    } else {
                        possible = null;
                    }
                } else if ($scope.selectedReason.selected.reason_code == 'LC' || $scope.selectedReason.selected.reason_code == 'LD') {
                    if ($scope.selectedOrder.suborder_status == 'Order Placed' || $scope.selectedOrder.suborder_status == 'Packed' || $scope.selectedOrder.suborder_status == 'In transit' || $scope.selectedOrder.suborder_status == 'Shipped') {
                        var tday = new Date();
                        var tday_1 = tday.getFullYear() + '-' + tday.getMonth() + '-' + tday.getDate();
                        $scope.selectedOrder.expected_arrival = new Date($scope.selectedOrder.expected_arrival);
                        if (tday > $scope.selectedOrder.expected_arrival) {
                            possible = true;
                        } else {
                            possible = null;
                        }
                    } else if ($scope.selectedOrder.suborder_status == 'Delivered') {
                        possible = true;
                    } else {
                        possible = null;
                    }
                } else if ($scope.selectedReason.selected.reason_code == 'LG' || $scope.selectedReason.selected.reason_code == 'LH') {
                    if ($scope.selectedOrder.suborder_status == 'Delivered') {
                        possible = true;
                    } else {
                        possible = null;
                    }
                } else if ($scope.selectedReason.selected.reason_code == 'LK') {
                    if ($scope.selectedOrder.suborder_status == 'Delivered') {
                        possible = true;
                    } else {
                        possible = null;
                    }
                } else if ($scope.selectedReason.selected.reason_code == 'LI' || $scope.selectedReason.selected.reason_code == 'LJ' || $scope.selectedReason.selected.reason_code == 'LL') {
                    if ($scope.selectedOrder.suborder_status == 'Delivered') {
                        possible = true;
                    } else {
                        possible = null;
                    }
                }
                if (possible == null) {
                    $scope.notif = "Cancellation not applicable. Please check."
                } else if (possible == true) {
                    data = {"order": [{
                                "orderid": $scope.selectedOrder.ref_incr_id,
                                "cancelreason": $scope.selectedReason.selected.reason_code,
                                "cstatus": "CANINI",
                                "comment": order.comment
                            }]}
                    var path = 'initiatecancelurlpath';
                    authenticationSvc.login('POST', magento_ConstantApi.Apiendpoint, path, data)
                            .then(function (response) {
                                //console.log(response)
                                //var orderno = response.config.data.order[0].orderid
                                //var cancellation_charge=response.data[0][0].orderdetails.cancellation_charge;
                                var orderno = response.data[0][0].orderdetails.message.order_id
                                //console.log(response.data[0][0].orderdetails.error_code)
                                //console.log(response.data[0][0].orderdetails.status)
                                if (response.data[0][0].orderdetails.error_code == 0) {
                                    //console.log("Successfully initiated cancellation for the order no " +orderno)
                                    popupdata = "Successfully Initiated Cancellation For The Order No " + orderno;
                                    //$scope.popupopen('generalpopup',popupdata,$scope)
                                    // creating ticket for the order whose  cancellation has been initiate
                                    //let subject = "Order Cancellation for order no "+orderno;
                                    let subject = tickettype + "#" + orderno;
                                    data = {
                                        "name": $scope.selectedOrder.customer_name,
                                        "email": $scope.selectedOrder.customer_email,
                                        "phone": $scope.selectedOrder.customer_mobile,
                                        "subject": subject,
                                        "message": $scope.selectedOrder.comment || 'No Comments',
                                        // "ip"  : '125.22.193.148',
                                        "topicId": $scope.helpTopicId, // 27
                                        "laykartappsubcategory": tickettype,
                                        "TicketType": "Operations",
                                        "priority": "2"
                                    }
                                    var path = Leykart_DatabaseConstant.osticketurl;
                                    fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, path, 'createticket', data)
                                            .then(function (response) {
                                                //console.log(response)
                                                //console.log("ticketNo  received from os ticket")
                                                //$scope.loading =false
                                                if (response.data[0] != null) {
                                                    //alert("Ticket created in os ticket with ticket no " + response.data)
                                                    //popupdata = popupdata+"\n.Ticket created  with ticket no " + response.data[0]
                                                    //$scope.popupopen('generalpopup',popupdata,$scope)
                                                    //console.log("Ticket created in os ticket with ticket no  " + response.data)

                                                    //var path = OSTicket_ConstantApi.viewticketurlpath ; 
                                                    var data = {
                                                        "luser": userInfosvc.returnUserInfo()[0].username,
                                                        "lpasswd": userInfosvc.returnUserInfo()[0].pass,
                                                        //"helptopic":"27", 
                                                        "helptopic": $scope.helpTopicId,
                                                        "ticket_number": response.data[0],
                                                        "status": "",
                                                        "staff_id": "",
                                                        "from_date": "",
                                                        "to_date": ""
                                                    }
                                                    var createdTicketNumber = response.data[0];
                                                    $scope.sendSmsCallCenter($scope.selectedOrder.customer_mobile, createdTicketNumber, 1);
                                                    //console.log(data)
                                                    // callimg os ticket to fetch ticket details
                                                    var path = Leykart_DatabaseConstant.osticketurl;
                                                    //authenticationSvc.login('POST',OSTicket_ConstantApi.Apiendpoint, path, data, OSTicket_ConstantApi.Header)
                                                    fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, path, 'viewticket', data)
                                                            .then(function (response) {
                                                                //console.log(response)
                                                                // calling transfer function to transfer ticket to that person

                                                                // these 5 lines is comented for time being

                                                                $scope.assignTo = {}
                                                                $scope.assignTo.staff_id = userInfosvc.returnUserInfo()[0].staff_id
                                                                $scope.ticketToTransferOrAssign = []
                                                                $scope.ticketToTransferOrAssign.push({'index': response.data[0]})
                                                                var data = {
                                                                    "luser": userInfosvc.returnUserInfo()[0].username,
                                                                    "lpasswd": userInfosvc.returnUserInfo()[0].pass,
                                                                    "ticket_id": response.data[0].ticket_id,
                                                                    "update_type": "AssigntoStaff",
                                                                    "message": "Assign ticket from API",
                                                                    "assignto": userInfosvc.returnUserInfo()[0].staff_id
                                                                }
                                                                //console.log(data)
                                                                //var count = 0
                                                                var path = Leykart_DatabaseConstant.osticketurl;
                                                                //authenticationSvc.login('POST',OSTicket_ConstantApi.Apiendpoint,path,data,header)
                                                                fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, path, 'updateticketAssign', data)
                                                                        .then(function (response) {
                                                                            if (response.data == 'true') {
                                                                                notif.removeChild(notif.lastChild)
                                                                                var para = document.createElement("P");
                                                                                var t = document.createTextNode("Ticket " + createdTicketNumber + " created.");
                                                                                para.appendChild(t);
                                                                                notif.appendChild(para);
                                                                                loading.style.visibility = "hidden";
                                                                            }
                                                                        });
                                                            })
                                                }
                                            })
                                }
                            });
                }
            } else {
                data = {
                    "name": $scope.selectedOrder.customer_name,
                    "email": $scope.selectedOrder.customer_email,
                    "phone": $scope.selectedOrder.customer_mobile,
                    "subject": tickettype + "#NA",
                    "message": $scope.selectedOrder.comment || 'No Comments',
                    // "ip"  : '125.22.193.148',
                    "topicId": $scope.helpTopicId, // 27
                    "laykartappsubcategory": tickettype,
                    "TicketType": "Operations",
                    "priority": "2"
                }
            }
            if (tickettype != "Select" && tickettype != "Cancel order" && tickettype != "Replacement/Return/Damage/short supply") {
                var path = Leykart_DatabaseConstant.osticketurl;
                //authenticationSvc.login('POST',OSTicket_ConstantApi.Apiendpoint, path, data, OSTicket_ConstantApi.Header)
                fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, path, 'createticket', data)
                        .then(function (response) {
                            //console.log(response)
                            //console.log("ticketNo  received from os ticket")
                            //$scope.loading =false
                            if (response.data[0] != null) {
                                //alert("Ticket created in os ticket with ticket no " + response.data)
                                //popupdata = popupdata+"\n.Ticket created  with ticket no " + response.data[0]
                                //$scope.popupopen('generalpopup',popupdata,$scope)
                                //console.log("Ticket created in os ticket with ticket no  " + response.data)

                                //var path = OSTicket_ConstantApi.viewticketurlpath ; 
                                var data = {
                                    "luser": userInfosvc.returnUserInfo()[0].username,
                                    "lpasswd": userInfosvc.returnUserInfo()[0].pass,
                                    //"helptopic":"27", 
                                    "helptopic": $scope.helpTopicId,
                                    "ticket_number": response.data[0],
                                    "status": "",
                                    "staff_id": "",
                                    "from_date": "",
                                    "to_date": ""
                                }
                                var createdTicketNumber = response.data[0];
                                $scope.sendSmsCallCenter($scope.selectedOrder.customer_mobile, createdTicketNumber, 1);
                                //console.log(data)
                                // callimg os ticket to fetch ticket details
                                var path = Leykart_DatabaseConstant.osticketurl;
                                //authenticationSvc.login('POST',OSTicket_ConstantApi.Apiendpoint, path, data, OSTicket_ConstantApi.Header)
                                fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, path, 'viewticket', data)
                                        .then(function (response) {
                                            //console.log(response)
                                            // calling transfer function to transfer ticket to that person

                                            // these 5 lines is comented for time being

                                            $scope.assignTo = {}
                                            $scope.assignTo.staff_id = userInfosvc.returnUserInfo()[0].staff_id
                                            $scope.ticketToTransferOrAssign = []
                                            $scope.ticketToTransferOrAssign.push({'index': response.data[0]})
                                            var data = {
                                                "luser": userInfosvc.returnUserInfo()[0].username,
                                                "lpasswd": userInfosvc.returnUserInfo()[0].pass,
                                                "ticket_id": response.data[0].ticket_id,
                                                "update_type": "AssigntoStaff",
                                                "message": "Assign ticket from API",
                                                "assignto": userInfosvc.returnUserInfo()[0].staff_id
                                            }
                                            //console.log(data)
                                            //var count = 0
                                            var path = Leykart_DatabaseConstant.osticketurl;
                                            //authenticationSvc.login('POST',OSTicket_ConstantApi.Apiendpoint,path,data,header)
                                            fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, path, 'updateticketAssign', data)
                                                    .then(function (response) {
                                                        if (response.data == 'true') {
                                                            notif.removeChild(notif.lastChild)
                                                            var para = document.createElement("P");
                                                            var t = document.createTextNode("Ticket " + createdTicketNumber + " created.");
                                                            para.appendChild(t);
                                                            notif.appendChild(para);
                                                            loading.style.visibility = "hidden";
                                                        }
                                                    });
                                        })
                            }
                        })
            }
        }
        $scope.disableCreateTicketButton = function () {
            return ($scope.selectedIssueType.selected.issue_category == 'Select' || $scope.selectedIssueType.selected.issue_category == undefined) || ($scope.selectedIssueType.selected.issue_category == "Cancel order" && (($scope.selectedReason.selected.reason_description == 'Select' || $scope.selectedReason.selected.reason_description == undefined) || ($scope.selectedOrder.suborder_status.indexOf('Cancel') > -1))) || ($scope.selectedIssueType.selected.issue_category == "Replacement/Return/Damage/short supply" && (($scope.selectedOrder.suborder_status != "Delivered") || (($scope.selectedReason.selected.reason_description == 'Select' || $scope.selectedReason.selected.reason_description == undefined) || ($scope.selectedOrder.suborder_status.indexOf('Return') > -1)))) || ($scope.selectedIssueType.selected.issue_category == "Cancel order" && $scope.selectedOrder.suborder_status == "Delivered") || ($scope.selectedIssueType.selected.issue_category == "Replacement/Return/Damage/short supply" && $scope.selectedOrder.suborder_status != "Delivered")

            /*($scope.selectedIssueType.selected.issue_category=='Select'||$scope.selectedIssueType.selected.issue_category==undefined)||(($scope.selectedIssueType.selected.issue_category=='Cancel order' && (($scope.selectedReason.selected.reason_description=='Select'||$scope.selectedReason.selected.reason_description==undefined))&&($scope.selectedOrder.suborder_status.indexOf('Cancel')>-1||$scope.selectedOrder.suborder_status.indexOf('Return')>-1))||($scope.selectedIssueType.selected.issue_category=='Replacement/Return/Damage/short supply' && (($scope.selectedReason.selected.reason_description=='Select'||$scope.selectedReason.selected.reason_description==undefined))&&($scope.selectedOrder.suborder_status.indexOf('Cancel')>-1||$scope.selectedOrder.suborder_status.indexOf('Return')>-1)))*/
        }
        $scope.selectedIssueType = {selected: {}};
        $scope.selectedReason = {selected: {}};
        function reasonForCancellation() {
            //console.log("called reasonForCancellation")
            //var path = magento_ConstantApi.getcancelreasonurlpath;
            //authenticationSvc.login('GET',magento_ConstantApi.Apiendpoint,path,null,magento_ConstantApi.Headers)
            var data = {
                user_role: $scope.getUserRole()
            }
            var path = 'getcancelreasonurlpath';
            authenticationSvc.login('POST', magento_ConstantApi.Apiendpoint, path, data)
                    .then(function (response) {
                        //console.log( response.data[0])
                        if (response.data[0] == null || response.data[0] == "") {
                            var msg = errorcodesrv.checkcode(response.status)
                            if (msg !== "")
                                var popupdata = msg
                            else
                                var popupdata = "Didnt Receive Any Detail From Server"
                            $scope.popupopen('generalpopup', popupdata, $scope)
                            $scope.loading = false
                        } else {
                            $scope.reasonForCancel = response.data[0].reasons;
                            $scope.reasonForCancel.push({'reason_code': "", 'reason_description': "Select"})
                            $scope.selectedReason.selected = $scope.reasonForCancel[$scope.reasonForCancel.length - 1]
                            $scope.loading = false
                        }
                        //$scope.reasonForCancel = response.data[0].reasons;
                        //console.log($scope.reasonForCancel)
                        // for (var i=0;typeof(orderdetails[i]) === 'object';i++)
                        // suborder.push(orderdetails[i])
                        // $scope.suborders = suborder;
                    },
                            function (response) {
                                console.log("Error response received  while getting Reason for cancellation ")
                                console.log(response)
                                var msg = errorcodesrv.checkcode(response.status)
                                if (msg !== "")
                                    var popupdata = msg
                                else
                                    var popupdata = "Error Response Received  While Getting Reason For Cancellation From Server"
                                $scope.popupopen('generalpopup', popupdata, $scope)
                                $scope.loading = false

                            })
        }
        $scope.actionTakenfun = function () {
            //et data{}j ={'callertypeId':$scope.selectedCallerType.caller_type,'isuuecateg':$scope.selectedIssueType.issue_category};
            //console.log($scope.selectedCallerType.id)
            //console.log($scope.selectedIssueType.issue)
            let dataObj = {'callertypeId': $scope.selectedIssueType.selected.caller_type, 'isuuecateg': $scope.selectedIssueType.selected.issue_category};
            fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, Leykart_DatabaseConstant.urlpath, 'actionToBeTaken', dataObj)
                    .then(function (response) {
                        //console.log(response)
                        if (response.length > 0) {
                            $scope.actiontaken = response;
                            //if(response.length>0)	
                        } else {
                            //console.log("else"+$scope.actiontaken)
                            $scope.actiontaken = []
                            $scope.actiontaken.push("No action to be taken present");
                            //console.log($scope.actiontaken)
                        }
                    }, function (response) {
                        //console.log(response)
                        $scope.actiontaken = [];
                        $scope.actiontaken.push("Error in fetching data from leykart database");
                    });
        }
        $scope.getissue = function () {
            fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, Leykart_DatabaseConstant.urlpath, 'IssueType', {caller_id: 1})
                    .then(function (response) {
                        //console.log(response)
                        $scope.issueType = response.data;
                        $scope.issueType.push({'caller_type': "1", 'issue_category': "Select"})
                        $scope.selectedIssueType.selected = $scope.issueType[$scope.issueType.length - 1]
                    }, function (error) {
                        console.log("error in getting IssueType type")
                        console.log(error)
                    });
        }
        $scope.getissue();
        $scope.sortArray = ['order_date'];
        $scope.sortFilterOrder = function (fieldname) {
            var ind = $scope.sortArray.indexOf('order_date');
            if (ind > -1) {
                $scope.sortArray.splice(ind, 1);
            }
            $scope.sortArray.push(fieldname);
        }
        $scope.removeSort = function () {
            $scope.sortArray = ['order_date'];
        }
        $scope.openTicketWidget = function (order) {
            $scope.selectedOrder = order;
            $scope.selectedIssueType.selected = {};
            $scope.selectedReason.selected = {};
            $scope.getissue();
            reasonForCancellation();
            $scope.actiontaken = "";
            $scope.popupopen('createticketwidget', null, $scope);
        }
        $scope.date = function (fromdate, todate) {
            //console.log("called date function of view all cntrl")
            dateAsData.from_date = fromdate.getDate() + '.' + (fromdate.getMonth() + 1) + '.' + fromdate.getFullYear();
            dateAsData.to_date = todate.getDate() + '.' + (todate.getMonth() + 1) + '.' + todate.getFullYear();
            $scope.viewallorderdetails();

            //console.log(fromdate.getDate()+'.'+fromdate.getMonth()+'.'+fromdate.getFullYear())
            //console.log(todate.getDate()+'.'+todate.getMonth()+'.'+todate.getFullYear())
        }
        // $scope.users = [];
        // $scope.totalUsers = 0;
        // $scope.usersPerPage = 25; 

        //set the page pagination changes By Arun

        //$scope.bigTotalItems = 100;
        $scope.maxSize = 10; // maxsize in pagination
        $scope.bigCurrentPage = 1; //Default page
        // $scope.setPage = function(pageNo) {
        //     $scope.currentPage = pageNo;
        // };

        //fetching Fromdate and Todate From filter option
        $scope.date = function (fromdate, todate) {
            //console.log("called date function of view all cntrl")
            fd = dateAsData.from_date = fromdate.getDate() + '.' + (fromdate.getMonth() + 1) + '.' + fromdate.getFullYear();
            td = dateAsData.to_date = todate.getDate() + '.' + (todate.getMonth() + 1) + '.' + todate.getFullYear();
            $scope.pageChanged();
        }
        //end for fetching Fromdate and Todate From filter option

        //Getting the current page
        $scope.pageChanged = function () {
            var pageid = $scope.bigCurrentPage;
            fromdate = fd;
            todate = td;
            $scope.viewallorderdetails(pageid, fromdate, todate);
        };
        $scope.setPage = function (pageNo) {
            $scope.bigCurrentPage = pageNo;
        };
        // end for Getting the current page

        // start of fetching data from Api  
        $scope.viewallorderdetails = function (pageid, fromdate, todate) {
            if (pageid === undefined) {
                pageid = 1;
            }
            $scope.loading = true;
            var loading = document.getElementById("loading");
            loading.style.visibility = "visible";
            var path = 'viewallorderurlpath';

            var dateAsData = {'from_date': fromdate, 'to_date': todate, 'status': 'All', 'page_num': pageid};
            fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, Leykart_DatabaseConstant.urlpath, 'viewallorders', {
                "data": dateAsData
            }).then(function (response) {
                if (response.data[0]['data'] != null && response.data[0]['data'] != "") {
                    if (response.data[0]['data'].length > 0) {
                        $scope.viewallorders = response.data[0].data;
                        $scope.bigTotalItems = response.data[0]['count'];
                        $scope.tabledata = response.data[0]['data'];
                        angular.forEach($scope.viewallorders, function (order) {
                            if (order.call_status != "" && order.call_status != null) {
                                var index = $scope.verifyStatus.findIndex(obj => obj.status_id == order.call_status[order.call_status.length - 2]);
                                console.log(index);
                                if (index != -1) {
                                    order.last_call_status = $scope.verifyStatus[index].status;
                                }
                            }
                        })
                        loading.style.visibility = "hidden";
                    }
                } else {
                    $scope.viewallorders = [];
                    $scope.tabledata = [];
                    var popupdata = "There Is No   To Display for The Input date Range"
                    $scope.popupopen('generalpopup', popupdata, $scope)
                    loading.style.visibility = "hidden";
                }
            },
                    function (response) {
                        console.log("Error response received  while getting viewall orders details from server")
                        var msg = errorcodesrv.checkcode(response.status)
                        if (msg !== "")
                            var popupdata = msg
                        else
                            var popupdata = "Error Response Received  While Getting View All Orders Details From Server"
                        $scope.popupopen('generalpopup', popupdata, $scope)
                        console.log(response)
                        loading.style.visibility = "hidden";
                    })
        }
        // end of fetching data from Api

        // start of  Sub order details of input order id
        $scope.orderOrsuborderpopupopen = function (popuptype, orderOrsuborderid) {
            //$scope.loading = true
            var loading = document.getElementById("loading");
            loading.style.visibility = "visible";
            //console.log("called   "+orderOrsuborderid)
            //var path = magento_ConstantApi.orderdetailurlpath+orderOrsuborderid;
            //authenticationSvc.login('GET',magento_ConstantApi.Apiendpoint,path,null,magento_ConstantApi.Headers)
            var data = {"orderid": orderOrsuborderid}
            var path = 'orderdetailurlpath';
            authenticationSvc.login('POST', magento_ConstantApi.Apiendpoint, path, data)

                    .then(function (response) {
                        //console.log(response.data)
                        if (popuptype === "Suborderpopup") {
                            $scope.popupopen(popuptype, response.data[0][0], $scope)
                            //$scope.loading = false
                            loading.style.visibility = "hidden";
                        }
                        if (popuptype === "orderpopup") {
                            var suborder = []
                            $scope.orderdetails = response.data[0];
                            //console.log(response.data[0])
                            for (var i = 0; typeof (response.data[0][i]) === 'object'; i++)
                                suborder.push(response.data[0][i])
                            $scope.suborders = suborder;
                            $scope.showsearchbar = false;
                            $scope.popupopen(popuptype, response.data[0][0], $scope)
                            //$scope.loading = false
                            loading.style.visibility = "hidden";
                        }

                    },
                            function (response) {
                                console.log("Error response received  while getting sub order details ")
                                console.log(response)
                                //$scope.loading = false
                                loading.style.visibility = "hidden";

                            })
        }
        // end of order pop up
    }])


app.controller('verifynewordercntrl', ['$scope', '$rootScope', '$state', 'authenticationSvc', 'magento_ConstantApi', 'removingVerifiedItemSrvc', 'errorcodesrv', 'ConvertJsonToCsvSrv', 'fetchdatabase', 'Leykart_DatabaseConstant'
            , function ($scope, $rootScope, $state, authenticationSvc, magento_ConstantApi, removingVerifiedItemSrvc, errorcodesrv, ConvertJsonToCsvSrv, fetchdatabase, Leykart_DatabaseConstant) {
                $scope.setnavshow(true);

                var arrayForTrackingVerifiedOrder = []
                // start of date
                var dateAsData = {
                    "from_date": '',
                    "to_date": ''
                }
                $scope.getVerifyStatus = function () {
                    fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, Leykart_DatabaseConstant.urlpath, 'getverifystatus', null).then(function (response) {
                        $scope.verifyStatus = response.data;
                    });
                }
                $scope.getVerifyStatus();
                $scope.date = function (fromdate, todate) {
                    //console.log("date in verify new order")
                    /*dateAsData.from_date = fromdate.getDate()+'.'+(fromdate.getMonth()+1)+'.'+fromdate.getFullYear();
                     dateAsData.to_date = todate.getDate()+'.'+(todate.getMonth()+1)+'.'+todate.getFullYear();*/
                    dateAsData.from_date = fromdate.getDate() + '.' + (fromdate.getMonth() + 1) + '.' + fromdate.getFullYear();
                    dateAsData.to_date = todate.getDate() + '.' + (todate.getMonth() + 1) + '.' + todate.getFullYear();
                    //$scope.loading=true;
                    $scope.getOrderForVerification();
                    //$scope.unVerifiedOrder();
                    //console.log(fromdate.getDate()+'.'+fromdate.getMonth()+'.'+fromdate.getFullYear())
                    //console.log(todate.getDate()+'.'+todate.getMonth()+'.'+todate.getFullYear())
                }

                $scope.setVerifyStatus = function (order, module = "verifyneworder") {
                    //$scope.loading=true;
                    var buttonSave = document.getElementById("button_tick");
                    buttonSave.classList.add("onclic");
                    setTimeout(function () {
                        buttonSave.classList.remove("onclic");
                        buttonSave.classList.add("validate");
                    }, 4000);
                    //buttonSave.classList.remove("onclick");
                    var load = document.getElementById("loading");
                    load.style.visibility = "visible";
                    if (order.selected_status != "" && order.selected_status != null && order.selected_status != undefined) {
                        fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, Leykart_DatabaseConstant.urlpath, 'setverifystatus', {"module": module, "order": order, "type": "upd"}).then(function (response) {
                            var popupdata = "Call Status Updated."
                            $scope.popupopen('generalpopup', popupdata, $scope);
                            $scope.getOrderForVerification();
                            //$scope.loading=false;
                            load.style.visibility = "hidden";
                        });
                    } else {
                        var popupdata = "Select a valid status and try again"
                        $scope.popupopen('generalpopup', popupdata, $scope);
                        //$scope.loading=false;
                        load.style.visibility = "hidden";
                }

                }
                $scope.maxCallsToBeMade = 5;
                $scope.getOrderForVerification = function () {
                    //$scope.loading=true;
                    var load = document.getElementById("loading");
                    load.style.visibility = "visible";
                    fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, Leykart_DatabaseConstant.urlpath, 'verifyneworder', {"data": {"status": "no", "from_date": dateAsData.from_date, "to_date": dateAsData.to_date}, "maxCount": $scope.maxCallsToBeMade}).then(function (response) {
                        $scope.loading = true;
                        if (response.data[0] == null || response.data[0] == "" || response.data.indexOf("error") > -1) {
                            load.style.visibility = "visible";
                            //console.log(response.data[0]);
                            $scope.verifyneworder = [];
                            var popupdata = "No new orders found";
                            load.style.visibility = "hidden";
                            /*$scope.popupopen('generalpopup',popupdata,$scope)*/
                        } else {
                            load.style.visibility = "visible";
                            $scope.verifyneworder = response.data[0];
                            angular.forEach($scope.verifyneworder, function (order) {
                                if (order.call_status != "" && order.call_status != null) {
                                    var index = $scope.verifyStatus.findIndex(obj => obj.status_id == order.call_status[order.call_status.length - 2]);
                                    if (index != -1) {
                                        order.last_call_status = $scope.verifyStatus[index].status;
                                    }
                                }
                            })
                            load.style.visibility = "hidden";
                        }
                    });

                }
                // end  of date
                $scope.downloadExcel = function (exceldata, excelname) {
                    /*console.log(exceldata)*/
                    var load = document.getElementById("loading");
                    load.style.visibility = "visible";
                    if (exceldata) {
                        angular.forEach(exceldata, function (data) {
                            if (data.verify_comment == "NULL") {
                                data.verify_comment = "";
                            }
                        });
                    }
                    var csvString = ConvertJsonToCsvSrv.ConvertToCSV(exceldata);
                    var a = $('<a/>', {
                        style: 'display:none',
                        href: 'data:application/octet-stream;base64,' + btoa(unescape(encodeURIComponent(csvString))),
                        download: excelname + '.csv'
                    }).appendTo('body')
                    a[0].click()
                    a.remove();
                    load.style.visibility = "hidden";
                }
                // Start of show un verified orders
                /*$scope.unVerifiedOrder = function(){
                 $scope.loading = true
                 var dataobj = {"status":'no',"from_date":dateAsData.from_date,"to_date":dateAsData.to_date}
                 var path = 'verifyneworderurlpath';
                 authenticationSvc.login('POST',magento_ConstantApi.Apiendpoint,path,dataobj)
                 .then(function(response){
                 //console.log(response.data[0])
                 if(response.data[0] == null || response.data[0] == ""){
                 var popupdata = "There is no unverified order to display";
                 $scope.verifyneworder=[];
                 $scope.popupopen('generalpopup',popupdata,$scope)
                 $scope.loading = false
                 }
                 else{	
                 $scope.verifyneworder = response.data[0]
                 $scope.loading = false
                 }
                 },
                 function(response){
                 console.log("Error response received  while getting unVerified Order ")
                 console.log(response)
                 var msg = errorcodesrv.checkcode(response.status)
                 if (msg !== "")
                 var popupdata = msg
                 else
                 var popupdata = "Error Response Received  While Getting UnVerified Order Details From Server"
                 $scope.popupopen('generalpopup',popupdata,$scope)
                 $scope.loading = false
                 })
                 
                 }*/
                // end of showing  UN verified order

                // Start of  removing the verified order from the screen
                var arrayForTrackingVerifiedOrder = [];
                var arrayForTrackingCC = [];
                $scope.pushitemIndex = function (index, comment, checkboxclicked) {
                    var flag = false
                    index.selected_status = "";
                    for (var i = 0; i < arrayForTrackingVerifiedOrder.length; i++) {
                        if (arrayForTrackingVerifiedOrder[i].order_id === index.suborder_id) {
                            flag = true
                            if (comment) {
                                arrayForTrackingVerifiedOrder[i].comment = comment;
                                var j = arrayForTrackingCC.findIndex(obj => obj.suborder_id == index.suborder_id);
                                if (j > -1)
                                    index.verify_comment = comment;
                                arrayForTrackingCC[j].verify_comment = comment;
                            } else {
                                arrayForTrackingVerifiedOrder[i].comment = '';
                                var j = arrayForTrackingCC.findIndex(obj => obj.suborder_id == index.suborder_id);
                                if (j > -1)
                                    index.verify_comment = '';
                                arrayForTrackingCC[j].verify_comment = '';
                            }
                            arrayForTrackingVerifiedOrder[i].verified = "YES"
                        }
                    }
                    if (flag == false && checkboxclicked) {
                        if (comment) {
                            arrayForTrackingVerifiedOrder.push({'order_id': index.suborder_id, 'comment': comment, 'verified': 'YES'});
                            index.verify_comment = comment;
                        } else
                            arrayForTrackingVerifiedOrder.push({'order_id': index.suborder_id, 'comment': '', 'verified': 'YES'})
                        index.selected_status = "";
                        arrayForTrackingCC.push(index);

                    }
                    //console.log(arrayForTrackingVerifiedOrder)

                }

                $scope.popitemIndex = function (index, comment) {
                    var newArray = [];
                    for (var i = 0; i < arrayForTrackingVerifiedOrder.length; i++) {
                        // console.log(arrayForTrackingVerifiedOrder[i].index)
                        if (arrayForTrackingVerifiedOrder[i].order_id === index.suborder_id)
                            continue
                        else
                            newArray.push(arrayForTrackingVerifiedOrder[i])
                    }
                    arrayForTrackingVerifiedOrder = newArray;
                    var i = arrayForTrackingCC.findIndex(obj => obj.ref_incr_id == index.ref_incr_id);
                    if (i > -1) {
                        arrayForTrackingCC.splice(i, 1);
                    }
                    //console.log(arrayForTrackingVerifiedOrder)
                }
                // for enabling save button
                $scope.enableSaveButton = function () {
                    return arrayForTrackingVerifiedOrder.length > 0 ? false : true
                }

                // for resetting  arrayForTrackingVerifiedOrder
                $scope.resetArrayVerified = function () {
                    //console.log("called")
                    arrayForTrackingVerifiedOrder = [];
                    arrayForTrackingCC = [];
                    //console.log(arrayForTrackingVerifiedOrder)
                }





                // Start of update verified  orders
                $scope.saveVerifiedRows = function (fieldToCheck) {
                    var load = document.getElementById("loading");
                    load.style.visibility = "visible";
                    //objReturnFromFactory = removingVerifiedItemSrvc.removeChecked($scope.verifyneworder,arrayForTrackingVerifiedOrder,fieldToCheck)
                    //$scope.verifyneworder = objReturnFromFactory.newtableCollection;
                    //arrayForTrackingVerifiedOrder = objReturnFromFactory.arrayForTrackingVerifiedOrder
                    //console.log(objReturnFromFactory.removedArray)
                    if (arrayForTrackingVerifiedOrder.length > 0) {
                        load.style.visibility = "visible";
                        var removedItems = {"magento": {"orderlist": arrayForTrackingVerifiedOrder}, "cc": arrayForTrackingCC, "type": "ver", "module": "verifyneworder"};
                        //console.log(removedItems)
                        var path = 'verifyupdateneworderurlpath'
                        fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, Leykart_DatabaseConstant.urlpath, 'setverifystatus', removedItems).then(function (response) {
                            var popupdata = "Order Verified and Updated."
                            $scope.popupopen('generalpopup', popupdata, $scope);
                            $scope.getOrderForVerification();
                            $scope.resetArrayVerified();
                        });
                    } else {
                        var popupdata = "No Orders Selected To Be Verified"
                        $scope.popupopen('generalpopup', popupdata, $scope)
                        load.style.visibility = "hidden";
                    }

                }
                // end of updating verified orders
                // end of removing the verified Items from the screen

                // start of  Sub order details of input order id
                $scope.orderOrsuborderpopupopen = function (popuptype, orderOrsuborderid) {
                    var load = document.getElementById("loading");
                    load.style.visibility = "visible";
                    //console.log("called   "+orderOrsuborderid)
                    //var path = magento_ConstantApi.orderdetailurlpath+orderOrsuborderid;
                    //authenticationSvc.login('GET',magento_ConstantApi.Apiendpoint,path,null,magento_ConstantApi.Headers)
                    var data = {"orderid": orderOrsuborderid}
                    var path = 'orderdetailurlpath';
                    authenticationSvc.login('POST', magento_ConstantApi.Apiendpoint, path, data)
                            .then(function (response) {
                                //console.log(response.data)
                                if (popuptype === "Suborderpopup") {
                                    $scope.popupopen(popuptype, response.data[0][0], $scope)
                                    load.style.visibility = "hidden";
                                }
                            },
                                    function (response) {
                                        console.log("Error response received  while getting sub order details ")
                                        console.log(response)
                                        //$scope.loading = false
                                        load.style.visibility = "hidden";

                                    })
                }
                // end of order pop up

            }])


app.controller('listnewuserscntrl', ['$scope', '$state', 'fetchdatabase', '$filter', 'removingVerifiedItemSrvc', 'magento_ConstantApi', 'authenticationSvc', 'errorcodesrv', 'ConvertJsonToCsvSrv', 'fetchdatabase', 'Leykart_DatabaseConstant', 'userInfosvc',
    function ($scope, $state, fetchdatabase, $filter, removingVerifiedItemSrvc, magento_ConstantApi, authenticationSvc, errorcodesrv, ConvertJsonToCsvSrv, fetchdatabase, Leykart_DatabaseConstant, userInfosvc) {


        $scope.setnavshow(true);
        var data = {
            "luser": userInfosvc.returnUserInfo()[0].username,
            "lpasswd": userInfosvc.returnUserInfo()[0].pass,
            "request_data": "helptopic",
            "application_name": "LeyKart",
            "depart_name": "L1 Support - Leykart"
        }
        $scope.getHelpTopicId = function () {
            var path = Leykart_DatabaseConstant.osticketurl;
            fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, path, 'l1agent', data)
                    .then(function (response) {
                        //console.log(response)
                        if (response.data == null || response.data == "") {
                            var msg = errorcodesrv.checkcode(response.status)
                            if (msg !== "")
                                var popupdata = msg
                            else
                                var popupdata = "There Is No  Help Topic To Display"
                            $scope.popupopen('generalpopup', popupdata, $scope)
                            $scope.loading = false
                        } else {
                            $scope.helpTopicId = response.data[0].topic_id
                            $scope.loading = false
                        }
                        //deferred.resolve(true);
                    },
                            function (response) {
                                console.log("Error response received  while getting L2 and L3 details from os ticket ")
                                console.log(response)
                                var msg = errorcodesrv.checkcode(response.status)
                                if (msg !== "")
                                    var popupdata = msg
                                else
                                    var popupdata = "Error Response Received  While Getting Help Topics From Os Ticket "
                                $scope.popupopen('generalpopup', popupdata, $scope)
                                //deferred.reject(false);
                            })
            //return deferred.promise;
        }
        $scope.getHelpTopicId();
        $scope.getVerifyStatus = function () {
            fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, Leykart_DatabaseConstant.urlpath, 'getverifystatus', null).then(function (response) {
                $scope.verifyStatus = response.data;
            });
        }
        $scope.getVerifyStatus();
        // start of to get list of new users 
        var dateAsData = {
            "from_date": '',
            "to_date": ''
        }
        $scope.sendSms = function (user) {
            fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, Leykart_DatabaseConstant.urlpath, 'sendSMS', {"user": user, "mod": 1}).then(function (response) {
                $scope.popupopen('generalpopup', 'SMS sent. Please check the status', $scope);
                $scope.getUserForVerification();
            });
        }

        $scope.openTicket = function (user) {
            $scope.ticketUser = user;
            $scope.popupopen('createticketpopup', null, $scope);
        }

        $scope.createTicket = function () {
            var load = document.getElementById("loading");
            load.style.visibility = "visible";
            var el_notif = document.getElementById("notif");
            var el_ticket = document.getElementById("ticket");
            el_ticket.style.visibility = 'hidden';
            var para = document.createElement("P");
            var t = document.createTextNode("Loading...");
            para.appendChild(t);
            el_notif.appendChild(para);
            el_notif.style.visibility = 'visible';
            var userinfo = userInfosvc.returnUserInfo()[0]
            var path = Leykart_DatabaseConstant.osticketurl;
            var data = {"name": $scope.ticketUser.name,
                "email": $scope.ticketUser.email,
                "phone": $scope.ticketUser.mobile_no,
                "subject": "Account modification#NA",
                "message": $scope.ticketUser.comment || 'No Comments',
                // "ip"  : '125.22.193.148',
                "topicId": $scope.helpTopicId, // 27
                "laykartappsubcategory": "Account modification",
                "TicketType": "Operations",
                "priority": "2"
            };
            fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, path, 'createticket', data)
                    .then(function (ticketnumber) {
                        //console.log(response)
                        //console.log("ticketNo  received from os ticket")
                        //$scope.loading =false
                        if (ticketnumber.data[0] != null) {
                            $scope.sendSmsCallCenter($scope.ticketUser.mobile_no, ticketnumber.data[0], 1);
                            //var para=document.createElement("P");
                            var t1 = document.createTextNode("Ticket number " + ticketnumber.data[0] + " created");
                            //para.appendChild(t);
                            //el_notif.appendChild(para);
                            //el_ticket.style.visibility='hidden';
                            var data = {
                                "luser": userinfo.username,
                                "lpasswd": userinfo.pass,
                                //"helptopic":"27", 
                                "helptopic": "27",
                                "ticket_number": ticketnumber.data[0],
                                "status": "",
                                "staff_id": "",
                                "from_date": "",
                                "to_date": ""
                            }
                            //console.log(data)
                            // callimg os ticket to fetch ticket details
                            var path = Leykart_DatabaseConstant.osticketurl;
                            //authenticationSvc.login('POST',OSTicket_ConstantApi.Apiendpoint, path, data, OSTicket_ConstantApi.Header)
                            fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, path, 'viewticket', data)
                                    .then(function (response) {
                                        //console.log(response)
                                        // calling transfer function to transfer ticket to that person

                                        // these 5 lines is comented for time being

                                        $scope.assignTo = {}
                                        $scope.assignTo.staff_id = userInfosvc.returnUserInfo()[0].staff_id
                                        $scope.ticketToTransferOrAssign = []
                                        $scope.ticketToTransferOrAssign.push({'index': response.data[0]})
                                        var data = {
                                            "luser": userInfosvc.returnUserInfo()[0].username,
                                            "lpasswd": userInfosvc.returnUserInfo()[0].pass,
                                            "ticket_id": response.data[0].ticket_id,
                                            "update_type": "AssigntoStaff",
                                            "message": "Assign ticket from API",
                                            "assignto": userInfosvc.returnUserInfo()[0].staff_id
                                        }
                                        //console.log(data)
                                        //var count = 0
                                        var path = Leykart_DatabaseConstant.osticketurl;
                                        //authenticationSvc.login('POST',OSTicket_ConstantApi.Apiendpoint,path,data,header)
                                        fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, path, 'updateticketAssign', data)
                                                .then(function (response) {
                                                    if (response.data == 'true') {
                                                    }
                                                    ;
                                                    para.removeChild(para.childNodes[0]);
                                                    para.appendChild(t1);
                                                    el_notif.style.visibility = 'visible';
                                                    load.style.visibility = "hidden";
                                                });
                                    })
                        }
                    });
        }

        $scope.date = function (fromdate, todate) {
            //console.log("date in verify new user")
            dateAsData.from_date = fromdate.getDate() + '.' + (fromdate.getMonth() + 1) + '.' + fromdate.getFullYear();
            dateAsData.to_date = todate.getDate() + '.' + (todate.getMonth() + 1) + '.' + todate.getFullYear();
            /*dateAsData.from_date = fromdate;
             dateAsData.to_date = todate*/
            //$scope.loading=true;
            $scope.getUserForVerification();
            //$scope.loading=false;
            //console.log(fromdate.getDate()+'.'+fromdate.getMonth()+'.'+fromdate.getFullYear())
            //console.log(todate.getDate()+'.'+todate.getMonth()+'.'+todate.getFullYear())
        }
        $scope.maxCallsToBeMade = 5;
        $scope.getUserForVerification = function () {
            //$scope.loading=true;

            var load = document.getElementById("loading");
            load.style.visibility = "visible";
            fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, Leykart_DatabaseConstant.urlpath, 'verifynewuser', {"data": {"status": "NO", "from_date": dateAsData.from_date, "to_date": dateAsData.to_date}, "maxCount": $scope.maxCallsToBeMade}).then(function (response) {
                $scope.loading = true;
                if (response.data[0] == null || response.data[0] == "" || response.data.indexOf("error") != -1) {
                    //console.log(response.data[0]);
                    $scope.loading = true;
                    $scope.listnewuser = [];
                    /*var popupdata="No users to display";
                     $scope.popupopen('generalpopup',popupdata,$scope)*/
                    $scope.loading = false;
                    load.style.visibility = "hidden";
                } else {
                    $scope.loading = true;
                    $scope.listnewuser = response.data[0];
                    angular.forEach($scope.listnewuser, function (user) {
                        if (user.call_status != "" && user.call_status != null) {
                            var index = $scope.verifyStatus.findIndex(obj => obj.status_id == user.call_status[user.call_status.length - 2]);
                            if (index != -1) {
                                user.last_call_status = $scope.verifyStatus[index].status;
                            }
                        }
                    })
                    //$scope.loading=false;
                    load.style.visibility = "hidden";
                }
            });
            //$scope.loading=false;
        }
        $scope.setVerifyStatus = function (user, module = "verifynewuser") {
            var load = document.getElementById("loading");
            load.style.visibility = "visible";
            if (user.selected_status != "" && user.selected_status && user.selected_status != null && user.selected_status != undefined) {
                fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, Leykart_DatabaseConstant.urlpath, 'setverifystatus', {"module": module, "user": user, "type": "upd"}).then(function (response) {
                    var popupdata = "Call Status Updated."
                    $scope.popupopen('generalpopup', popupdata, $scope);
                    $scope.getUserForVerification();
                });
            } else {
                var popupdata = "Select a valid status and try again"
                $scope.popupopen('generalpopup', popupdata, $scope);
                //$scope.loading=false;
                load.style.visibility = "hidden";
        }
        }
        $scope.getlistofnewuser = function () {
            $scope.loading = true
            //console.log("called")
            //var path = magento_ConstantApi.getnewuserlisturlpath+'NO';
            //authenticationSvc.login('GET',magento_ConstantApi.Apiendpoint,path,null,magento_ConstantApi.Headers)
            var data = {"status": "NO", "from_date": dateAsData.from_date, "to_date": dateAsData.to_date}
            var path = 'getnewuserlisturlpath';
            authenticationSvc.login('POST', magento_ConstantApi.Apiendpoint, path, data)
                    .then(function (response) {
                        //console.log(response.data)

                        if (response.data == null || response.data == "" || response.data[0].customer.length == 0) {
                            var popupdata = "There is no user to display"
                            $scope.listnewuser = [];
                            $scope.popupopen('generalpopup', popupdata, $scope)
                            $scope.loading = false
                        } else {
                            $scope.listnewuser = response.data[0].customer
                            $scope.loading = false
                        }
                    },
                            function (response) {
                                console.log("Error response received  while getting list of new user details from server")
                                var msg = errorcodesrv.checkcode(response.status)
                                if (msg !== "")
                                    var popupdata = msg
                                else
                                    var popupdata = "Error response received  while getting list of new user details from server"
                                $scope.popupopen('generalpopup', popupdata, $scope)
                                console.log(response)
                                $scope.loading = false
                            })
        }
        //$scope.getlistofnewuser();

        // end of  list of new users


        // Start of  removing the verified order from the screen
        var arrayForTrackingVerifiedOrder = [];
        var arrayForTrackingCC = [];
        $scope.pushitemIndex = function (index, cmnt, checkboxclicked) {
            //alert(index +"  "+cmnt+"  ")
            var flag = false
            for (var i = 0; i < arrayForTrackingVerifiedOrder.length; i++) {
                if (arrayForTrackingVerifiedOrder[i].user_id === index.user_id) {
                    index.selected_status = "";
                    flag = true
                    var ind = arrayForTrackingCC.findIndex(obj => obj.user_id == index.user_id);
                    if (cmnt) {
                        arrayForTrackingVerifiedOrder[i].comment = cmnt;
                        if (ind > -1) {
                            arrayForTrackingCC[ind].comment = cmnt;
                        }
                    } else {
                        arrayForTrackingVerifiedOrder[i].comment = '';
                        if (ind > -1) {
                            arrayForTrackingCC[ind].comment = '';
                        }

                    }
                    arrayForTrackingVerifiedOrder[i].verified = 'YES';
                    if (ind > -1) {
                        arrayForTrackingCC[ind].verified = 'YES';
                    }
                }
            }
            if (flag == false && checkboxclicked) {
                index.selected_status = "";
                if (cmnt) {
                    arrayForTrackingVerifiedOrder.push({'user_id': index.user_id, 'comment': cmnt, 'verified': 'YES'});
                    index.verified = 'YES';
                    arrayForTrackingCC.push(index);
                } else {
                    arrayForTrackingVerifiedOrder.push({'user_id': index.user_id, 'comment': '', 'verified': 'YES'});
                    index.verified = 'YES';
                    index.comment = "";
                    arrayForTrackingCC.push(index);
                }
            }
            //console.log(arrayForTrackingVerifiedOrder)

        }

        $scope.popitemIndex = function (index, comment) {
            var newArray = [];
            for (var i = 0; i < arrayForTrackingVerifiedOrder.length; i++) {
                // console.log(arrayForTrackingVerifiedOrder[i].index)
                if (arrayForTrackingVerifiedOrder[i].user_id === index.user_id)
                    continue
                else
                    newArray.push(arrayForTrackingVerifiedOrder[i])
            }
            arrayForTrackingVerifiedOrder = newArray;
            var ind = arrayForTrackingCC.findIndex(obj => obj.user_id == index.user_id);
            if (ind > -1) {
                arrayForTrackingCC.splice(ind, 1);
            }

            // console.log(arrayForTrackingVerifiedOrder)
        }

        $scope.enableSaveButton = function () {
            return arrayForTrackingVerifiedOrder.length > 0 ? false : true
        }

        $scope.resetArrayVerified = function () {
            //console.log("called")
            arrayForTrackingVerifiedOrder = []
            arrayForTrackingCC = [];
            //console.log(arrayForTrackingVerifiedOrder)
        }



        // start of TO update new users 
        $scope.saveVerifiedRows = function (fieldToCheck) {
            var load = document.getElementById("loading");
            load.style.visibility = "visible";
            //objReturnFromFactory = removingVerifiedItemSrvc.removeChecked($scope.verifyneworder,arrayForTrackingVerifiedOrder,fieldToCheck)
            //$scope.verifyneworder = objReturnFromFactory.newtableCollection;
            //arrayForTrackingVerifiedOrder = objReturnFromFactory.arrayForTrackingVerifiedOrder
            //console.log(objReturnFromFactory.removedArray)
            if (arrayForTrackingVerifiedOrder.length > 0) {
                load.style.visibility = "visible";
                var removedItems = {"magento": {"userlist": arrayForTrackingVerifiedOrder}, "cc": arrayForTrackingCC, "type": "ver", "module": "verifynewuser"};
                //console.log(removedItems)
                var path = 'verifyupdateneworderurlpath'
                fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, Leykart_DatabaseConstant.urlpath, 'setverifystatus', removedItems).then(function (response) {
                    var popupdata = "Call Status Verified and Updated."
                    $scope.popupopen('generalpopup', popupdata, $scope);
                    $scope.getUserForVerification();
                    $scope.resetArrayVerified();
                });
            } else {
                var popupdata = "No Users Selected To Be Verified"
                load.style.visibility = "hidden";
                $scope.popupopen('generalpopup', popupdata, $scope)
            }

        }
        /*$scope.saveVerifiedRows = function(fieldToCheck){
         
         //objReturnFromFactory = removingVerifiedItemSrvc.removeChecked($scope.listnewuser,arrayForTrackingVerifiedOrder,fieldToCheck)
         //$scope.listnewuser = objReturnFromFactory.newtableCollection;
         //arrayForTrackingVerifiedOrder = objReturnFromFactory.arrayForTrackingVerifiedOrder
         
         //we need to Enable below if condition to update user  in magento
         
         if(arrayForTrackingVerifiedOrder.length > 0){
         $scope.loading =true
         var removedusers = {"userlist" : arrayForTrackingVerifiedOrder};
         var path = 'updateverifyurlpath'
         authenticationSvc.login('POST',magento_ConstantApi.Apiendpoint,path,removedusers)
         .then(function(response){
         //console.log(response.data)
         if(response.data == null || response.data == ""){
         var popupdata = "Users Could Not Be Verified"
         $scope.popupopen('generalpopup',popupdata,$scope)
         $scope.loading = false
         }
         else{	
         var popupdata = "Users Verified Successfully"
         $scope.popupopen('generalpopup',popupdata,$scope)
         //$state.reload();
         //$state.go($state.current, {}, {reload: true});
         $scope.loading = false
         arrayForTrackingVerifiedOrder = []
         $scope.getlistofnewuser()
         
         }
         },
         function(response){
         console.log("Error response received  while Updating Verified new User ")
         console.log(response)
         var msg = errorcodesrv.checkcode(response.status)
         if (msg !== "")
         var popupdata = msg
         else	
         var popupdata = "Error Response Received  While Updating Verified New User From Server"
         $scope.popupopen('generalpopup',popupdata,$scope)
         $scope.loading = false
         })
         }
         else{
         var popupdata = "No Users Selected To Be Verified"
         $scope.popupopen('generalpopup',popupdata,$scope)
         }
         
         }
         */

        // end of  update new users

        $scope.downloadUsersList = function () {
            //console.log("called")
            var load = document.getElementById("loading");
            load.style.visibility = "visible";
            $scope.downloadExcel($scope.listnewuser, 'Listnewuser')
            load.style.visibility = "hidden";
            // var csvString = ConvertJsonToCsvSrv.ConvertToCSV($scope.listnewuser);
            // var a = $('<a/>', {
            // 	style:'display:none',
            // 	href:'data:application/octet-stream;base64,'+btoa(csvString),
            // 	download:'Listnewuser.csv'
            // }).appendTo('body')
            // a[0].click()
            // a.remove();
        }

    }])


app.controller('getfeedbackcntrl', ['$scope', 'fetchdatabase', '$state', 'authenticationSvc', 'magento_ConstantApi', 'Leykart_DatabaseConstant',
    function ($scope,
            fetchdatabase, $state, authenticationSvc, magento_ConstantApi, Leykart_DatabaseConstant) {
        $scope.feedbackReceived;
        $scope.maxCallsToBeMade = 5;
        $scope.callStatus = [];
        $scope.getCallStatus = function () {
            fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, Leykart_DatabaseConstant.urlpath, 'getCallStatus', null).then(function (response) {
                if (response.data.indexOf('<script>') == -1) {
                    $scope.callStatus = response.data;
                }
            });
        }
        $scope.getCallStatus();
        $scope.setnavshow(true)
        $scope.feedback = {
            regfeedbacktype: false,
            cancelfeedbacktype: false
        };


        //Start of  fetching the data based on Date
        var dateAsData = {
            "from_date": '',
            "to_date": ''
        }

        $scope.date = function (fromdate, todate) {
            dateAsData.from_date = fromdate.getDate() + '.' + (fromdate.getMonth() + 1) + '.' + fromdate.getFullYear();
            dateAsData.to_date = todate.getDate() + '.' + (todate.getMonth() + 1) + '.' + todate.getFullYear();
            var todayDt = new Date();
            dateAsData.today = todayDt.getDate() + '.' + (todayDt.getMonth() + 1) + '.' + todayDt.getFullYear();
            dateAsData.from_dateLocal = fromdate.getFullYear() + '-' + (fromdate.getMonth() + 1) + '-' + fromdate.getDate() + ' ' + '00:00:00';
            dateAsData.todayLocal = todayDt.getFullYear() + '-' + (todayDt.getMonth() + 1) + '-' + todayDt.getDate() + ' ' + '23:59:59';
            $scope.viewallorderdetails();

            //console.log(fromdate.getDate()+'.'+fromdate.getMonth()+'.'+fromdate.getFullYear())
            //console.log(todate.getDate()+'.'+todate.getMonth()+'.'+todate.getFullYear())
        }

        // function autocall(){
        // //console.log("called initial declatiion")
        // $scope.feedback.regfeedbacktype=false;
        // $scope.feedback.cancelfeedbacktype=true;

        // $scope.$broadcast('regtype', $scope.feedback.regfeedbacktype);
        // $scope.$broadcast('canceltype', $scope.feedback.cancelfeedbacktype);
        // //$scope.$digest();
        // }
        //autocall()

        // start of fetching data from Api  
        //$scope.crossModule='';
        $scope.viewallorderdetails = function () {
            $scope.loading = true
            var mainorder = [];
            var suborder = [];
            var path = 'viewallorderurlpath';
            if ($scope.regfeedsuborderdetails) {
                $scope.regfeedsuborderdetails = [];
            } else if ($scope.cancelfeedsuborderdetails) {
                $scope.cancelfeedsuborderdetails = [];
            }
            dateAsData.status = 'Upd';
            var data = dateAsData;
            $scope.order_array = [];
            $scope.viewallorderstemp = [];
            $scope.viewallorders = [];
            authenticationSvc.login('POST', magento_ConstantApi.Apiendpoint, path, data)
                    .then(function (response) {
                        //console.log(response.data)
                        $scope.loading = true;
                        order2 = true;
                        if (response.data[0] == null || response.data[0] == "") {
                            var popupdata = "There Is No  Orders To Display For Input Date Range"
                            $scope.popupopen('generalpopup', popupdata, $scope)
                            $scope.loading = false
                        } else {
                            $scope.order_array = response.data[0];
                            //$scope.viewallorders=$scope.order_array;
                        }
                        //console.log('The length of order array is '+$scope.order_array.length);
                        var flag = 0;
                        angular.forEach($scope.order_array, function (order) {
                            flag = 0;
                            var done = false;
                            angular.forEach($scope.viewallorderstemp, function (main) {
                                if (!done)
                                    if (main.order_id == order.order_id) {
                                        flag += 1;
                                        done = true;
                                    }
                            });
                            if (flag == 0 /*&& (order.suborder_status=='Delivered'||order.suborder_status=='Refunded')*/) {
                                $scope.viewallorderstemp.push(order);
                                var mainordertemp = [];
                                mainordertemp.order_id = order.order_id;
                                mainordertemp.suborder_id = [];
                                mainordertemp.suborder_id.push({'orderid': order.ref_incr_id, 'status': order.suborder_status});
                                mainorder.push(mainordertemp);
                            }
                            if (flag > 0) {
                                angular.forEach($scope.order_array, function (order) {
                                    var done1 = false;
                                    angular.forEach(mainorder, function (m_order) {
                                        if (!done1)
                                            if (m_order.order_id == order.order_id) {
                                                if (m_order.suborder_id.findIndex(obj => obj.orderid == order.ref_incr_id) < 0) {
                                                    m_order.suborder_id.push({'orderid': order.ref_incr_id, 'status': order.suborder_status});
                                                }
                                                done1 = true;
                                            }
                                    });
                                });
                                //console.log(mainorder);

                            }

                        });
                        var ind = 0;
                        var dataIp = {"from_date": dateAsData.from_dateLocal, "to_date": dateAsData.todayLocal}
                        if (mainorder.length != 0 && mainorder.length == $scope.viewallorderstemp.length)
                            fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, Leykart_DatabaseConstant.urlpath, 'ViewFeedback', dataIp).then(function (response) {
                                if (response.data.indexOf("<script>alert('Something went wrong. Please contact your administrator.')</script>") < 0 && response.data != '') {
                                    $scope.feedbackReceived = response.data;
                                    //console.log($scope.feedbackReceived);
                                    var entry = 0;

                                    var mainorder_temp = [];
                                    angular.forEach(mainorder, function (order) {
                                        var total_suborders_count = order.suborder_id.length;
                                        var increment_flag = 0;
                                        angular.forEach(order.suborder_id, function (suborder) {
                                            if (suborder.status == 'Delivered' || suborder.status == 'Refunded') {
                                                increment_flag = increment_flag + 1;
                                            }
                                        });
                                        if (increment_flag == total_suborders_count) {
                                            mainorder_temp.push(order);
                                        }
                                    });

                                    angular.forEach(mainorder_temp, function (order) {
                                        var done = false;
                                        //$scope.crossModule+=feedback.call_status;
                                        var count = 0;
                                        var count_1 = 0;
                                        var len = 0;
                                        angular.forEach($scope.feedbackReceived, function (feedback) {
                                            count_1 = 0;
                                            if (order.order_id == feedback.mainorder_number) {
                                                angular.forEach(order.suborder_id, function (suborder) {
                                                    len = order.suborder_id.length;
                                                    count_1 += 1;
                                                    if (feedback.call_count < $scope.maxCallsToBeMade && suborder.orderid == feedback.subOrder_number && feedback.call_status.indexOf(':5}') == -1) {
                                                        if (suborder.status == 'Delivered' || suborder.status == 'Refunded') {
                                                            count += 1;
                                                            suborder.over = true;
                                                            done = true;
                                                            var check = false;
                                                            angular.forEach($scope.viewallorderstemp, function (temporder) {
                                                                if (!check && temporder.order_id == order.order_id && (temporder.order_status == 'Delivered' || temporder.order_status == 'Cancelled')) { //fully delivered orders only condition
                                                                    check = true;
                                                                    $scope.viewallorders.push(temporder);
                                                                }
                                                            })
                                                        }
                                                    } else {
                                                        if (suborder.over == undefined && (suborder.orderid == feedback.subOrder_number)) {
                                                            if (feedback.call_status.indexOf(':5}') != -1 && feedback.call_count < $scope.maxCallsToBeMade) {
                                                                suborder.over = true;
                                                                if (len == 1) {
                                                                    done = true;
                                                                } else {
                                                                    if (count == 0 && count_1 == len) {
                                                                        done = true
                                                                    } else if (count > 0) {
                                                                        done = false;
                                                                    } else
                                                                    {
                                                                        if (done) {
                                                                            done = true;
                                                                        }
                                                                    }
                                                                }
                                                            } else if (feedback.call_count >= $scope.maxCallsToBeMade) {
                                                                suborder.over = true;
                                                                done = true;
                                                            }
                                                        } else {
                                                            if (suborder.over == undefined) {
                                                                if (suborder.orderid == feedback.subOrder_number) {
                                                                    if ((suborder.status == "Delivered" || suborder.status == "Refunded")) {
                                                                        var index = $scope.feedbackReceived.findIndex(obj => obj.subOrder_number == suborder.orderid);
                                                                        if (index > -1) {
                                                                            if ($scope.feedbackReceived[index].call_status.indexOf(":5}") == -1) {
                                                                                done = false;
                                                                                count += 1;
                                                                                suborder.over = true;
                                                                                //return;
                                                                            }
                                                                        } else {
                                                                            if (suborder.status == "Delivered" || suborder.status == "Refunded") {
                                                                                done = false;
                                                                                count += 1;
                                                                                suborder.over = true;
                                                                            } else {
                                                                                if (done) {
                                                                                    done = true;
                                                                                    suborder.over = true;
                                                                                }
                                                                            }
                                                                        }
                                                                    } else {
                                                                        done = true;
                                                                        suborder.over = true;
                                                                    }
                                                                } else {
                                                                    if (suborder.status == "Delivered" || suborder.status == "Refunded") {
                                                                        var index = $scope.feedbackReceived.findIndex(obj => obj.subOrder_number == suborder.orderid);
                                                                        if (index > -1) {
                                                                            if ($scope.feedbackReceived[index].call_status.indexOf(":5}") == -1) {
                                                                                done = false;
                                                                                count += 1;
                                                                                suborder.over = true;
                                                                                //return;
                                                                            } else {
                                                                                if (done || count == 0) {
                                                                                    done = true;
                                                                                    suborder.over = true;
                                                                                }
                                                                            }
                                                                        } else {
                                                                            done = false;
                                                                            count += 1;
                                                                            suborder.over = true;
                                                                        }
                                                                    } else {
                                                                        suborder.over = true;
                                                                        if (done || count == 0 || count_1 == len)
                                                                            done = true;
                                                                    }
                                                                }
                                                            }
                                                            /*else{
                                                             
                                                             }*/
                                                        }

                                                    }
                                                })
                                            }

                                        })
                                        if (!done) {
                                            done = true;
                                            var check = false;
                                            angular.forEach($scope.viewallorderstemp, function (temporder) {
                                                if (!check && temporder.order_id == order.order_id && (temporder.order_status == 'Delivered' || temporder.order_status == 'Cancelled')) { //fully delivered orders only condition
                                                    check = true;
                                                    $scope.viewallorders.push(temporder);
                                                }
                                            })
                                        }
                                    })
                                } else {
                                    var mainorder_temp = [];
                                    angular.forEach(mainorder, function (order) {
                                        var total_suborders_count = order.suborder_id.length;
                                        var increment_flag = 0;
                                        angular.forEach(order.suborder_id, function (suborder) {
                                            if (suborder.status == 'Delivered' || suborder.status == 'Refunded') {
                                                increment_flag = increment_flag + 1;
                                            }
                                        });
                                        if (increment_flag == total_suborders_count) {
                                            mainorder_temp.push(order);
                                        }
                                    });
                                    //mainorder_temp - fully delivered/refunded orders
                                    angular.forEach(mainorder_temp, function (order) {
                                        var done = false;

                                        if (!done) {
                                            angular.forEach(order.suborder_id, function (suborder) {
                                                if (!done)
                                                    if (suborder.status == 'Delivered' || suborder.status == 'Refunded') {
                                                        done = true;
                                                        var check = false;
                                                        angular.forEach($scope.viewallorderstemp, function (temporder) {
                                                            if (!check && temporder.order_id == order.order_id) {
                                                                check = true;
                                                                $scope.viewallorders.push(temporder);
                                                            }
                                                        })
                                                    }
                                            })



                                        }
                                    });
                                }
                                if ($scope.viewallorders.length == 0) {
                                    var popupdata = 'No Refunded or Delivered orders to be displayed for the given time range';
                                    $scope.popupopen('generalpopup', popupdata, $scope);
                                }
                            });
                        else
                        if ($scope.viewallorders.length == 0) {
                            var popupdata = 'No Refunded or Delivered orders to be displayed for the given time range';
                            $scope.popupopen('generalpopup', popupdata, $scope);
                        }
                        $scope.loading = false;
                        /*if(mainorder.length!=0 && mainorder.length==$scope.viewallorderstemp.length){
                         //console.log(mainorder);
                         var timer=0;
                         $scope.loading=true;
                         angular.forEach(mainorder,function(main){
                         var length=0;
                         var times=0;
                         ind+=1;
                         var done=false;
                         //console.log('order id : '+main.order_id)
                         //console.log('entry timer : '+timer);
                         angular.forEach(main.suborder_id,function(suborder){
                         if(!done)
                         setTimeout(function(){fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, Leykart_DatabaseConstant.urlpath, 'CheckOrderID', {'orderID':suborder.orderid}).then(function(response) {
                         times+=1;
                         //console.log('suborder id : '+main.suborder_id+' starting time : '+timer)
                         //console.log(response.data)
                         //response.data = $filter('orderBy')(response.data, 'id', true)
                         //console.log(response.data)
                         //console.log("OrderID" + orderID);
                         //console.log(response.data.length);
                         //console.log(suborder);
                         if (response.data.length == undefined && (suborder.status=='Refunded'||suborder.status=='Delivered')) {
                         length+=1;
                         done=true;
                         }
                         if(done){
                         //main.feedbackProvided="Yes";
                         if(length>0){
                         var check=true;
                         angular.forEach($scope.viewallorderstemp,function(ord){
                         if(check){
                         if(ord.order_id==main.order_id){
                         //ord.feedbackProvided=main.feedbackProvided;
                         $scope.viewallorders.push(ord);
                         check=false;
                         }
                         } 
                         });}
                         
                         }
                         //console.log('suborder id : '+main.suborder_id+' leaving time : '+timer)
                         timer+=500;
                         });},timer);
                         
                         });
                         if(ind==mainorder.length){
                         $scope.loading=false;
                         }
                         
                         if(timer){
                         timer=0;
                         }
                         });
                         
                         }
                         else{
                         var popupdata='No orders found with status as Delivered or Refunded for the given date range.';
                         $scope.popupopen('generalpopup',popupdata,$scope);
                         $scope.loading=false;
                         }*/

                        //console.log(mainorder);

                    }, function (error) {});


        }


        // $scope.loading = false


        // Start of  fetching the data based on Date

        $scope.typeoffeedback = function ($event, feedbacktype, value) {
            $scope.loading = true
            $scope.orderNo = value
            $scope.crossModule = $scope.feedbackReceived;
            //console.log("typeoffeedback   " + feedbacktype)
            if (feedbacktype !== 'Cancelled') {
                // $scope.feedback.regfeedbacktype=true;
                // $scope.feedback.cancelfeedbacktype=false;
                // var popupdata = ""
                // $scope.popupopen('regfeedback',popupdata,$scope)

                // console.log("inside")
                // //$state.go("getfeedback.regfeedback");
                $scope.$broadcast('regtype', $scope.feedback.regfeedbacktype);
                /*$scope.selectedOrder=value;*/
                $scope.optRadButtons = document.getElementsByName("optradioComment");
                angular.forEach($scope.optRadButtons, function (opt) {
                    opt.checked = false;
                });
                $scope.radButtons = document.getElementsByName("optradio");
                angular.forEach($scope.radButtons, function (opt) {
                    opt.checked = false;
                });
                $scope.activateTextBox = false;
                $scope.starRating = document.getElementsByClassName("star");
                angular.forEach($scope.starRating, function (star, index) {

                    star.classList.remove("filled");

                });
                var textElement = document.getElementById("commentInput");
                if (textElement) {
                    textElement.value = "";
                    //textElement.disabled=true;
                }
                var feedbackComment = document.getElementById('feedbackComment');
                if (feedbackComment) {
                    feedbackComment.value = "";
                }
                var checkBx = document.getElementById("mainSelect");
                if (checkBx) {
                    checkBx.checked = false;
                }
                $scope.loading = false
                $state.go("getfeedback.regfeedback");

            } else {
                // $scope.feedback.cancelfeedbacktype=true;
                // $scope.feedback.regfeedbacktype=false;
                // var popupdata = ""
                // $scope.popupopen('feedbackforcancelation',popupdata,$scope)

                // $state.go("getfeedback.cancelfeedback");
                $scope.$broadcast('canceltype', $scope.feedback.cancelfeedbacktype);
                $scope.radButtons = document.getElementsByName("optradio");
                angular.forEach($scope.radButtons, function (opt) {
                    opt.checked = false;
                });
                $scope.starRating = document.getElementsByClassName("star");
                angular.forEach($scope.starRating, function (star, index) {

                    star.classList.remove("filled");

                });
                var textElement = document.getElementById("commentInput");
                if (textElement) {
                    textElement.value = "";
                }
                var feedbackComment = document.getElementById('feedbackComment');
                if (feedbackComment) {
                    feedbackComment.value = "";
                }
                var checkBx = document.getElementById("mainSelect");
                if (checkBx) {
                    checkBx.checked = false;
                }
                $scope.loading = false
                $state.go("getfeedback.cancelfeedback");

            }
            var elem = $event.currentTarget || $event.srcElement;
            var elem1 = document.getElementById("highlight-row");
            if (elem1) {
                elem1.removeAttribute("id")
            }
            elem.parentElement.setAttribute("id", "highlight-row");
            /*console.log(elem)*/

            //$scope.$broadcast('regtype', $scope.feedback.regfeedbacktype);
            //$scope.$broadcast('canceltype', $scope.feedback.cancelfeedbacktype);
            //$scope.$digest();

        }

        // start of  Sub order details of input order id
        $scope.orderOrsuborderpopupopen = function (popuptype, orderOrsuborderid) {
            //console.log("called   " + orderOrsuborderid)
            //var path = magento_ConstantApi.orderdetailurlpath + orderOrsuborderid;
            //authenticationSvc.login('GET', magento_ConstantApi.Apiendpoint, path, null, magento_ConstantApi.Headers)
            var data = {"orderid": orderOrsuborderid}
            var path = 'orderdetailurlpath';
            authenticationSvc.login('POST', magento_ConstantApi.Apiendpoint, path, data)
                    .then(function (response) {
                        //console.log(response.data)

                        if (popuptype === "Suborderpopup")
                            $scope.popupopen(popuptype, response.data[0][0], $scope)

                    },
                            function (response) {
                                console.log("Error response received  while getting sub order details ")
                                console.log(response)

                            })
        }
        // end of order pop up
        $scope.$on('feedbackStatus', function (event, data) {
            //console.log("feedback status received")
            $scope.loading = true
            //console.log(event)
            $scope.viewallorderdetails();
            $scope.loading = false;

            //$scope.regfeedbacktype =data;
        });


    }
])




app.controller("regularfeedbackcntrl", ['$scope', 'magento_ConstantApi', 'authenticationSvc', 'fetchdatabase', 'Leykart_DatabaseConstant',
    function ($scope, magento_ConstantApi, authenticationSvc, fetchdatabase, Leykart_DatabaseConstant) {


        $scope.$on('regtype', function (event, data) {
            //console.log("regular brodcast received")
            $scope.loading = true;
            $scope.selectedOrderIds = [];
            //console.log(event)
            $scope.subOrderdetails();

            $scope.selectAll = true;

            //$scope.regfeedbacktype =data;
        });
        //$scope.regfeedbacktype=true;

        // start of to get Sub order details of input order id 
        $scope.resetStarRating = function () {
            $scope.rating1 = 1;
        }
        $scope.setCallStatus = function (order) {
            var dataObj = {};
            var done = false;
            var index;
            if (order.presentAlready) {
                done = true;
                if (order.call_count < $scope.maxCallsToBeMade) {
                    order.method = 'Upd';
                    order.call_count = order.call_count + 1;
                    //var data = JSON.parse($scope.callStatus);
                    index = $scope.callStatus.findIndex(obj => obj.status_id == order.selected_status.status_id);
                    if (index >= 0) {
                        order.call_status += '{' + order.call_count + ':' + (order.selected_status.status_id) + '}';
                        order.times = 1;
                        dataObj = {
                            'mainorder': null,
                            'order': [order],
                            'feedbacktype': null,
                            'feedbackoptions': null,
                            'customer_name': $scope.customer.name,
                            'mobile_no': $scope.customer.mobile_no,
                            'shipping_address': null,
                            'customer_type': null
                        }
                    } else {
                        done = false;
                    }
                }
            } else {
                order.method = 'Ins';
                done = true;
                order.call_count = 1;
                //var data = JSON.parse($scope.callStatus);
                order.times = $scope.feedbackQuestions.length;
                index = $scope.callStatus.findIndex(obj => obj.status_id == order.selected_status.status_id);
                if (index >= 0) {
                    order.call_status += ('{' + order.call_count + ':' + (order.selected_status.status_id) + '}');
                    dataObj = {
                        'mainorder': $scope.orderNo,
                        'order': [order],
                        'feedbacktype': 1,
                        'feedbackoptions': null,
                        'customer_name': $scope.customer.name,
                        'mobile_no': $scope.customer.mobile_no,
                        'shipping_address': $scope.customer.shipping_address,
                        'customer_type': $scope.customer.customer_type
                    }
                } else {
                    done = false;
                }
            }

            if (done)
                fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, Leykart_DatabaseConstant.urlpath, 'sendfeedback', dataObj).then(function (response) {
                    $scope.loading = true;
                    var popupdata = 'Status updated.';
                    $scope.regfeedsuborderdetails = [];
                    $scope.viewallorderdetails();
                    $scope.selectedOrderIds = [];
                    $scope.selectedFeedbackOptions = [];
                    $scope.radButtons = document.getElementsByName("optradio");
                    angular.forEach($scope.radButtons, function (opt) {
                        opt.checked = false;
                    });
                    $scope.radButtons = document.getElementsByName("optradioComment");
                    angular.forEach($scope.radButtons, function (opt) {
                        opt.checked = false;
                    });
                    $scope.feedbackSent = false;
                    $scope.customer = {"name": '', 'mobile_no': ''};
                    $scope.popupopen('generalpopup', popupdata, $scope);
                    $scope.loading = false;
                });
            else {
                $scope.loading = true;
                var popupdata = 'Status cannot be updated as maximum call count has exceeded.';
                if (index < 0) {
                    popupdata = 'Please enter a valid status.'
                }
                $scope.regfeedsuborderdetails = [];
                $scope.selectedOrderIds = [];
                $scope.selectedFeedbackOptions = [];
                $scope.radButtons = document.getElementsByName("optradio");
                angular.forEach($scope.radButtons, function (opt) {
                    opt.checked = false;
                });
                $scope.radButtons = document.getElementsByName("optradioComment");
                angular.forEach($scope.radButtons, function (opt) {
                    opt.checked = false;
                });
                $scope.feedbackSent = false;
                $scope.customer = {"name": '', 'mobile_no': ''};
                $scope.popupopen('generalpopup', popupdata, $scope);
                $scope.loading = false;
            }

        }
        $scope.customer = {"name": '', 'mobile_no': ''};
        $scope.subOrderdetails = function () {
            $scope.loading = true
            //var path = magento_ConstantApi.orderdetailurlpath + $scope.orderNo;
            //authenticationSvc.login('GET', magento_ConstantApi.Apiendpoint, path, null, magento_ConstantApi.Headers)
            var data = {"orderid": $scope.orderNo}
            var path = 'orderdetailurlpath';
            $scope.customer = {"name": '', 'mobile_no': ''};
            authenticationSvc.login('POST', magento_ConstantApi.Apiendpoint, path, data)
                    .then(function (response) {
                        var suborder = []
                        //console.log(response.data[0])
                        $scope.customer.name = response.data[0].customer_name;
                        $scope.customer.mobile_no = response.data[0].mobile_no;
                        $scope.customer.shipping_address = response.data[0].shipping_address;
                        $scope.customer.customer_type = response.data[0].customer_type;
                        for (var i = 0; typeof (response.data[0][i]) === 'object'; i++)
                            suborder.push(response.data[0][i])
                        $scope.regfeedsuborderdetails = suborder;
                        angular.forEach($scope.regfeedsuborderdetails, function (order) {
                            order.selected = false;
                            var done = false;
                            order.presentAlready = false;
                            if ($scope.feedbackReceived) {
                                angular.forEach($scope.feedbackReceived, function (feedback) {
                                    if (!done && feedback.subOrder_number == order.suborder_id) {
                                        if (feedback.call_count < $scope.maxCallsToBeMade && feedback.call_status.indexOf(':5}') == -1) {
                                            order.presentAlready = true;
                                            done = true;
                                            order.call_count = parseInt(feedback.call_count);
                                            var index = $scope.callStatus.findIndex(obj => obj.status_id == feedback.call_status[feedback.call_status.length - 2]);
                                            order.call_status = feedback.call_status;
                                            order.last_call_status = $scope.callStatus[index].status;
                                            order.feedbackCanBeProvided = true;
                                        } else if (feedback.call_count == $scope.maxCallsToBeMade || feedback.call_status.indexOf(':5}') != -1) {
                                            done = true;
                                            order.presentAlready = true;
                                            order.call_count = parseInt(feedback.call_count);
                                            //var index=$scope.callStatus.findIndex(obj=>obj.status_id==feedback.call_status[feedback.call_status.length-2]);
                                            order.call_status = feedback.call_status;
                                            order.last_call_status = "Feedback Received";
                                            order.feedbackCanBeProvided = false;
                                        }

                                    }
                                })

                                if (!done && (order.status == 'Delivered' || order.status == 'Refunded')) {
                                    done = true;
                                    order.presentAlready = false;
                                    order.call_count = 0;
                                    order.call_status = '';
                                    order.feedbackCanBeProvided = true;
                                }
                            } else {
                                if (order.status == 'Delivered' || order.status == 'Refunded') {
                                    done = true;
                                    order.presentAlready = false;
                                    order.call_count = 0;
                                    order.call_status = '';
                                    order.feedbackCanBeProvided = true;
                                } else {
                                    done = true;
                                    order.presentAlready = false;
                                    order.call_count = null;
                                    order.call_status = null;
                                    order.feedbackCanBeProvided = null;
                                }
                            }
                            if ((order.status == 'Delivered' || order.status == 'Refunded') && order.feedbackCanBeProvided) {
                                order.selected = true;
                                $scope.selectedOrderIds.push(order.suborder_id);
                            }
                        })
                        //console.log($scope.regfeedsuborderdetails )
                        $scope.loading = false
                    },
                            function (response) {
                                console.log("Error response received  while getting Suborder details for regular feedback ")
                                console.log(response)
                                $scope.loading = false

                            })
        }
        //$scope.subOrderdetails()
        // end of to get sub order details of input order id 

        // for capturing feedback
        //$scope.feebackvalue = {"ques1" : "", "ques2" : "", "ques3" : "", "ques4" : "",}
        $scope.feedbackQuestions = [];
        $scope.feedbackOptions = [];
        $scope.getFeedbackQuestions = function () {
            var dataObj = {
                'feedbackType': 'Regular'
            };
            $scope.feedbackQuestions = [];
            fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, Leykart_DatabaseConstant.urlpath, 'FeedbackQues', dataObj).then(function (response) {
                //console.log(response.data)
                //response.data = $filter('orderBy')(response.data, 'id', true)
                //console.log(response.data)
                angular.forEach(response.data, function (ques) {
                    $scope.feedbackQuestions.push({
                        'serialNo': ques.serialNo,
                        'question': ques.questions,
                        'qType': ques.question_type
                    });
                });
                //$scope.callersType = response.data;
                //console.log($scope.feedbackQuestions);
                $scope.getFeedbackOptions();
            }, function (error) {
                console.log("error in getting feedback questions")
                console.log(error)
            });
        }


        $scope.getFeedbackOptions = function () {
            $scope.qid_array = [];
            angular.forEach($scope.feedbackQuestions, function (ques) {
                $scope.qid_array.push({
                    'serialNo': ques.serialNo,
                    'question': ques.question,
                    'qType': ques.qType
                });
            })
            $scope.feedbackOptions = [];
            var dataObj = {
                'qid_array': $scope.qid_array
            };
            fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, Leykart_DatabaseConstant.urlpath, 'FeedbackOptions', dataObj).then(function (response) {
                //console.log(response.data)
                //response.data = $filter('orderBy')(response.data, 'id', true)
                //console.log(response.data)
                var ind = 0;
                angular.forEach($scope.qid_array, function (ques) {
                    $scope.feedbackOptions.push({
                        'qid': ques.serialNo,
                        'question': ques.question,
                        'qType': ques.qType
                    });
                    $scope.optionsArr = [];
                    angular.forEach(response.data, function (opt) {
                        angular.forEach(opt, function (option) {
                            if (option.qno == $scope.qid_array[ind].serialNo) {
                                $scope.optionsArr.push({
                                    'optno': option.optno,
                                    'option': option.options
                                });
                            }
                        });
                    });
                    angular.forEach($scope.feedbackOptions, function (arr) {
                        if (arr.qid == $scope.qid_array[ind].serialNo) {
                            arr.option = $scope.optionsArr;
                        }
                    });
                    ind += 1;
                });
                //console.log($scope.feedbackOptions);
                //$scope.callersType = response.data;
            }, function (error) {
                console.log("error in getting feedback options")
                console.log(error)
            });
        }
        $scope.selectedFeedbackOptions = [];
        $scope.selectedOrderIds = [];
        $scope.comment = {
            "inputComment": ''
        };
        $scope.feedbackComment = {
            "inputComment": ''
        };
        $scope.activateTextBox = false;
        $scope.deactivateComment = function () {
            if ($scope.activateTextBox) {
                $scope.activateTextBox = !$scope.activateTextBox;
            }
            if (!$scope.activateTextBox) {
                $scope.comment.inputComment = null;
                var textElement = document.getElementById("commentInput");
                if (textElement) {
                    textElement.value = "";
                    textElement.disabled = true;
                }

            }
            /*var corresponding_Opt = document.getElementsByName("optradioComment");
             angular.forEach(corresponding_Opt, function(opt) {
             opt.checked = false;
             })*/
        }
        $scope.activateComment = function () {
            if (!$scope.activateTextBox) {
                $scope.activateTextBox = true;
            }
            var textElement = document.getElementById("commentInput");
            if (textElement) {
                textElement.value = "";
                textElement.disabled = false;
            }
            /*if(!$scope.activateTextBox){
             $scope.comment.inputComment=null;
             var textElement = document.getElementById("commentInput");
             if (textElement) {
             textElement.value = "";
             textElement.disabled=true;
             }
             
             }*/}
        $scope.setFeedback = function (qid, optid, comment, rating) {
            var check = 0;
            if (!comment) {
                angular.forEach($scope.selectedFeedbackOptions, function (selected) {
                    if (selected.qid == qid) {
                        selected.optid = optid;
                        selected.comment = null;
                        check += 1;
                    }
                });
                if (check != 1) {
                    $scope.selectedFeedbackOptions.push({
                        'qid': qid,
                        'optid': optid,
                        'comment': null
                    });
                    check = 0;
                }
            } else {
                angular.forEach($scope.selectedFeedbackOptions, function (selected) {
                    if (selected.qid == qid) {
                        if (rating > 0) {
                            selected.optid = optid;
                            selected.comment = rating;
                        } else {
                            if (qid == 9 || qid == 10) {
                                selected.comment = $scope.feedbackComment.inputComment;
                            } else {
                                selected.comment = $scope.comment.inputComment;
                            }

                        }
                        check += 1;
                    }
                });
                if (check != 1) {
                    if (rating > 0) {
                        $scope.selectedFeedbackOptions.push({
                            'qid': qid,
                            'optid': optid,
                            'comment': rating
                        });
                    } else {
                        if (optid != '') {
                            if (qid == 9 || qid == 10) {
                                $scope.selectedFeedbackOptions.push({
                                    'qid': qid,
                                    'optid': optid,
                                    'comment': $scope.feedbackComment.inputComment
                                });
                            } else {
                                $scope.selectedFeedbackOptions.push({
                                    'qid': qid,
                                    'optid': optid,
                                    'comment': $scope.comment.inputComment
                                });
                            }
                        } else {
                            var popupdata = "Select an option before you enter any remark";
                            $scope.popupopen('generalpopup', popupdata, $scope);
                            var textElement = document.getElementById("commentInput");
                            var feedbackCommentSec = document.getElementById("feedbackComment");
                            if (textElement) {
                                textElement.value = "";
                                //textElement.disabled=true;
                            }
                            if (feedbackCommentSec) {
                                feedbackCommentSec.value = '';
                            }
                        }
                    }
                    check = 0;
                }
            }
            //console.log($scope.selectedFeedbackOptions);
        }

        $scope.checkIfOrderPresent = function (orderID) {
            var dataObj = {
                'orderID': orderID
            };
            fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, Leykart_DatabaseConstant.urlpath, 'CheckOrderID', dataObj).then(function (response) {
                //console.log(response.data)
                //response.data = $filter('orderBy')(response.data, 'id', true)
                //console.log(response.data)
                //console.log("OrderID" + orderID);
                //console.log(response.data.length);
                if (response.data.length != undefined) {
                    angular.forEach($scope.regfeedsuborderdetails, function (order) {
                        if (order.suborder_id == orderID) {
                            order.presentAlready = true;

                        }
                    })
                } else {
                    angular.forEach($scope.regfeedsuborderdetails, function (order) {
                        if (order.suborder_id == orderID) {
                            order.presentAlready = false;

                        }
                    })
                }


            }, function (error) {
                console.log("error in getting feedback questions")
                console.log(error)
            });
        }

        $scope.sendFeedback = function () {
            $scope.loading = true;
            $scope.selectedOrders = [];
            if ($scope.selectedFeedbackOptions.length >= 1 && $scope.selectedFeedbackOptions.length == $scope.feedbackQuestions.length) {
                angular.forEach($scope.selectedOrderIds, function (orderid) {
                    angular.forEach($scope.regfeedsuborderdetails, function (order) {
                        if (orderid == order.suborder_id) {
                            $scope.selectedOrders.push(order);
                        }
                    })
                })
                if ($scope.feedbackReceived)
                    angular.forEach($scope.selectedOrders, function (order) {
                        var done = false;
                        if (order.presentAlready) {
                            if (order.feedbackCanBeProvided) {
                                order.call_count = parseInt(order.call_count) + 1;
                                order.call_status += '{' + order.call_count + ':5}';
                                order.method = 'UpdFB';
                            }
                        } else {
                            if (order.feedbackCanBeProvided) {
                                order.call_count = 1;
                                order.call_status += '{' + order.call_count + ':5}';
                                order.method = 'InsFB';
                            }
                        }
                    });
                else {
                    angular.forEach($scope.selectedOrders, function (order) {
                        if (order.feedbackCanBeProvided) {
                            order.call_count = 1;
                            order.call_status += '{1:5}';
                            order.method = 'InsFB';
                        }
                    })

                }
                var dataObj = {
                    'mainorder': $scope.orderNo,
                    'order': $scope.selectedOrders,
                    'feedbacktype': 1,
                    'feedbackoptions': $scope.selectedFeedbackOptions,
                    'customer_name': $scope.customer.name,
                    'mobile_no': $scope.customer.mobile_no,
                    'shipping_address': $scope.customer.shipping_address,
                    'customer_type': $scope.customer.customer_type
                }
                fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, Leykart_DatabaseConstant.urlpath, 'sendfeedback', dataObj).then(function (response) {
                    $scope.loading = true;
                    //console.log(response.data)
                    //response.data = $filter('orderBy')(response.data, 'id', true)
                    //console.log(response.data)
                    var popupdata = 'Feedback submitted successfully.';
                    //console.log(popupdata);
                    $scope.regfeedsuborderdetails = [];
                    $scope.selectedOrderIds = [];
                    $scope.selectedFeedbackOptions = [];
                    $scope.radButtons = document.getElementsByName("optradio");
                    angular.forEach($scope.radButtons, function (opt) {
                        opt.checked = false;
                    });
                    $scope.radButtons = document.getElementsByName("optradioComment");
                    angular.forEach($scope.radButtons, function (opt) {
                        opt.checked = false;
                    });
                    $scope.feedbackSent = false;
                    $scope.customer = {"name": '', 'mobile_no': ''};
                    $scope.popupopen('generalpopup', popupdata, $scope);
                    $scope.loading = false;
                }, function (error) {
                    console.log("error in getting feedback questions")
                    console.log(error)
                });
                $scope.$emit('feedbackStatus', $scope.feedbackSent);
                //$scope.loading=false;
            } else {
                var popupdata = 'Cannot submit empty feedback. Please answer all the questions.';
                $scope.popupopen('generalpopup', popupdata, $scope);
                $scope.loading = false;
            }

        }
        $scope.selectAll = false;
        $scope.isSelectAll = function () {
            $scope.selectedOrderIds = [];
            if ($scope.selectAll) {
                angular.forEach($scope.regfeedsuborderdetails, function (order) {
                    if ((order.status == 'Delivered' || order.status == 'Refunded') && order.feedbackCanBeProvided) {
                        order.selected = true;
                        $scope.selectedOrderIds.push(order.suborder_id);
                    }
                });
            } else {
                angular.forEach($scope.regfeedsuborderdetails, function (order) {
                    order.selected = false;
                });
                $scope.selectedOrderIds = [];
            }
            //console.log($scope.selectedOrderIds);
        }
        $scope.isChecked = function (checkboxVal, selectedOrderId) {
            if (!$scope.selectAll && checkboxVal) {
                $scope.selectedOrderIds.push(selectedOrderId);
                //console.log()
            } else if ($scope.selectAll && !checkboxVal) {
                $scope.selectAll = false;
                var ind = $scope.selectedOrderIds.indexOf(selectedOrderId);
                if (ind != -1) {
                    $scope.selectedOrderIds.splice(ind, 1);
                }
            } else if (checkboxVal) {
                $scope.selectedOrderIds.push(selectedOrderId);
            } else if (!checkboxVal) {
                var ind = $scope.selectedOrderIds.indexOf(selectedOrderId);
                if (ind != -1) {
                    $scope.selectedOrderIds.splice(ind, 1);
                }
            }
            //console.log($scope.selectedOrderIds);
        }
        $scope.rating1 = 1;
        //$scope.rating2=2;
        this.isReadonly = true;
        //console.log($scope.feebackvalue)

    }
])



app.controller("cancelfeedbackcntrl", ['$scope', 'magento_ConstantApi', 'authenticationSvc', 'fetchdatabase', 'Leykart_DatabaseConstant',
    function ($scope, magento_ConstantApi, authenticationSvc, fetchdatabase, Leykart_DatabaseConstant) {
        //$scope.setnavshow(true);
        $scope.$on('canceltype', function (event, data) {
            $scope.loading = true;
            $scope.selectedOrderIds = [];
            if ($scope.feedbackReceived)
                console.log($scope.feedbackReceived)
            //console.log(" canceltype brodcast received");
            //console.log(event )
            $scope.subOrderdetails();
            $scope.selectAll = true;
            //$scope.cancelfeedbacktype =data;
        });
        //$scope.cancelfeedbacktype=false;

        // start of to get Sub order details of input order id 
        $scope.resetStarRating = function () {
            $scope.rating1 = 1;
        }
        $scope.feedbackReceived;
        $scope.maxCallsToBeMade = 5;
        $scope.callStatus = [];
        $scope.getCallStatus = function () {
            fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, Leykart_DatabaseConstant.urlpath, 'getCallStatus', null).then(function (response) {
                if (response.data.indexOf('<script>') == -1) {
                    $scope.callStatus = response.data;
                }
            });
        }
        $scope.setCallStatus = function (order) {
            var dataObj;
            var done = false;
            var index;
            if (order.presentAlready) {
                if (order.call_count < $scope.maxCallsToBeMade) {
                    done = true;
                    order.method = 'Upd';
                    order.call_count = order.call_count + 1;
                    //var data = JSON.parse($scope.callStatus);
                    index = $scope.callStatus.findIndex(obj => obj.status_id == order.selected_status.status_id);
                    if (index >= 0) {
                        order.call_status += '{' + order.call_count + ':' + (order.selected_status.status_id) + '}';
                        order.times = 1;
                        dataObj = {
                            'mainorder': null,
                            'order': [order],
                            'feedbacktype': null,
                            'feedbackoptions': null,
                            'customer_name': $scope.customer.name,
                            'mobile_no': $scope.customer.mobile_no,
                            'shipping_address': null,
                            'customer_type': null
                        }
                    } else {
                        done = false;
                    }
                }
            } else {
                done = true;
                order.method = 'Ins';
                order.call_count = 1;
                //var data = JSON.parse($scope.callStatus);
                order.times = $scope.feedbackQuestions.length;
                index = $scope.callStatus.findIndex(obj => obj.status_id == order.selected_status.status_id);
                if (index >= 0) {
                    order.call_status += ('{' + order.call_count + ':' + (order.selected_status.status_id) + '}');
                    dataObj = {
                        'mainorder': $scope.orderNo,
                        'order': [order],
                        'feedbacktype': 1,
                        'feedbackoptions': null,
                        'customer_name': $scope.customer.name,
                        'mobile_no': $scope.customer.mobile_no,
                        'shipping_address': $scope.customer.shipping_address,
                        'customer_type': $scope.customer.customer_type

                    }
                } else {
                    done = false;
                }
            }
            if (done)
                fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, Leykart_DatabaseConstant.urlpath, 'sendfeedback', dataObj).then(function (response) {
                    $scope.loading = true;
                    var popupdata = 'Status updated.';
                    $scope.cancelfeedsuborderdetails = [];
                    $scope.viewallorderdetails();
                    $scope.selectedOrderIds = [];
                    $scope.selectedFeedbackOptions = [];
                    $scope.radButtons = document.getElementsByName("optradio");
                    angular.forEach($scope.radButtons, function (opt) {
                        opt.checked = false;
                    });
                    $scope.radButtons = document.getElementsByName("optradioComment");
                    angular.forEach($scope.radButtons, function (opt) {
                        opt.checked = false;
                    });
                    var feedbackComment = document.getElementById('feedbackComment');
                    if (feedbackComment) {
                        feedbackComment.value = "";
                    }
                    $scope.feedbackSent = false;
                    $scope.customer = {"name": '', 'mobile_no': ''};
                    $scope.popupopen('generalpopup', popupdata, $scope);
                    $scope.loading = false;
                });
            else {
                $scope.loading = true;
                var popupdata = 'Status cannot be updated as maximum call count has exceeded.';
                if (index < 0) {
                    popupdata = 'Please enter a valid status.'
                }
                $scope.cancelfeedsuborderdetails = [];
                $scope.selectedOrderIds = [];
                $scope.selectedFeedbackOptions = [];
                $scope.radButtons = document.getElementsByName("optradio");
                angular.forEach($scope.radButtons, function (opt) {
                    opt.checked = false;
                });
                $scope.radButtons = document.getElementsByName("optradioComment");
                angular.forEach($scope.radButtons, function (opt) {
                    opt.checked = false;
                });
                var feedbackComment = document.getElementById('feedbackComment');
                if (feedbackComment) {
                    feedbackComment.value = "";
                }
                $scope.feedbackSent = false;
                $scope.customer = {"name": '', 'mobile_no': ''};
                $scope.popupopen('generalpopup', popupdata, $scope);
                $scope.loading = false;
            }
        }
        $scope.getCallStatus();
        $scope.customer = {"name": '', 'mobile_no': ''};
        $scope.subOrderdetails = function () {
            $scope.loading = true
            //var path = magento_ConstantApi.orderdetailurlpath + $scope.orderNo;
            //authenticationSvc.login('GET', magento_ConstantApi.Apiendpoint, path, null, magento_ConstantApi.Headers)
            var data = {"orderid": $scope.orderNo}
            var path = 'orderdetailurlpath';
            $scope.customer = {"name": '', 'mobile_no': ''};
            authenticationSvc.login('POST', magento_ConstantApi.Apiendpoint, path, data)
                    .then(function (response) {
                        var suborder = []
                        //console.log(response.data[0])
                        $scope.customer.name = response.data[0].customer_name;
                        $scope.customer.mobile_no = response.data[0].mobile_no;
                        $scope.customer.shipping_address = response.data[0].shipping_address;
                        $scope.customer.customer_type = response.data[0].customer_type;
                        for (var i = 0; typeof (response.data[0][i]) === 'object'; i++)
                            suborder.push(response.data[0][i])
                        $scope.cancelfeedsuborderdetails = suborder;
                        //console.log($scope.regfeedsuborderdetails )
                        angular.forEach($scope.cancelfeedsuborderdetails, function (order) {
                            order.selected = false;
                            var done = false;
                            order.presentAlready = false;
                            if ($scope.feedbackReceived) {
                                angular.forEach($scope.feedbackReceived, function (feedback) {
                                    if (!done && feedback.subOrder_number == order.suborder_id) {
                                        if (feedback.call_count < $scope.maxCallsToBeMade && feedback.call_status.indexOf(':5}') == -1) {
                                            order.presentAlready = true;
                                            done = true;
                                            order.call_count = parseInt(feedback.call_count);
                                            var index = $scope.callStatus.findIndex(obj => obj.status_id == feedback.call_status[feedback.call_status.length - 2]);
                                            order.call_status = feedback.call_status;
                                            order.last_call_status = $scope.callStatus[index].status;
                                            order.feedbackCanBeProvided = true;
                                        } else if (feedback.call_count == $scope.maxCallsToBeMade || feedback.call_status.indexOf(':5}') != -1) {
                                            done = true;
                                            order.presentAlready = true;
                                            order.call_count = parseInt(feedback.call_count);
                                            var index = $scope.callStatus.findIndex(obj => obj.status_id == feedback.call_status[feedback.call_status.length - 2]);
                                            order.call_status = feedback.call_status;
                                            order.last_call_status = $scope.callStatus[index].status;
                                            order.feedbackCanBeProvided = false;
                                        }

                                    }
                                })

                                if (!done && (order.status == 'Delivered' || order.status == 'Refunded')) {
                                    done = true;
                                    order.presentAlready = false;
                                    order.call_count = 0;
                                    order.call_status = '';
                                    order.feedbackCanBeProvided = true;
                                }
                            } else {
                                if (order.status == 'Delivered' || order.status == 'Refunded') {
                                    done = true;
                                    order.presentAlready = false;
                                    order.call_count = 0;
                                    order.call_status = '';
                                    order.feedbackCanBeProvided = true;
                                } else {
                                    done = true;
                                    order.presentAlready = false;
                                    order.call_count = null;
                                    order.call_status = null;
                                    order.feedbackCanBeProvided = null;
                                }
                            }
                            if ((order.status == 'Delivered' || order.status == 'Refunded') && order.feedbackCanBeProvided) {
                                order.selected = true;
                                $scope.selectedOrderIds.push(order.suborder_id);
                            }
                        })
                        //console.log($scope.regfeedsuborderdetails )
                        $scope.loading = false
                    },
                            function (response) {
                                console.log("Error response received  while getting Suborder details for Cancelled feedback ")
                                console.log(response)
                                $scope.loading = false

                            })
        }
        //$scope.subOrderdetails()
        // end of to get sub order details of input order id 

        // for capturing feedback
        //$scope.feebackvalue = {"ques1" : "", "ques2" : "", "ques3" : "", "ques4" : "",}
        $scope.feedbackQuestions = [];
        $scope.feedbackOptions = [];
        $scope.getFeedbackQuestions = function () {
            var dataObj = {
                'feedbackType': 'Cancelled'
            };
            $scope.feedbackQuestions = [];
            fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, Leykart_DatabaseConstant.urlpath, 'FeedbackQues', dataObj).then(function (response) {
                //console.log(response.data)
                //response.data = $filter('orderBy')(response.data, 'id', true)
                //console.log(response.data)
                angular.forEach(response.data, function (ques) {
                    $scope.feedbackQuestions.push({
                        'serialNo': ques.serialNo,
                        'question': ques.questions,
                        'qType': ques.question_type
                    });
                });
                //$scope.callersType = response.data;
                //console.log($scope.feedbackQuestions);
                $scope.getFeedbackOptions();
            }, function (error) {
                console.log("error in getting feedback questions")
                console.log(error)
            });
        }


        $scope.getFeedbackOptions = function () {
            $scope.qid_array = [];
            angular.forEach($scope.feedbackQuestions, function (ques) {
                $scope.qid_array.push({
                    'serialNo': ques.serialNo,
                    'question': ques.question,
                    'qType': ques.qType
                });
            })
            $scope.feedbackOptions = [];
            var dataObj = {
                'qid_array': $scope.qid_array
            };
            fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, Leykart_DatabaseConstant.urlpath, 'FeedbackOptions', dataObj).then(function (response) {
                //console.log(response.data)
                //response.data = $filter('orderBy')(response.data, 'id', true)
                //console.log(response.data)
                var ind = 0;
                angular.forEach($scope.qid_array, function (ques) {
                    $scope.feedbackOptions.push({
                        'qid': ques.serialNo,
                        'question': ques.question,
                        'qType': ques.qType
                    });
                    $scope.optionsArr = [];
                    angular.forEach(response.data, function (opt) {
                        angular.forEach(opt, function (option) {
                            if (option.qno == $scope.qid_array[ind].serialNo) {
                                $scope.optionsArr.push({
                                    'optno': option.optno,
                                    'option': option.options
                                });
                            }
                        });
                    });
                    angular.forEach($scope.feedbackOptions, function (arr) {
                        if (arr.qid == $scope.qid_array[ind].serialNo) {
                            arr.option = $scope.optionsArr;
                        }
                    });
                    ind += 1;
                });
                //console.log($scope.feedbackOptions);
                //$scope.callersType = response.data;
            }, function (error) {
                console.log("error in getting feedback options")
                console.log(error)
            });
        }
        $scope.selectedFeedbackOptions = [];
        $scope.selectedOrderIds = [];
        $scope.comment = {
            "inputComment": ''
        };
        $scope.feedbackComment = {
            "inputComment": ''
        };
        $scope.activateTextBox = false;
        $scope.deactivateComment = function () {
            if ($scope.activateTextBox) {
                $scope.activateTextBox = !$scope.activateTextBox;
            }
            if (!$scope.activateTextBox) {
                $scope.comment.inputComment = null;
                var textElement = document.getElementById("commentInput");
                if (textElement) {
                    textElement.value = "";
                    textElement.disabled = true;
                }
                var feedbackComment = document.getElementById('feedbackComment');
                if (feedbackComment) {
                    feedbackComment.value = "";
                }

            }
            /*var corresponding_Opt = document.getElementsByName("optradioComment");
             angular.forEach(corresponding_Opt, function(opt) {
             opt.checked = false;
             })*/
        }
        $scope.activateComment = function () {
            if (!$scope.activateTextBox) {
                $scope.activateTextBox = true;
            }
            var textElement = document.getElementById("commentInput");
            if (textElement) {
                textElement.value = "";
                textElement.disabled = false;
            }
            /*if(!$scope.activateTextBox){
             $scope.comment.inputComment=null;
             var textElement = document.getElementById("commentInput");
             if (textElement) {
             textElement.value = "";
             textElement.disabled=true;
             }
             
             }*/}
        $scope.setFeedback = function (qid, optid, comment, rating) {
            var check = 0;
            if (!comment) {
                angular.forEach($scope.selectedFeedbackOptions, function (selected) {
                    if (selected.qid == qid) {
                        selected.optid = optid;
                        selected.comment = null;
                        check += 1;
                    }
                });
                if (check != 1) {
                    $scope.selectedFeedbackOptions.push({
                        'qid': qid,
                        'optid': optid,
                        'comment': null
                    });
                    check = 0;
                }
            } else {
                angular.forEach($scope.selectedFeedbackOptions, function (selected) {
                    if (selected.qid == qid) {
                        if (rating > 0) {
                            selected.optid = optid;
                            selected.comment = rating;
                        } else {
                            selected.comment = $scope.comment.inputComment;
                        }
                        check += 1;
                    }
                });
                if (check != 1) {
                    if (rating > 0) {
                        $scope.selectedFeedbackOptions.push({
                            'qid': qid,
                            'optid': optid,
                            'comment': rating
                        });
                    } else {
                        if (optid != '') {
                            $scope.selectedFeedbackOptions.push({
                                'qid': qid,
                                'optid': optid,
                                'comment': $scope.comment.inputComment
                            });
                        } else {
                            var popupdata = "Select an option before you enter any remark";
                            $scope.popupopen('generalpopup', popupdata, $scope);
                            var textElement = document.getElementById("commentInput");
                            if (textElement) {
                                textElement.value = "";
                                //textElement.disabled=true;
                            }
                            var feedbackComment = document.getElementById('feedbackComment');
                            if (feedbackComment) {
                                feedbackComment.value = "";
                            }
                        }
                    }
                    check = 0;
                }
            }
            //console.log($scope.selectedFeedbackOptions);
        }

        $scope.checkIfOrderPresent = function (orderID) {
            var dataObj = {
                'orderID': orderID
            };
            fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, Leykart_DatabaseConstant.urlpath, 'CheckOrderID', dataObj).then(function (response) {
                //console.log(response.data)
                //response.data = $filter('orderBy')(response.data, 'id', true)
                //console.log(response.data)
                //console.log("OrderID" + orderID);
                //console.log(response.data.length);
                if (response.data.length != undefined) {
                    angular.forEach($scope.cancelfeedsuborderdetails, function (order) {
                        if (order.suborder_id == orderID) {
                            order.presentAlready = true;

                        }
                    })
                } else {
                    angular.forEach($scope.cancelfeedsuborderdetails, function (order) {
                        if (order.suborder_id == orderID) {
                            order.presentAlready = false;

                        }
                    })
                }


            }, function (error) {
                console.log("error in getting feedback questions")
                console.log(error)
            });
        }

        $scope.sendFeedback = function () {
            $scope.loading = true;
            $scope.selectedOrders = [];
            if ($scope.selectedFeedbackOptions.length >= 1 && $scope.selectedFeedbackOptions.length == $scope.feedbackQuestions.length) {
                angular.forEach($scope.selectedOrderIds, function (orderid) {
                    angular.forEach($scope.cancelfeedsuborderdetails, function (order) {
                        if (orderid == order.suborder_id) {
                            $scope.selectedOrders.push(order);
                        }
                    })
                })
                if ($scope.feedbackReceived)
                    angular.forEach($scope.selectedOrders, function (order) {
                        var done = false;
                        if (order.presentAlready) {
                            if (order.feedbackCanBeProvided) {
                                order.call_count = parseInt(order.call_count) + 1;
                                order.call_status += '{' + order.call_count + ':5}';
                                order.method = 'UpdFB';
                            }
                        } else {
                            if (order.feedbackCanBeProvided) {
                                order.call_count = 1;
                                order.call_status += '{' + order.call_count + ':5}';
                                order.method = 'InsFB';
                            }
                        }
                    });
                else {
                    angular.forEach($scope.selectedOrders, function (order) {
                        if (order.feedbackCanBeProvided) {
                            order.call_count = 1;
                            order.call_status += '{1:5}';
                            order.method = 'InsFB';
                        }
                    })

                }
                var dataObj = {
                    'mainorder': $scope.orderNo,
                    'order': $scope.selectedOrders,
                    'feedbacktype': 2,
                    'feedbackoptions': $scope.selectedFeedbackOptions,
                    'customer_name': $scope.customer.name,
                    'mobile_no': $scope.customer.mobile_no,
                    'shipping_address': $scope.customer.shipping_address,
                    'customer_type': $scope.customer.customer_type
                }
                fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, Leykart_DatabaseConstant.urlpath, 'sendfeedback', dataObj).then(function (response) {
                    //console.log(response.data)
                    //response.data = $filter('orderBy')(response.data, 'id', true)
                    //console.log(response.data)
                    var popupdata = 'Feedback submitted successfully.';
                    //console.log(popupdata);
                    $scope.cancelfeedsuborderdetails = [];
                    $scope.selectedOrderIds = [];
                    $scope.selectedFeedbackOptions = [];
                    $scope.popupopen('generalpopup', popupdata, $scope);
                    $scope.loading = false;
                    $scope.radButtons = document.getElementsByName("optradio");
                    angular.forEach($scope.radButtons, function (opt) {
                        opt.checked = false;
                    });
                    $scope.radButtons = document.getElementsByName("optradioComment");
                    angular.forEach($scope.radButtons, function (opt) {
                        opt.checked = false;
                    });
                    $scope.customer = {"name": '', 'mobile_no': ''};
                    $scope.feedbackSent = false;
                    $scope.loading = false;



                }, function (error) {
                    console.log("error in getting feedback questions")
                    console.log(error)
                });
                $scope.$emit('feedbackStatus', $scope.feedbackSent);
            } else {
                var popupdata = 'Cannot submit empty feedback. Please answer all the questions.';
                $scope.popupopen('generalpopup', popupdata, $scope);
                $scope.loading = false;
            }

        }
        $scope.selectAll = true;
        $scope.isSelectAll = function () {
            $scope.selectedOrderIds = [];
            if ($scope.selectAll) {
                angular.forEach($scope.cancelfeedsuborderdetails, function (order) {
                    if ((order.status == 'Delivered' || order.status == 'Refunded') && order.feedbackCanBeProvided) {
                        order.selected = true;
                        $scope.selectedOrderIds.push(order.suborder_id);
                    }
                });
            } else {
                angular.forEach($scope.cancelfeedsuborderdetails, function (order) {
                    order.selected = false;
                });
                $scope.selectedOrderIds = [];
            }
            //console.log($scope.selectedOrderIds);
        }
        $scope.isChecked = function (checkboxVal, selectedOrderId) {
            if (!$scope.selectAll && checkboxVal) {
                $scope.selectedOrderIds.push(selectedOrderId);
                //console.log()
            } else if ($scope.selectAll && !checkboxVal) {
                $scope.selectAll = false;
                var ind = $scope.selectedOrderIds.indexOf(selectedOrderId);
                if (ind != -1) {
                    $scope.selectedOrderIds.splice(ind, 1);
                }
            } else if (checkboxVal) {
                $scope.selectedOrderIds.push(selectedOrderId);
            } else if (!checkboxVal) {
                var ind = $scope.selectedOrderIds.indexOf(selectedOrderId);
                if (ind != -1) {
                    $scope.selectedOrderIds.splice(ind, 1);
                }
            }
            //console.log($scope.selectedOrderIds);
        }
        $scope.rating1 = 1;
        //$scope.rating2=2;
        this.isReadonly = true;
        //console.log($scope.feebackvalue)

    }
])

app.controller("adminscreencntrl", ['$scope', '$state', '$location', 'authenticationSvc',
    function ($scope, $state, $location, authenticationSvc) {

        //console.log("adminscreencntrl called")
        $scope.setnavshow(false);
        //$scope.highlightActiveTab = 'admin.viewcancelrequest';
        $scope.resourceTabClick(false);

        $scope.resourceTabClick = function (value) {
            $scope.showResourceButton = value;
        }

        $scope.setHighlightActiveTab = function (name) {
            $scope.highlightActiveTab = name;

        }

        if ($location.url().split("/")[1] === 'login') {
            //console.log("here  "+$location.url().split("/")[2])
            $scope.setHighlightActiveTab('admin.viewcancelrequest');
        } else
            $scope.resourceTabClick(true)
        //console.log("here  "+$location.url().split("/")[1]+'.'+$location.url().split("/")[2])
        $scope.setHighlightActiveTab($location.url().split("/")[1] + '.' + $location.url().split("/")[2]);

        $scope.redirectTo = function (name) {
            //alert(" do u wanna raise ticket");
            $state.go(name);
            $scope.highlightActiveTab = name;
            //console.log($scope.highlightActiveTab)

        }


        $scope.logout = function () {
            authenticationSvc.logout()
            $state.go("login");
        }
    }])


app.controller("adminviewcancelrequestcntrl", ['$scope', '$filter', '$timeout', '$q', 'magento_ConstantApi', 'authenticationSvc',
    'OSTicket_ConstantApi', 'fetchdatabase', 'Leykart_DatabaseConstant', 'extractOrdernoSrv', 'userInfosvc', 'mergeOrder_Ticket', 'errorcodesrv', 'adminOrderCan_TicketAssignSrv',
    function ($scope, $filter, $timeout, $q, magento_ConstantApi, authenticationSvc,
            OSTicket_ConstantApi, fetchdatabase, Leykart_DatabaseConstant, extractOrdernoSrv, userInfosvc, mergeOrder_Ticket, errorcodesrv, adminOrderCan_TicketAssignSrv) {
        $scope.setnavshow(false);
        $scope.helpTopicFun();
        $scope.internalError = false
        //$scope.setHighlightActiveTab('admin.viewcancelrequest');
        //$scope.loading = true
        // start of date
        var arrayForTrackingVerifiedOrder = []
        var dateAsData = {"from_date": '', "to_date": ''}
        var dateforOsticket = {"from_date": '', "to_date": ''}
        $scope.date = function (fromdate, todate) {
            $scope.loading = true
            dateAsData.from_date = fromdate.getDate() + '.' + (fromdate.getMonth() + 1) + '.' + fromdate.getFullYear();
            dateAsData.to_date = (todate.getDate()) + '.' + (todate.getMonth() + 1) + '.' + todate.getFullYear();

            dateforOsticket.from_date = fromdate.getFullYear() + '-' + (fromdate.getMonth() + 1) + '-' + (fromdate.getDate()) + ' ' + '00:00:00'
            dateforOsticket.to_date = todate.getFullYear() + '-' + (todate.getMonth() + 1) + '-' + (todate.getDate()) + ' ' + '23:59:59'

            $scope.getcancelrequest()

            //$scope.getcancelrequest()
            //$scope.ticketdetail()
        }
        // end  of date



        // start of to get list of cancel initiate order 
        $scope.selecttype = 'CANINI'
        $scope.getcancelrequest = function () {
            reasonForCancellation();
            $scope.loading = true
            var deferred = $q.defer();
            //console.log("called  " + $scope.selecttype)
            var dataobj = {"status": $scope.selecttype, "from_date": dateAsData.from_date, "to_date": dateAsData.to_date}
            var path = 'getcancelrequesturlpath';
            authenticationSvc.login('POST', magento_ConstantApi.Apiendpoint, path, dataobj)
                    .then(function (response) {
                        //console.log(response.data)
                        if (response.data[0] == null || response.data[0].length == 0) {
                            $scope.admincancelrequestdata = []
                            $scope.adminorderDetailsCopy = []
                            var popupdata = "There Is No  Orders To Display For The Given Date Range"
                            $scope.popupopen('generalpopup', popupdata, $scope)
                            $scope.loading = false
                        } else {
                            $scope.admincancelrequestdata = response.data[0]
                            $scope.loading = false
                            $scope.adminorderDetailsCopy = response.data[0]
                        }
                        // $scope.admincancelrequestdata = response.data[0]
                        // $scope.loading = false
                        // var orderDetails = response.data[0]
                        //console.log(orderDetails)
                        $scope.ticketdetail().then(function () {
                            mergeOrder_Ticket.merge($scope)
                        })

                    },
                            function (response) {
                                $scope.loading = false
                                console.log(response)
                                console.log("Error response received  while getting  order details for admin view cancellation")
                                var msg = errorcodesrv.checkcode(response.status)
                                if (msg !== "")
                                    var popupdata = msg
                                else
                                    var popupdata = "Error Response Received  While Getting Order Details For Admin View Cancellation From Server"
                                $scope.popupopen('generalpopup', popupdata, $scope)
                                //return deferred.reject(false);
                            })
        }
        // end of  to get list of cancel initiate order 


        // start of to get Reason for cancellation 
        function reasonForCancellation() {
            //console.log("called reasonForCancellation")
            //var path = magento_ConstantApi.getcancelreasonurlpath;
            //authenticationSvc.login('GET',magento_ConstantApi.Apiendpoint,path,null,magento_ConstantApi.Headers)
            var data = {
                user_role: $scope.getUserRole()
            }
            var path = 'getcancelreasonurlpath';
            authenticationSvc.login('POST', magento_ConstantApi.Apiendpoint, path, data)
                    .then(function (response) {
                        //console.log( response.data[0])
                        if (response.data[0] == null || response.data[0] == "") {
                            var msg = errorcodesrv.checkcode(response.status)
                            if (msg !== "")
                                var popupdata = msg
                            else
                                var popupdata = "Didnt Receive Any Detail From Server"
                            $scope.popupopen('generalpopup', popupdata, $scope)
                            $scope.loading = false
                        } else {
                            $scope.reasonForCancel = response.data[0].reasons;
                            $scope.reasonForCancel.push({'reason_code': "", 'reason_description': "Select"})
                            $scope.selectedReason = $scope.reasonForCancel[$scope.reasonForCancel.length - 1]
                            $scope.loading = false
                        }
                        //$scope.reasonForCancel = response.data[0].reasons;
                        //console.log($scope.reasonForCancel)
                        // for (var i=0;typeof(orderdetails[i]) === 'object';i++)
                        // suborder.push(orderdetails[i])
                        // $scope.suborders = suborder;
                    },
                            function (response) {
                                console.log("Error response received  while getting Reason for cancellation ")
                                console.log(response)
                                var msg = errorcodesrv.checkcode(response.status)
                                if (msg !== "")
                                    var popupdata = msg
                                else
                                    var popupdata = "Error Response Received  While Getting Reason For Cancellation From Server"
                                $scope.popupopen('generalpopup', popupdata, $scope)
                                $scope.loading = false

                            })
        }
        // end of to get Reason for cancellation

        // fetching ticket details from os ticket
        $scope.ticketdetail = function (name, ticketno, orderno) {
            var deferred = $q.defer();
            // $scope.helpTopicFun().then(function(value){
            // 	if(value){

            //console.log(name)
            //$scope.loading = true
            //var path = OSTicket_ConstantApi.viewticketurlpath ; 
            //console.log(dateforOsticket)
            var data = {
                "luser": userInfosvc.returnUserInfo()[0].username,
                "lpasswd": userInfosvc.returnUserInfo()[0].pass,
                //"helptopic":"27",
                "helptopic": $scope.helpTopicId,
                "ticket_number": "",
                "status": "",
                //"staff_id": "",
                "staff_id": userInfosvc.returnUserInfo()[0].staff_id,
                "from_date": dateforOsticket.from_date,
                "to_date": dateforOsticket.to_date
            }
            var path = Leykart_DatabaseConstant.osticketurl;
            //authenticationSvc.login('POST',OSTicket_ConstantApi.Apiendpoint, path, data, OSTicket_ConstantApi.Header)
            fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, path, 'viewticket', data)
                    .then(function (response) {
                        //console.log(response.data)
                        $scope.ticketWithOrderno = extractOrdernoSrv.extractorderno(response.data)
                        //console.log($scope.ticketWithOrderno)
                        deferred.resolve(true);


                    }, function (response) {
                        console.log("Error response received  while getting ticket details from os ticket for admin view cancellation reuest ")
                        console.log(response)
                        //$scope.loading = false
                        deferred.reject(false);
                    })
            return deferred.promise;
            //}
            // else
            // 	console.log("Error in getting helptopic")
            // })
        } //end of  fetching ticket details from os ticket



        // Start of  adding or removing the verified order from the screen
        var arrayForTrackingVerifiedOrder = [];
        var removeitemindex = -1
        // for toggling and storing orders
        $scope.toggle = function (requestFrom, data, value, cancel_reason) {
            //console.log($scope.admincancelrequestdata)
            if (requestFrom === 'approve' && value == true) {
                data.reject = false
                data.approve = true
                data.cstatus = 'CANAPP'
            }
            if (requestFrom === 'approve' && value == false) {
                data.approve = false
            }
            if (requestFrom === 'reject' && value == true) {
                data.approve = false
                data.reject = true
                data.cstatus = 'CANREJ'
            }
            if (requestFrom === 'reject' && value == false) {
                data.reject = false
            }

            $scope.addToApproveRejectOrderList(data, 'togglefunction', cancel_reason)

        }

        $scope.addToApproveRejectOrderList = function (data, callfrom, cancel_reason) {
            //var  original_reason_code = getReasonCode(cancel_reason)
            var indextoberemoved = -1
            if (arrayForTrackingVerifiedOrder.length == 0 && callfrom === 'togglefunction') {
                //console.log(data)
                if (cancel_reason != "") {
                    var change_can_reason = cancel_reason
                }
                arrayForTrackingVerifiedOrder.push({"order": [{"orderid": data.suborder_id, "cancelreason": change_can_reason ? change_can_reason : getReasonCode(data.cancellation_reason), "cstatus": data.cstatus, "comment": data.comment, 'tkt_detail': data.tckt_detail}]})
            } else {
                if (checkOrderAlreadyAdded(data)) {
                    //console.log(data.cstatus)
                    for (var i = 0; i < arrayForTrackingVerifiedOrder[0].order.length; i++) {
                        // console.log(arrayForTrackingVerifiedOrder[i].index)
                        if (arrayForTrackingVerifiedOrder[0].order[i].orderid == data.suborder_id) {
                            // To remove order 
                            if (data.cstatus == "") {
                                indextoberemoved = i
                                //console.log(indextoberemoved)
                            } else
                                arrayForTrackingVerifiedOrder[0].order[i].cstatus = data.cstatus
                            //arrayForTrackingVerifiedOrder[0].order[i].comment = data.comment
                        }
                    }

                }

                if (!checkOrderAlreadyAdded(data) && callfrom === 'togglefunction') {
                    //console.log(data)
                    if (cancel_reason != "") {
                        var change_can_reason = cancel_reason
                    }
                    arrayForTrackingVerifiedOrder[0].order.push({"orderid": data.suborder_id, "cancelreason": change_can_reason ? change_can_reason : getReasonCode(data.cancellation_reason), "cstatus": data.cstatus, "comment": data.comment, 'tkt_detail': data.tckt_detail})
                }
            }
            if (indextoberemoved !== -1) {
                var newarray = []
                newarray[0] = {}
                newarray[0].order = []
                for (var i = 0; i < arrayForTrackingVerifiedOrder[0].order.length; i++) {
                    if (indextoberemoved !== i) {
                        newarray[0].order.push(arrayForTrackingVerifiedOrder[0].order[i])
                    }
                }
                arrayForTrackingVerifiedOrder = newarray
            }
            //console.log(arrayForTrackingVerifiedOrder)
        }

        // start of change cancel reason
        $scope.changecancelreason = function (orderid, changedreason, originalreason) {
            //console.log(checkboxselected +"  "+ reasonid)
            //var original_reason_code = $scope.reasonForCancel.filter(function(reason){ if(reason.reason_description == originalreason) return reason.reason_code})
            //console.log(original_reason_code)
            var original_reason_code = getReasonCode(originalreason)
            if (arrayForTrackingVerifiedOrder.length > 0) {
                var ordersarray = arrayForTrackingVerifiedOrder[0].order
                var indexOfobj = ordersarray.findIndex(function (obj) {
                    return obj.orderid == orderid
                });

                if (changedreason == "" || !changedreason) {
                    if (indexOfobj != -1) {
                        arrayForTrackingVerifiedOrder[0].order[indexOfobj].cancelreason = original_reason_code
                    }
                } else {

                    if (indexOfobj != -1) {
                        arrayForTrackingVerifiedOrder[0].order[indexOfobj].cancelreason = changedreason
                    }
                }
            }
            //console.log(checkboxselected +"  "+ reasonid)
            //console.log(arrayForTrackingVerifiedOrder)
        }

        function getReasonCode(originalreason) {
            for (reason  of $scope.reasonForCancel) {
                if (reason.reason_description == originalreason)
                    return reason.reason_code
            }
        }

        $scope.changeComments = function (data) {
            if (checkOrderAlreadyAdded(data)) {
                for (var i = 0; i < arrayForTrackingVerifiedOrder[0].order.length; i++) {
                    // console.log(arrayForTrackingVerifiedOrder[i].index)
                    if (arrayForTrackingVerifiedOrder[0].order[i].orderid == data.suborder_id) {
                        //arrayForTrackingVerifiedOrder[0].order[i].cstatus = data.cstatus
                        arrayForTrackingVerifiedOrder[0].order[i].comment = data.comment
                    }
                }
            }
            //console.log(data)
            //console.log(arrayForTrackingVerifiedOrder)
        }


        $scope.resetArrayVerified = function () {
            //console.log("called")
            arrayForTrackingVerifiedOrder = []
            //console.log(arrayForTrackingVerifiedOrder)
        }

        function checkOrderAlreadyAdded(obj) {
            //console.log("hi  "+obj.cstatus)
            if (arrayForTrackingVerifiedOrder.length > 0) {
                for (var i = 0; i < arrayForTrackingVerifiedOrder[0].order.length; i++) {
                    // console.log(arrayForTrackingVerifiedOrder[i].index)
                    if (arrayForTrackingVerifiedOrder[0].order[i].orderid == obj.suborder_id) {
                        // if(arrayForTrackingVerifiedOrder[0].order[i].cstatus == ""){
                        // removeitemindex = i
                        // console.log(removeitemindex)
                        // }
                        return true
                    }
                }
            }

            return false
        }
        // end of removing the verified Items from the screen






        // start of saving approved or reject order 
        $scope.saveOrders = function () {

            $scope.loading = true


            adminOrderCan_TicketAssignSrv.calledfromCntrlfunc(arrayForTrackingVerifiedOrder, $scope)
                    .then(function (response) {
                        $scope.loading = false
                        var popupdata = 'Orders Successfully Approved Or Rejected'
                        $scope.popupopen('generalpopup', popupdata, $scope)
                        arrayForTrackingVerifiedOrder = []
                        $scope.getcancelrequest()
                    }, function (response) {
                        $scope.loading = false
                        //console.log("Error Occured")
                        // var msg = errorcodesrv.checkcode(response.status)
                        // if (msg !== "")
                        // var popupdata = msg
                        // else
                        arrayForTrackingVerifiedOrder = []

                        //console.log($scope.admincancelerrormsg);
                        if ($scope.admincancelerrormsg)
                            var popupdata = $scope.admincancelerrormsg
                        else
                            var popupdata = 'Error Response Received  While Approving Or Rejecting order'
                        $scope.popupopen('generalpopup', popupdata, $scope)
                        $scope.getcancelrequest()
                    })

        }
        // end of saving appored or reject order 

        //start of to disable cancel button
        $scope.checkarraylength = function () {
            if (arrayForTrackingVerifiedOrder.length <= 0 || arrayForTrackingVerifiedOrder[0].order.length <= 0)
                return true
            else
                return false
        }
        //end of to disable cancel button

        // start of  Sub order details of input order id
        $scope.orderOrsuborderpopupopen = function (popuptype, orderOrsuborderid) {
            if (orderOrsuborderid == "" || orderOrsuborderid == "NA" || orderOrsuborderid == undefined || orderOrsuborderid == null)
                return
            $scope.loading = true
            //console.log("called   "+orderOrsuborderid)
            //var path = magento_ConstantApi.orderdetailurlpath+orderOrsuborderid;
            //authenticationSvc.login('GET',magento_ConstantApi.Apiendpoint,path,null,magento_ConstantApi.Headers)
            var data = {"orderid": orderOrsuborderid}
            var path = 'orderdetailurlpath';
            authenticationSvc.login('POST', magento_ConstantApi.Apiendpoint, path, data)
                    .then(function (response) {
                        //console.log(response.data)
                        if (popuptype === "Suborderpopup") {
                            $scope.popupopen(popuptype, response.data[0][0], $scope)
                            $scope.loading = false
                        }

                    },
                            function (response) {
                                console.log("Error response received  while getting sub order details ")
                                console.log(response)
                                var msg = errorcodesrv.checkcode(response.status)
                                if (msg !== "")
                                    var popupdata = msg
                                else
                                    var popupdata = 'Error Response Received  While Getting Ticket Details From Server'
                                $scope.popupopen('generalpopup', popupdata, $scope)
                                $scope.loading = false

                            })
        }
        // end of order pop up

        // created by
        // $scope.getcreatorindex =function(ticket){
        // 	var min=parseInt(ticket.event_info[0].id)+1
        // 	for(var i=0; i<ticket.event_info.length;i++){

        // 		if(ticket.event_info[i].id == min)
        // 			return i
        // 		//console.log(ticket.event_info)
        // 		//console.log("hello2  " +i)
        // 	}
        // }

        // fetching ticket details from os ticket for ticket popup
        $scope.ticketpopup = function (name, ticketno, orderno) {
            //console.log(ticketno)
            if (ticketno) {
                $scope.loading = true
                //var path = OSTicket_ConstantApi.viewticketurlpath ; 
                var data = {
                    "luser": userInfosvc.returnUserInfo()[0].username,
                    "lpasswd": userInfosvc.returnUserInfo()[0].pass,
                    //"helptopic":"27",
                    "helptopic": $scope.helpTopicId,
                    "ticket_number": ticketno,
                    "status": "",
                    "staff_id": "",
                    "from_date": "",
                    "to_date": ""
                }
                var path = Leykart_DatabaseConstant.osticketurl;
                //authenticationSvc.login('POST',OSTicket_ConstantApi.Apiendpoint, path, data, OSTicket_ConstantApi.Header)
                fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, path, 'viewticket', data)
                        .then(function (response) {
                            //console.log(response.data[0])
                            $scope.ticketinfo = response.data[0]
                            $scope.popupopen('ticketdetails', orderno, $scope)
                            $scope.loading = false
                        }, function (response) {
                            console.log("Error response received  while getting ticket details from os ticket ")
                            console.log(response)
                            var msg = errorcodesrv.checkcode(response.status)
                            if (msg !== "")
                                var popupdata = msg
                            else
                                var popupdata = "Error Response Received  While Getting Ticket Details From Os Ticket"
                            $scope.popupopen('generalpopup', popupdata, $scope)
                            $scope.loading = false
                        })
            } else
                return

        } //end of  fetching ticket details from os ticket

    }]);

app.controller("adminviewticketcntrl", ['$scope', 'fetchdatabase', 'authenticationSvc', 'OSTicket_ConstantApi', 'extractOrdernoSrv', 'magento_ConstantApi', 'userInfosvc', 'errorcodesrv', 'Leykart_DatabaseConstant',
    function ($scope, fetchdatabase, authenticationSvc, OSTicket_ConstantApi, extractOrdernoSrv, magento_ConstantApi, userInfosvc, errorcodesrv, Leykart_DatabaseConstant) {
        $scope.search = {"searchText": ''};
        $scope.setnavshow(false);
        //$scope.helpTopicFun();
        //$scope.highlightActiveTab = 'admin.viewtickets';
        //$scope.resourceTabClick(false);
        // fetchdatabase.ApiData('abc',3).then(function(response){
        // $scope.adminopenticketdata = response;
        // },function(response){
        // //console.log(response)
        // })
        // start of date
        var dateAsData = {"from_date": '', "to_date": ''}
        var dateforOsticket = {"from_date": '', "to_date": ''}
        $scope.date = function (fromdate, todate) {
            if ($scope.tickettype == 'Open') {
                dateAsData.from_date = '';
                dateAsData.to_date = '';

                dateforOsticket.from_date = '';
                dateforOsticket.to_date = '';
            } else {
                dateAsData.from_date = fromdate.getDate() + '.' + (fromdate.getMonth() + 1) + '.' + fromdate.getFullYear();
                dateAsData.to_date = todate.getDate() + '.' + (todate.getMonth() + 1) + '.' + todate.getFullYear();

                dateforOsticket.from_date = fromdate.getFullYear() + '-' + (fromdate.getMonth() + 1) + '-' + fromdate.getDate() + ' ' + '00:00:00';
                dateforOsticket.to_date = todate.getFullYear() + '-' + (todate.getMonth() + 1) + '-' + (todate.getDate()) + ' ' + '23:59:59';
            }

            /*dateforOsticket.from_date = fromdate.getFullYear()+'-'+(fromdate.getMonth()+1)+'-'+fromdate.getDate()+' '+'00:00:00';
             dateforOsticket.to_date = todate.getFullYear()+'-'+(todate.getMonth()+1)+'-'+(todate.getDate())+' '+'23:59:59';*/
            //console.log(fromdate.getDate()+'.'+fromdate.getMonth()+'.'+fromdate.getFullYear())
            //console.log(todate.getDate()+'.'+todate.getMonth()+'.'+todate.getFullYear())
            //console.log(dateforOsticket.from_date)
            //console.log(dateforOsticket.to_date)
            $scope.ticketdetail()
        }

        $scope.filterTicketType = function () {
            $scope.dateGo();

        }
        // end  of date

        // ticket creator
        // $scope.getcreatorindex =function(ticket){
        // 	var min=parseInt(ticket.event_info[0].id)+1
        // 	for(var i=0; i<ticket.event_info.length;i++){

        // 		if(ticket.event_info[i].id == min)
        // 			return i
        // 		//console.log(ticket.event_info)
        // 		//console.log("hello  " +i)
        // 	}
        // }

        // fetching ticket details from os ticket
        $scope.ticketdetail = function (name, ticketno, orderno) {
            $scope.helpTopicFun().then(function (value) {
                if (value) {


                    //console.log(name)
                    $scope.loading = true
                    //var path = OSTicket_ConstantApi.viewticketurlpath ; 
                    var data = {
                        "luser": userInfosvc.returnUserInfo()[0].username,
                        "lpasswd": userInfosvc.returnUserInfo()[0].pass,
                        //"helptopic":"27",
                        "helptopic": $scope.helpTopicId,
                        "ticket_number": "",
                        "status": "",
                        "staff_id": "",
                        "from_date": dateforOsticket.from_date,
                        "to_date": dateforOsticket.to_date
                    }
                    var path = Leykart_DatabaseConstant.osticketurl;
                    //authenticationSvc.login('POST',OSTicket_ConstantApi.Apiendpoint, path, data, OSTicket_ConstantApi.Header)
                    fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, path, 'viewticket', data)
                            .then(function (response) {
                                //console.log(response.data)

                                if (response.data == 'null' || response.data.length == 0) {
                                    var popupdata = "There Is No  Tickets To Display For The Given Date Range"
                                    $scope.popupopen('generalpopup', popupdata, $scope)
                                    $scope.loading = false
                                } else {
                                    $scope.listoftickets = response.data
                                    $scope.listoftickets = extractOrdernoSrv.extractorderno($scope.listoftickets)
                                    $scope.loading = false
                                }
                            }, function (response) {
                                console.log("Error response received  while getting ticket details from os ticket ")
                                console.log(response)
                                var msg = errorcodesrv.checkcode(response.status)
                                if (msg !== "")
                                    var popupdata = msg
                                else
                                    var popupdata = 'Error Response Received  While Getting Ticket Details From Server'
                                $scope.popupopen('generalpopup', popupdata, $scope)
                                $scope.loading = false
                            })
                } else
                    console.log("error in getting help topic")
            });
        } //end of  fetching ticket details from os ticket
        //$scope.ticketdetail();

        // fetching ticket details from os ticket for ticket popup
        $scope.ticketpopup = function (name, ticketno, orderno) {
            $scope.loading = true
            //var path = OSTicket_ConstantApi.viewticketurlpath ; 
            var data = {
                "luser": userInfosvc.returnUserInfo()[0].username,
                "lpasswd": userInfosvc.returnUserInfo()[0].pass,
                //"helptopic":"27",
                "helptopic": $scope.helpTopicId,
                "ticket_number": ticketno,
                "status": "",
                "staff_id": "",
                "from_date": "",
                "to_date": ""
            }
            var path = Leykart_DatabaseConstant.osticketurl;
            //authenticationSvc.login('POST',OSTicket_ConstantApi.Apiendpoint, path, data, OSTicket_ConstantApi.Header)
            fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, path, 'viewticket', data)
                    .then(function (response) {
                        //console.log(response.data[0])
                        $scope.ticketinfo = response.data[0]
                        $scope.popupopen('ticketdetails_viewticket', orderno, $scope)
                        $scope.loading = false
                    }, function (response) {
                        console.log("Error response received  while getting ticket details from os ticket ")
                        console.log(response)
                        var msg = errorcodesrv.checkcode(response.status)
                        if (msg !== "")
                            var popupdata = msg
                        else
                            var popupdata = 'Error Response Received  While Getting Ticket Details From Server'
                        $scope.popupopen('generalpopup', popupdata, $scope)
                        $scope.loading = false
                    })
        } //end of  fetching ticket details from os ticket

        //calculate age of the ticket
        $scope.calcualateAge = function (status, created, closed) {
            var created1 = new Date(created);
            var created2 = created1.getFullYear() + "-" + (created1.getMonth() + 1) + "-" + created1.getDate();
            var finalCreatedDate = new Date(created2);

            var closed1 = new Date(closed);
            var closed2 = closed1.getFullYear() + "-" + (closed1.getMonth() + 1) + "-" + closed1.getDate();
            var finalClosedDate = new Date(closed2);

            if (status == 'Open' || status == 'In-progress') {
                var endingDate = new Date();
                //var startingDate = new Date(created);   
                var timeDiff = Math.abs(finalCreatedDate.getTime() - endingDate.getTime());
                return(Math.ceil(timeDiff / (1000 * 3600 * 24)) - 1);
            } else if (status == 'Closed' || status == 'Resolved') {
                //var endingDate = new Date(closed);
                //var startingDate = new Date(created);
                var timeDiff = Math.abs(finalCreatedDate.getTime() - finalClosedDate.getTime());
                return(Math.ceil(timeDiff / (1000 * 3600 * 24)));
            } else {
                return '-';
            }

        } //end - calculate age of the ticket

        //sending sms to customer while closing the order
        $scope.sendSmsCallCenter = function (mobileNumber, ticketNumber, modf) {
            if (modf == 1) {
                var today_date = new Date();
                var today = ((today_date.getDate() < 10) ? "0" : "") + today_date.getDate()
                        + "/" + (((today_date.getMonth() + 1) < 10) ? "0" : "")
                        + (today_date.getMonth() + 1) + "/" + today_date.getFullYear() + ", "
                        + ((today_date.getHours() < 10) ? "0" : "") + today_date.getHours()
                        + ":" + ((today_date.getMinutes() < 10) ? "0" : "") + today_date.getMinutes();
                var textmessage = "Thank you for contacting us. The reference no. for your Leykart query is (" + ticketNumber + "), registered on " + today + "."
                //"Dear <User>, request " + ticketNumber +" Created successfully. Thank you";
            }
            if (modf == 2) {
                //var textmessage = "Dear <User>, request " + ticketNumber +" Closed successfully. Thank you";
                var textmessage = "Dear <User>, Your Leykart query with reference no. (" + ticketNumber + ") has been resolved and closed successfully. Thank you";
            }

            var data = {"mobileNo": mobileNumber, "message": textmessage};

            /*fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, Leykart_DatabaseConstant.urlpath, 'sendSmsCallCenter',data)
             .then(function(response) {
             $scope.popupopen('generalpopup',JSON.stringify(response),$scope);
             }, function(response) {
             $scope.popupopen('generalpopup', JSON.stringify(response), $scope);
             }
             );*/
            var path = 'sendsmsforticket';
            authenticationSvc.login('POST', magento_ConstantApi.Apiendpoint, path, data)
                    .then(function (response) {
                        console.log(response);
                        //$scope.popupopen('generalpopup',JSON.stringify(response),$scope);
                    }, function (response) {
                        console.log(response);
                        //$scope.popupopen('generalpopup','test',$scope);
                    });
        }
        $scope.sendSMSforClosingTicket = function (ticketnumber) {
            var getTicketdata = {
                "luser": userInfosvc.returnUserInfo()[0].username,
                "lpasswd": userInfosvc.returnUserInfo()[0].pass,
                //"helptopic":"27",
                "helptopic": $scope.helpTopicId,
                "ticket_number": ticketnumber,
                "status": "",
                "staff_id": "",
                "from_date": "",
                "to_date": ""
            }
            var path = Leykart_DatabaseConstant.osticketurl;
            fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, path, 'viewticket', getTicketdata)
                    .then(function (response) {
                        var customer_mobile_number = response.data[0].phone;
                        $scope.sendSmsCallCenter(customer_mobile_number, ticketnumber, 2);

                    }, function (response) {
                        console.log("Error response received  while getting ticket details from os ticket ")
                        console.log(response)

                    })
        }
        // end - sending sms to customer while closing the order

        // start of  Sub order details of input order id
        $scope.orderOrsuborderpopupopen = function (popuptype, orderOrsuborderid) {
            if (orderOrsuborderid == "" || orderOrsuborderid == "NA" || orderOrsuborderid == undefined || orderOrsuborderid == null)
                return
            $scope.loading = true
            //console.log("called   "+orderOrsuborderid)
            //var path = magento_ConstantApi.orderdetailurlpath+orderOrsuborderid;
            //authenticationSvc.login('GET',magento_ConstantApi.Apiendpoint,path,null,magento_ConstantApi.Headers)
            var data = {"orderid": orderOrsuborderid}
            var path = 'orderdetailurlpath';
            authenticationSvc.login('POST', magento_ConstantApi.Apiendpoint, path, data)
                    .then(function (response) {
                        //console.log(response.data)
                        if (popuptype === "Suborderpopup") {
                            $scope.popupopen(popuptype, response.data[0][0], $scope)
                            $scope.loading = false
                        }
                        if (popuptype === "orderpopup") {
                            var suborder = []
                            $scope.orderdetails = response.data[0];
                            //console.log(response.data[0])
                            for (var i = 0; typeof (response.data[0][i]) === 'object'; i++)
                                suborder.push(response.data[0][i])
                            $scope.suborders = suborder;
                            $scope.showsearchbar = false;
                            $scope.popupopen(popuptype, response.data[0][0], $scope)
                            $scope.loading = false
                        }

                    },
                            function (response) {
                                console.log("Error response received  while getting sub order details ")
                                console.log(response)
                                var msg = errorcodesrv.checkcode(response.status)
                                if (msg !== "")
                                    var popupdata = msg
                                else
                                    var popupdata = 'Error Response Received  While Getting Order Details From Server'
                                $scope.popupopen('generalpopup', popupdata, $scope)
                                $scope.loading = false

                            })
        }
        // end of order pop up

        // Start   this function is called when submit button of ticket popup is clicked  
        $scope.ticketSubmit = function (ticketid, posttype, updatetype, message, ticketnumber = null) {
            var data = {}
            var typeofupdate = ""
            $scope.loading = true
            //console.log("ticketSubmit")
            //console.log(posttype)
            //console.log(updatetype)
            if (posttype != 'Select') {
                if (posttype === 'Reply') {
                    typeofupdate = "updateticketReply"
                    data = {
                        "luser": userInfosvc.returnUserInfo()[0].username,
                        "lpasswd": userInfosvc.returnUserInfo()[0].pass,
                        "ticket_id": ticketid,
                        "update_type": "Reply",
                        "message": message,
                        "status": "open"
                    }
                } else if (posttype === 'Note') {
                    typeofupdate = "updateticketNote"
                    data = {
                        "luser": userInfosvc.returnUserInfo()[0].username,
                        "lpasswd": userInfosvc.returnUserInfo()[0].pass,
                        "ticket_id": ticketid,
                        "update_type": "Note",
                        "title": "Title-2",
                        "message": message
                    }
                }
            } else if (updatetype != 'Select') {
                if (updatetype === 'Open') {
                    typeofupdate = "updateticketReply"
                    data = {
                        "luser": userInfosvc.returnUserInfo()[0].username,
                        "lpasswd": userInfosvc.returnUserInfo()[0].pass,
                        "ticket_id": ticketid,
                        "update_type": "Reply",
                        "message": message,
                        "status": "open"
                    }
                } else if (updatetype === 'Close') {
                    typeofupdate = "updateticketReply"
                    data = {
                        "luser": userInfosvc.returnUserInfo()[0].username,
                        "lpasswd": userInfosvc.returnUserInfo()[0].pass,
                        "ticket_id": ticketid,
                        "update_type": "Reply",
                        "message": message,
                        "status": "closed"
                    }
                } else if (updatetype === 'Resolve') {
                    typeofupdate = "updateticketReply"
                    data = {
                        "luser": userInfosvc.returnUserInfo()[0].username,
                        "lpasswd": userInfosvc.returnUserInfo()[0].pass,
                        "ticket_id": ticketid,
                        "update_type": "Reply",
                        "message": message,
                        "status": "resolved"
                    }
                }
            }
            //var path = OSTicket_ConstantApi.updateticketurlpath ;
            $scope.$broadcast('ticketsubmitEvent', {obj: 'please close the popup event!'}) // send whatever you want
            //$scope.popupclose()
            //$scope.popupclose()
            var path = Leykart_DatabaseConstant.osticketurl;
            //authenticationSvc.login('POST',OSTicket_ConstantApi.Apiendpoint, path, data, OSTicket_ConstantApi.Header)
            fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, path, typeofupdate, data)
                    .then(function (response) {
                        //console.log(response)
                        if (response.status == 201)
                            //console.log("succesfully replied or noted for the ticket")
                            $scope.loading = false
                        $scope.ticketdetail();
                        var popupdata = "Ticket Updated Successfully";

                        //sending sms to customer while closing the ticket
                        if (updatetype === 'Close') {
                            $scope.sendSMSforClosingTicket(ticketnumber);
                        }

                        $scope.popupopen('generalpopup', popupdata, $scope)
                    }, function (response) {
                        console.log("Error response received  from os ticket while updating ticket  ")
                        console.log(response)
                        var msg = errorcodesrv.checkcode(response.status)
                        if (msg !== "")
                            var popupdata = msg
                        else
                            var popupdata = "Error response received  from os ticket while updating ticket "
                        $scope.popupopen('generalpopup', popupdata, $scope)
                        // firing an event downwards ie to close model by calling popupcntrl  watch function
                        //$scope.$broadcast('ticketsubmitEvent', {obj: 'please close the popup event!'})   // send whatever you want
                        $scope.loading = false
                    })



        } // end of ticketSubmit for popup ticket	

    }])

app.controller("adminuploadmanualcntrl", ['$scope', '$http', 'Leykart_DatabaseConstant', 'fetchdatabase', '$q', 'UploadFileService',
    function ($scope, $http, Leykart_DatabaseConstant, fetchdatabase, $q, UploadFileService) {

        $scope.setnavshow(false);
        $scope.highlightActiveTab = 'admin.uploadmanual';
        $scope.uploadSuccess = []
        $scope.index = []
        // GET THE FILE INFORMATION.

        // $scope.getFileDetails = function (e) {

        // $scope.files = [];
        // $scope.$apply(function () {

        // // STORE THE FILE OBJECT IN AN ARRAY.
        // for (var i = 0; i < e.files.length; i++) {
        // $scope.files.push(e.files[i])
        // }

        // });
        // console.log($scope.files)
        // };
        // 'http://localhost:8083/LeyWhite_v3/data',
        // $scope.uploadFile = function(){
        // var fd = new FormData();
        // angular.forEach($scope.files,function(file){
        // fd.append("file", file);
        // })
        // $http.post('uploadFile.php',fd,{
        // withCredentials : false,
        // headers : {
        // 'Content-Type' : undefined
        // },
        // transformRequest : angular.identity
        // })
        // .then(function(data,header,config){
        // console.log(data);
        // }
        // ,function(data){console.log(data);}
        // );
        // }

        function checkfileformat(e) {
            var deferred = $q.defer();
            //var ext='';
            //console.log(e.files[0].name)
            if (e.files.length == 0) {
                $scope.pocUpload = true;
                deferred.resolve(false);
                return deferred.promise;
            } else {
                var ext = e.files[0].name.match(/\.([^\.]+)$/)[1].toLowerCase();
                switch (ext)
                {
                    case 'doc':
                    case 'docx':
                    case 'txt':
                    case 'xls':
                    case 'xlsx':
                    case 'pdf':
                    case 'jpg':
                    case 'bmp':
                    case 'png':
                    case 'tif':
                        //alert('allowed');
                        deferred.resolve(true);
                        break;
                    default:
                        //alert('not allowed');
                        deferred.resolve(false);
                }
                return deferred.promise;
            }
        }
        ;

        $scope.files = [];
        $scope.uploadedFile = function (element, indexInArray) {
            //console.log("he")
            checkfileformat(element)
                    .then(function (resp) {
                        if (resp == true) {
                            $scope.index[indexInArray] = indexInArray
                            //console.log("called")
                            //console.log(element)
                            //$scope.$digest(function($scope) {
                            UploadFileService.addfileinFilesArray($scope, element.files[0], indexInArray)
                            //$scope.files = element.files;         
                            //});
                            //console.log($scope.files)
                        } else if (resp == false) {
                            //console.log($scope.index)
                            $scope.index.splice(indexInArray)
                            //console.log($scope.index)
                            var popupdata = "No file selected or Selected File Format Not Allowed. Please use file with .doc.docx.txt.xls.xlsx.pdf.png.jpg.jepg.bmp Format Only "
                            $scope.popupopen('generalpopup', popupdata, $scope)
                        }

                    }, function (resp) {
                        var popupdata = popupdata + "Selected File Format Not Allowed. Please use file with (.doc,.docx,.txt,.xls,.xlsx,.pdf,.png,.jpg,.jepg,.bmp) Extensions only "
                        $scope.popupopen('generalpopup', popupdata, $scope)
                    })

        }

        $scope.enableupload = function (indexInArray) {
            //console.log($scope.index[indexInArray])
            if (typeof ($scope.index[indexInArray]) != 'undefined')
                return false
            else
                return true

        }

        $scope.addFile = function (indexInArray) {
            $scope.loading = true
            UploadFileService.uploadfile($scope, $scope.files, indexInArray)
        }

        $scope.viewUploadedFile = function (indexOfFile) {
            $scope.loading = true
            UploadFileService.viewUploadedFile($scope, indexOfFile)
        }

        $scope.downloadFile = function (indexOfFile) {
            $scope.loading = true
            UploadFileService.downloadFilefun($scope, indexOfFile)
        }
        $scope.pocUpload = true;
        $scope.ExcelExport = function (event) {
            var input = event.target;
            var reader = new FileReader();
            reader.onload = function () {
                var fileData = reader.result;
                var wb = XLSX.read(fileData, {type: 'binary'});

                wb.SheetNames.forEach(function (sheetName) {
                    var rowObj = XLSX.utils.sheet_to_row_object_array(wb.Sheets[sheetName]);
                    //$scope.jsonObj = JSON.stringify(rowObj);
                    $scope.jsonObj = rowObj;
                    //console.log($scope.jsonObj)
                    $scope.pocUpload = false;
                })
            };
            $scope.pocUpload = false;
            reader.readAsBinaryString(input.files[0]);
        }

        $scope.insertPOCDetails = function () {
            $scope.removedObj = [];
            angular.forEach($scope.jsonObj, function (json) {
                console.log(json);
                if ((!json.hasOwnProperty('SELLER NAME') || !json.hasOwnProperty('POC NAME')) || (!json.hasOwnProperty('POC CONTACT NO') && !json.hasOwnProperty('POC EMAIL')) || json.hasOwnProperty('POC EMAIL').length > 50) {
                    //$scope.removedObj.push(json);
                    var index = $scope.jsonObj.indexOf(json);
                    if (index != -1) {
                        console.log(index)
                        $scope.jsonObj.splice(index, 1);
                        $scope.removedObj.push(json);
                    }
                }
            })
            $scope.jsonObj = JSON.stringify($scope.jsonObj);
            //console.log($scope.jsonObj);
            //console.log($scope.removedObj);
            var dataObj = {"poc": $scope.jsonObj};
            //console.log(dataObj);
            $scope.pocSuccess = false;
            fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, Leykart_DatabaseConstant.urlpath, 'InsertPOC', dataObj)
                    .then(function (response) {
                        if (response.data == null || response.data == undefined || response.data.indexOf('Notice') != -1 || response.data.indexOf('Warning') != -1 || response.data == "  ") {
                            if ($scope.removedObj.length > 0) {
                                $scope.pocSuccess = true;
                                var popupdata = "The following records cannot be entered. Please make sure you have entered both the Seller Name and POC Name, and mentioned either the POC Contact Number or the Email ID. <br/><table><tr><th>POC CATEGORY</th><th>SELLER ID</th><th>SELLER NAME</th><th>POC NAME</th><th>POC CONTACT NO</th><th>POC EMAIL</th></tr><tr ng-repeat='removed in removedObj'><td>{{removed['POC CATEGORY']}}</td><td></td></tr></table>";
                                $scope.popupopen('removedObjects', popupdata, $scope)
                            } else {
                                $scope.pocSuccess = true;
                                var popupdata = "POC Details have been updated.";
                                $scope.popupopen('generalpopup', popupdata, $scope)
                            }
                            setTimeout(function () {
                                $scope.pocSuccess = false;
                            }, 3000);
                            $scope.pocUpload = true;
                        }
                        $scope.jsonObj = JSON.parse($scope.jsonObj);
                    }, function (error) {});
        }

        $scope.downloadPOCDetails = function () {
            var fileName = "POC Details.xlsx";
            fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, Leykart_DatabaseConstant.urlpath, 'GetPOC', null)
                    .then(function (response) {
                        if (response.data['POC CATEGORY'] == "" || response.data.indexOf('administrator') < 0) {
                            if (response.data['POC CATEGORY'] == "") {
                                var tempArray = []
                                tempArray.push(response.data);
                                $scope.jsonObj = tempArray;
                            } else {
                                $scope.jsonObj = response.data;
                                angular.forEach($scope.jsonObj, function (item) {
                                    item['POC CONTACT NO'] = Number(item['POC CONTACT NO']);
                                });
                            }
                            alasql('SELECT * INTO XLSX("POC Details.xlsx",{headers:true}) FROM ?', [$scope.jsonObj]);
                        }
                        $scope.jsonObj = '';
                    }, function (error) {});
        }

    }])


app.controller("admindwnldfeedbackcntrl", ['$scope', 'Leykart_DatabaseConstant', 'fetchdatabase', 'ConvertJsonToCsvSrv', 'authenticationSvc', 'magento_ConstantApi',
    function ($scope, Leykart_DatabaseConstant, fetchdatabase, ConvertJsonToCsvSrv, authenticationSvc, magento_ConstantApi) {

        $scope.setnavshow(false);
        $scope.highlightActiveTab = 'admin.dwnldfeedback';
        $scope.feedback = '';
        var dateAsData = {"from_date": '', "to_date": ''}
        var dateforOsticket = {"from_date": '', "to_date": ''}
        $scope.date = function (fromdate, todate) {
            today = new Date();
            if (typeof (fromdate) == typeof (today) && typeof (todate) == typeof (today)) {
                if (fromdate > todate || todate > today) {
                    $scope.feedback = '';
                    var popupdata = "Please enter a valid date range";
                    $scope.popupopen('generalpopup', popupdata, $scope)
                } else {
                    dateAsData.from_date = fromdate.getDate() + '.' + (fromdate.getMonth() + 1) + '.' + fromdate.getFullYear();
                    dateAsData.to_date = todate.getDate() + '.' + (todate.getMonth() + 1) + '.' + todate.getFullYear();

                    dateforOsticket.from_date = fromdate.getFullYear() + '-' + (fromdate.getMonth() + 1) + '-' + fromdate.getDate() + ' ' + '00:00:00'
                    dateforOsticket.to_date = todate.getFullYear() + '-' + (todate.getMonth() + 1) + '-' + (todate.getDate()) + ' ' + '23:59:59'
                    //console.log(fromdate.getDate()+'.'+fromdate.getMonth()+'.'+fromdate.getFullYear())
                    //console.log(todate.getDate()+'.'+todate.getMonth()+'.'+todate.getFullYear())
                    //console.log(dateforOsticket.from_date)
                    //console.log(dateforOsticket.to_date)
                    //$scope.ticketdetail()
                    //console.log(dateforOsticket);
                    //$scope.downloadfeedback(dateforOsticket);

                }
            } else {
                $scope.feedback = '';
                if (typeof (fromdate) != typeof (today)) {
                    var popupdata = "The 'From' date entered by you is not in proper format. Enter date in dd-mm-yyyy format.";
                } else if (typeof (todate) != typeof (today)) {
                    var popupdata = "The 'To' date entered by you is not in proper format. Enter date in dd-mm-yyyy format.";
                } else {
                    var popupdata = "The date entered by you is not in proper format. Enter date in dd-mm-yyyy format.";
                }
                $scope.popupopen('generalpopup', popupdata, $scope)
                var dd = today.getDate();
                var mm = today.getMonth(); //January is 0!

                var yyyy = today.getFullYear();
                if (dd < 10) {
                    dd = '0' + dd;
                }
                if (mm < 10) {
                    mm = '0' + mm;
                }
                var today = dd + '/' + mm + '/' + yyyy;

                //console.log("dd "+dd+" mm "+mm+" yyyy "+yyyy)
                $scope.dt = new Date(yyyy, mm, (dd - 7))      //'03.08.2017';
                $scope.toDate = new Date(yyyy, mm, dd)  //'10.09.2017';
            }
        }
        $scope.downloadAsFile = function (list, filename) {
            $scope.loading = true;
            //console.log($scope.feedback);
            if (list && list.indexOf('administrator') < 0) {
                if (filename == 'VerifiedOrder') {
                    angular.forEach(list, function (data) {
                        if (data.verify_comment == null) {
                            data.verify_comment = "";
                        }
                    })
                }
                var csvString = ConvertJsonToCsvSrv.ConvertToCSV(list);

                var a = $('<a/>', {
                    style: 'display:none',
                    href: 'data:application/octet-stream;base64,' + btoa(unescape(encodeURIComponent(csvString))),
                    download: filename + '.csv'
                }).appendTo('body')
                a[0].click()
                a.remove();
                $scope.loading = false;
            } else {
                var popupdata = "Data not available for the given time range";
                $scope.loading = false;
                $scope.popupopen('generalpopup', popupdata, $scope)
            }
        }
        $scope.feedback = '';
        $scope.download = 0;
        $scope.downloadfeedback = function (time = dateforOsticket) {
            //console.log("called")
            var dataObj = {"from_date": dateforOsticket.from_date, "to_date": dateforOsticket.to_date};
            //console.log(dataObj);
            fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, Leykart_DatabaseConstant.urlpath, 'ViewFeedback', dataObj)
                    .then(function (response) {
                        $scope.loading = true;
                        //console.log(response.data)
                        //response.data = $filter('orderBy')(response.data, 'id', true)
                        //console.log(response.data)
                        /*$scope.selectedCallerType = response.data[0]
                         $scope.callersType = response.data;*/
                        $scope.feedback = response.data;
                        if ($scope.feedback && $scope.feedback.indexOf('administrator') < 0) {
                            angular.forEach($scope.feedback, function (feedback) {
                                if (feedback.question_type == 'rating') {
                                    feedback.option_recorded = feedback.feedback_comment;
                                    feedback.feedback_comment = 'NULL';
                                }
                            });
                            var popupdata = "Feedback responses have been generated and downloaded from " + dateAsData.from_date + " to " + dateAsData.to_date + ". ";
                            $scope.popupopen('generalpopup', popupdata, $scope)
                            $scope.downloadAsFile($scope.feedback, 'feedback')
                            $scope.loading = false;
                        } else {
                            var popupdata = "No feedback responses available for the given time range.";
                            $scope.popupopen('generalpopup', popupdata, $scope);
                            $scope.loading = false;
                        }
                        //console.log($scope.feedback);
                    }, function (error) {
                        console.log("error in Downloading feedback")
                        console.log(error)
                        $scope.loading = false;
                    });

            //console.log("called")
            // var csvString = ConvertJsonToCsvSrv.ConvertToCSV($scope.listnewuser);
            // var a = $('<a/>', {
            // style:'display:none',
            // href:'data:application/octet-stream;base64,'+btoa(csvString),
            // download:'Listnewuser.csv'
            // }).appendTo('body')
            // a[0].click()
            // a.remove();
        }

        $scope.getlistofverifieduser = function () {
            $scope.loading = true;
            fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, Leykart_DatabaseConstant.urlpath, 'verifieduser', {"data": {"status": "YES", "from_date": dateAsData.from_date, "to_date": dateAsData.to_date}}).then(function (response) {
                $scope.loading = true;
                if (response.data[0] == null || response.data[0] == "" || response.data.indexOf("error") > -1 || response.data == "  " || response.data.indexOf("Notice") > -1 || response.data.indexOf("Warning") > -1) {
                    //console.log(response.data[0]);
                    var popupdata = "There is no verified user to display in the given time range"
                    $scope.popupopen('generalpopup', popupdata, $scope);
                    $scope.loading = false;
                } else {
                    $scope.listverifieduser = response.data[0];
                    angular.forEach($scope.listverifieduser, function (user) {
                        user.last_call_status = "Verified successfully";
                    })
                    $scope.downloadAsFile($scope.listverifieduser, 'VerifiedUser');
                    $scope.loading = false;
                    /*angular.forEach($scope.listnewuser,function(user){
                     if(user.call_status!=""&&user.call_status!=null){
                     var index=$scope.verifyStatus.findIndex(obj=>obj.status_id==user.call_status[user.call_status.length-2]);
                     if(index!=-1){
                     user.last_call_status=$scope.verifyStatus[index].status;
                     }
                     }
                     })*/
                }
            });
            /*$scope.loading = true
             //console.log("called")
             //var path = magento_ConstantApi.getnewuserlisturlpath+'NO';
             //authenticationSvc.login('GET',magento_ConstantApi.Apiendpoint,path,null,magento_ConstantApi.Headers)
             var data = {"status":"YES","from_date":dateAsData.from_date,"to_date":dateAsData.to_date}
             var path = 'getnewuserlisturlpath';
             authenticationSvc.login('POST',magento_ConstantApi.Apiendpoint,path,data)
             .then(function(response){
             //console.log(response.data)
             
             if(response.data == null || response.data == ""){
             var popupdata = "There is no verified user to display in the given time range"
             $scope.popupopen('generalpopup',popupdata,$scope)
             $scope.loading = false
             }
             else{	
             $scope.listverifieduser = response.data[0].customer
             $scope.downloadAsFile($scope.listverifieduser,'VerifiedUser');
             $scope.loading = false
             }
             },
             function(response){
             console.log("Error response received  while getting list of new user details from server")
             var msg = errorcodesrv.checkcode(response.status)
             if (msg !== "")
             var popupdata = msg
             else
             var popupdata = "Error response received  while getting list of new user details from server"
             $scope.popupopen('generalpopup',popupdata,$scope)
             console.log(response)
             $scope.loading = false
             })*/
        }

        $scope.downloadVerifiedOrder = function () {
            $scope.loading = true;
            fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, Leykart_DatabaseConstant.urlpath, 'verifiedorder', {"data": {"status": "yes", "from_date": dateAsData.from_date, "to_date": dateAsData.to_date}}).then(function (response) {
                $scope.loading = true;
                if (response.data[0] == null || response.data[0] == "" || response.data.indexOf("error") > -1 || response.data == "  " || response.data.indexOf("Notice") > -1 || response.data.indexOf("Warning") > -1) {
                    //console.log(response.data[0]);
                    var popupdata = "There is no verified order to display in the given time range."
                    $scope.popupopen('generalpopup', popupdata, $scope)
                    $scope.loading = false
                } else {
                    $scope.verifiedOrders = response.data[0];
                    angular.forEach($scope.verifiedOrders, function (order) {
                        order.last_call_status = "Verified successfully";
                    })
                    $scope.downloadAsFile($scope.verifiedOrders, 'VerifiedOrder');
                    $scope.loading = false;
                }
            });
            //$scope.loading=false;
            /*$scope.loading = true
             var dataobj = {"status":'yes',"from_date":dateAsData.from_date,"to_date":dateAsData.to_date}
             var path = 'verifiedorder';
             authenticationSvc.login('POST',magento_ConstantApi.Apiendpoint,path,dataobj)
             .then(function(response){
             //console.log(response.data[0])
             if(response.data[0] == null || response.data[0] == ""){
             var popupdata = "There is no verified order to display in the given time range."
             $scope.popupopen('generalpopup',popupdata,$scope)
             $scope.loading = false
             }
             else{	
             $scope.verifiedOrders = response.data[0]
             $scope.downloadAsFile($scope.verifiedOrders,'VerifiedOrders');
             $scope.loading = false
             }
             },
             function(response){
             console.log("Error response received  while getting Verified Orders ")
             console.log(response)
             var msg = errorcodesrv.checkcode(response.status)
             if (msg !== "")
             var popupdata = msg
             else
             var popupdata = "Error Response Received  While Getting Verified Orders Details From Server"
             $scope.popupopen('generalpopup',popupdata,$scope)
             $scope.loading = false
             })*/
        }

        // $scope.uploadSuccess = []
        // $scope.index = []
        // GET THE FILE INFORMATION.

        // $scope.getFileDetails = function (e) {

        // $scope.files = [];
        // $scope.$apply(function () {

        // // STORE THE FILE OBJECT IN AN ARRAY.
        // for (var i = 0; i < e.files.length; i++) {
        // $scope.files.push(e.files[i])
        // }

        // });
        // console.log($scope.files)
        // };
        // 'http://localhost:8083/LeyWhite_v3/data',
        // $scope.uploadFile = function(){
        // var fd = new FormData();
        // angular.forEach($scope.files,function(file){
        // fd.append("file", file);
        // })
        // $http.post('uploadFile.php',fd,{
        // withCredentials : false,
        // headers : {
        // 'Content-Type' : undefined
        // },
        // transformRequest : angular.identity
        // })
        // .then(function(data,header,config){
        // console.log(data);
        // }
        // ,function(data){console.log(data);}
        // );
        // }


    }])

app.controller("partscatalougecntrl", ['$scope', 'authenticationSvc', 'magento_ConstantApi', 'errorcodesrv'
            , function ($scope, authenticationSvc, magento_ConstantApi, errorcodesrv) {

                $scope.setnavshow(true);

                $scope.enterpartno = function () {
                    $scope.partdetails = ''
                }

                // fetching partcatalouge  details from magento
                $scope.getpartdetail = function () {
                    $scope.loading = true
                    //console.log("called")
                    if ($scope.searchText != null) {
                        //var path = magento_ConstantApi.getpartcatalougeurlpath+$scope.searchText ; 
                        //authenticationSvc.login('GET',magento_ConstantApi.Apiendpoint, path, null, magento_ConstantApi.Headers)
                        var data = {"partnumber": $scope.searchText}
                        var path = 'getpartcatalougeurlpath';
                        authenticationSvc.login('POST', magento_ConstantApi.Apiendpoint, path, data)
                                .then(function (response) {
                                    //console.log(response.data[0])
                                    // $scope.partdetails = response.data[0]
                                    // $scope.loading =false

                                    if (response.data[0] == null || response.data[0] == "") {
                                        var popupdata = "Didnt Receive Any Detail From Server"
                                        $scope.popupopen('generalpopup', popupdata, $scope)
                                        $scope.loading = false
                                    } else {
                                        $scope.partdetails = response.data[0]
                                        $scope.loading = false
                                    }

                                }, function (response) {
                                    console.log("Error response received  while getting part catalouge details  ")
                                    console.log(response)
                                    if (response.data.message === "Requested product doesn't exist")
                                        var msg = "Requested product doesn't exist"
                                    else
                                        var msg = errorcodesrv.checkcode(response.status)
                                    if (msg !== "")
                                        var popupdata = msg
                                    else
                                        var popupdata = 'Error Response Received  While Getting Part Catalouge Details From Server'
                                    $scope.popupopen('generalpopup', popupdata, $scope)
                                    $scope.loading = false
                                })
                    } else {
                        var popupdata = 'Please Enter Part Number To Search'
                        $scope.popupopen('generalpopup', popupdata, $scope)
                        $scope.loading = false
                    }

                } //end of  fetching partcatalouge details from magento

                $scope.elementFocus('search')
            }])


app.controller("instructionmanualcntrl", ['$scope', 'UploadFileService'
            , function ($scope, UploadFileService) {
                //$scope.loading =false
                $scope.setnavshow(true);

                $scope.viewUploadedFile = function (indexOfFile) {
                    $scope.loading = true
                    UploadFileService.viewUploadedFile($scope, indexOfFile)
                }

                $scope.downloadFile = function (indexOfFile) {
                    $scope.loading = true
                    UploadFileService.downloadFilefun($scope, indexOfFile)
                }
            }])


app.controller("viewpocdetailcntrl", ['$scope', 'fetchdatabase', 'Leykart_DatabaseConstant', 'errorcodesrv'
            , function ($scope, fetchdatabase, Leykart_DatabaseConstant, errorcodesrv) {

                $scope.setnavshow(true);
                $scope.loading = true
                // Start of getting poc detail from local database

                var dataObj = null;
                fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, Leykart_DatabaseConstant.urlpath, 'PocDetail', dataObj)
                        .then(function (response) {
                            //console.log(response.data)

                            if (response.data == null || response.data == "") {
                                var popupdata = "Didnt Receive Any Detail From Server"
                                $scope.popupopen('generalpopup', popupdata, $scope)
                                $scope.loading = false
                            } else {
                                $scope.pocDetails = response.data;
                                $scope.loading = false
                            }

                        }, function (error) {
                            console.log("error in getting poc detail ")
                            console.log(error)
                            var msg = errorcodesrv.checkcode(response.status)
                            if (msg !== "")
                                var popupdata = msg
                            else
                                var popupdata = 'Error In Getting Poc Detail From Leykart Database Server'
                            $scope.popupopen('generalpopup', popupdata, $scope)
                            $scope.loading = false
                        });
                // end of getting poc detail


                $scope.elementFocus('search')
            }])


app.controller("orderdetailscntrl", ['$scope', 'authenticationSvc', 'magento_ConstantApi', 'errorcodesrv'
            , function ($scope, authenticationSvc, magento_ConstantApi, errorcodesrv) {

                $scope.setnavshow(true);
                $scope.showsearchbar = true;

                $scope.oneAtATime = true;

                $scope.groups = [
                    {
                        title: 'Dynamic Group Header - 1',
                        content: 'Dynamic Group Body - 1'
                    },
                    {
                        title: 'Dynamic Group Header - 2',
                        content: 'Dynamic Group Body - 2'
                    }
                ];

                $scope.items = ['Item 1', 'Item 2', 'Item 3'];

                $scope.addItem = function () {
                    var newItemNo = $scope.items.length + 1;
                    $scope.items.push('Item ' + newItemNo);
                };

                $scope.status = {
                    isCustomHeaderOpen: false,
                    isFirstOpen: true,
                    isFirstDisabled: false
                };

                //$scope.searchText = 12;
                $scope.orderdetailsfun = function () {
                    $scope.loading = true
                    //console.log("called    " + $scope.searchText)
                    if ($scope.searchText != null) {
                        //var path = magento_ConstantApi.orderdetailurlpath+$scope.searchText;
                        //authenticationSvc.login('GET',magento_ConstantApi.Apiendpoint,path,null,magento_ConstantApi.Headers)
                        var data = {"orderid": $scope.searchText}
                        var path = 'orderdetailurlpath';
                        authenticationSvc.login('POST', magento_ConstantApi.Apiendpoint, path, data)
                                .then(function (response) {
                                    var suborder = []
                                    //var orderdetails = JSON.parse(response.data);
                                    if (response.data[0] == null || response.data[0] == "") {
                                        var msg = errorcodesrv.checkcode(response.status)
                                        if (msg !== "")
                                            var popupdata = msg
                                        else
                                            var popupdata = "Didnt Receive Any Detail From Server"
                                        $scope.popupopen('generalpopup', popupdata, $scope)
                                        $scope.loading = false
                                    } else {
                                        $scope.orderdetails = response.data[0];
                                        //console.log(response.data[0])
                                        for (var i = 0; typeof (response.data[0][i]) === 'object'; i++)
                                            suborder.push(response.data[0][i])
                                        $scope.suborders = suborder;
                                        $scope.loading = false
                                    }


                                },
                                        function (response) {
                                            console.log("Error response received  while getting order details ")
                                            console.log(response)
                                            var msg = errorcodesrv.checkcode(response.status)
                                            if (msg !== "")
                                                var popupdata = msg
                                            else if (response.data != null)
                                                var popupdata = response.data.message

                                            //var popupdata = "Error Response Received  While Getting Order Details From Server"
                                            $scope.popupopen('generalpopup', popupdata, $scope)
                                            $scope.loading = false


                                        })
                    } else {
                        var popupdata = 'Please Enter Order Number To Search'
                        $scope.popupopen('generalpopup', popupdata, $scope)
                        $scope.loading = false
                    }

                }

                $scope.elementFocus('search')

            }])


app.controller("datepickercntrl", ['$scope'
            , function ($scope) {

                $scope.today = function () {
                    $scope.dt = new Date();
                    $scope.toDate = new Date();
                };
                $scope.today();


                $scope.clear = function () {
                    $scope.dt = null;
                };

                $scope.inlineOptions = {
                    customClass: getDayClass,
                    minDate: new Date(),
                    showWeeks: true
                };

                $scope.dateOptions = {
                    dateDisabled: disabled,
                    formatYear: 'yy',
                    maxDate: new Date(2050, 5, 22),
                    minDate: new Date(),
                    startingDay: 1
                };



                $scope.toggleMin = function () {
                    $scope.inlineOptions.minDate = $scope.inlineOptions.minDate ? null : new Date();
                    $scope.dateOptions.minDate = $scope.inlineOptions.minDate;
                };

                $scope.toggleMin();

                $scope.open1 = function () {
                    $scope.popup1.opened = true;
                };

                $scope.open2 = function () {
                    $scope.popup2.opened = true;
                };

                $scope.setDate = function (year, month, day) {
                    $scope.dt = new Date(year, month, day);
                };

                $scope.formats = ['dd.MM.yyyy', 'dd-MM-yyyy', 'yyyy/MM/dd', 'shortDate'];
                $scope.format = $scope.formats[1];
                $scope.altInputFormats = ['M!/d!/yyyy'];

                $scope.popup1 = {
                    opened: false
                };

                $scope.popup2 = {
                    opened: false
                };

                var tomorrow = new Date();
                tomorrow.setDate(tomorrow.getDate() + 1);
                var afterTomorrow = new Date();
                afterTomorrow.setDate(tomorrow.getDate() + 1);
                $scope.events = [
                    {
                        date: tomorrow,
                        status: 'full'
                    },
                    {
                        date: afterTomorrow,
                        status: 'partially'
                    }
                ];

                function getDayClass(data) {
                    var date = data.date;
                    var mode = data.mode;
                    //console.log(mode)
                    if (mode === 'day') {
                        var dayToCheck = new Date(date).setHours(0, 0, 0, 0);

                        for (var i = 0; i < $scope.events.length; i++) {
                            var currentDay = new Date($scope.events[i].date).setHours(0, 0, 0, 0);

                            if (dayToCheck === currentDay) {
                                return $scope.events[i].status;
                            }
                        }
                    }

                    return '';
                }

                //"from_date":"03.08.2017",
                //"to_date":"10.09.2017"
                var today = new Date();
                var dd = today.getDate();
                var mm = today.getMonth(); //January is 0!

                var yyyy = today.getFullYear();
                if (dd < 10) {
                    dd = '0' + dd;
                }
                if (mm < 10) {
                    mm = '0' + mm;
                }
                var today = dd + '/' + mm + '/' + yyyy;

                //console.log("dd "+dd+" mm "+mm+" yyyy "+yyyy)
                $scope.dt = new Date(yyyy, mm, (dd - 1))      //'03.08.2017';
                $scope.toDate = new Date(yyyy, mm, dd)  //'10.09.2017';
                $scope.date($scope.dt, $scope.toDate);

                $scope.dateGo = function () {
                    //console.log("called")
                    $scope.loading = true;
                    $scope.date($scope.dt, $scope.toDate);
                    //$scope.loading=false;
                }

                //Disable weekend selection
                // function disabled(data) {
                // var date = data.date;
                // var mode = data.mode;
                // //console.log(mode)
                // return mode === 'day' && (date.getDay() === 0 || date.getDay() === 6);
                // }

                //Disable Future date  selection year month day
                function disabled(data) {
                    var date = data.date;
                    var mode = data.mode;
                    //console.log(mode)
                    //console.log(date.getFullYear()+"  "+ date.getMonth()+"  "+ date.getDate())
                    //console.log(mode)
                    if (mode === 'year')
                        return date.getFullYear() > new Date().getFullYear()
                    if (mode === 'month')
                        return ((date.getFullYear() > new Date().getFullYear()) || (date.getFullYear() == new Date().getFullYear() &&
                                date.getMonth() > new Date().getMonth()))
                    if (mode === 'day') {
                        if ((date.getFullYear() > new Date().getFullYear()) ||
                                (date.getFullYear() == new Date().getFullYear() &&
                                        date.getMonth() > new Date().getMonth()))
                            return true
                        else if (date.getFullYear() == new Date().getFullYear() && date.getMonth() == new Date().getMonth()
                                && date.getDate() > new Date().getDate())
                            return true
                    }

                    //return mode === 'day' && (date.getDay() === 0 || date.getDay() === 6);
                }
            }])

