app.service('fetchdatabase',['$http','$localStorage','$q',function($http,$localStorage,$q ){
	var fetch=this;
	 
	
	fetch.ApiData=function (url,index){
	   //return $http.get(Json_API.Apiendpoint)
	   return $http.get('data/callcentrejsondata.json')
				  .then(function(response){ 
				  //console.log(response)
				  return response.data[index];
				},function(error){
					console.log(error)
					return error;
				 })
     
	
	}
	
	
	fetch.leykartDatabase = function (urlMethod,api,urlpath,phpFunctionIdentifier,dataObj){
		//console.log("here")
		var deferred = $q.defer();
	    $http({
		   method: urlMethod,
		   url: api+urlpath+'?'+phpFunctionIdentifier,
		   data: dataObj  
	   }).then(function(response){

			// if(response.data.error == 'true')    
			// 	deferred.reject({'data':response.data.message}); 
		   //console.log(response)
		   //if condition for checking if the ticket got created in leykart database or not 

		   if(response.data.error == 'true')  
		   		deferred.reject(response.data.message);
		   else if(phpFunctionIdentifier === 'createticket' && response.data === "   true"){
			   //console.log("Received success response from leykart database")
			   deferred.resolve(response);
			   //return response;
		   }
		   
		   // if condition for formatiing the action to be taken 
			//console.log(response.data)
		   //let actionNotDefined = 'No action defined ';
		   
		   else if(phpFunctionIdentifier === 'actionToBeTaken' &&   response.data.length == null){
			   //console.log(response);
			   deferred.resolve(['There is no entry  of action to be taken in database for the selected caller type and issue category']);
			   //return ['please select the caller type first ']
		   }
		   //&& response.data[0].action != undefined
		   else if(phpFunctionIdentifier === 'actionToBeTaken' && response.data[0] != null ){
			  //console.log("if am here");
			  //console.log(response.data[0].action)
			  formatedData= fetch.DomElem(response.data[0].action);
			  deferred.resolve(formatedData);
			  //return formatedData;
		   }
		   deferred.resolve(response);
		   
		  },function(error){
			   //console.log("Didn't receive success response from leykart database")
			   //console.log(error)
			   deferred.reject(error);
			   //return error;
		   })

    return deferred.promise;
     
	
	}
	
	
	fetch.DomElem = function(dataArry){
		        //console.log("!!!!!!called domelem");
				if (!dataArry) return dataArry;
				var listArray = [];						
				var lines = dataArry.split('\n');			
				for (var i = 0; i < lines.length; i++) {				
					if(lines[i] && lines[i].trim() != ''){					
						listArray.push(lines[i]);				
					}			
				}
				
				//console.log("contents"+listArray);
				return listArray;
		}
		
	fetch.convertStringToJsonObject = function(dataArry){
		        //console.log("!!!!!!called domelem");
				if (!dataArry) return dataArry;
				var listArray = [];						
				var lines = dataArry.split('\n');			
				for (var i = 0; i < lines.length; i++) {				
					if(lines[i] && lines[i].trim() != ''){					
						listArray.push({'issue':lines[i].trim()});				
					}			
				}
				
				//console.log("contents"+listArray);
				return listArray;
		}
		
	return fetch;
	
	//end of return
}])

// service for removing verified order from the table
app.factory('removingVerifiedItemSrvc',['$filter',function($filter){

	function removeChecked(tableCollection,arrayForTrackingVerifiedOrder,field){
		//console.log("tableCollection")
		//console.log(tableCollection)
		var newtableCollection = [];
		var removedArray = [];
		var sortedVerifiedArray = $filter('orderBy')(arrayForTrackingVerifiedOrder,'index')
		//console.log("sorted")
		//console.log(sortedVerifiedArray)
		var j = 0 ;

		// this IF is for verify new order
		if(field === 'suborder_id'){
			for(var i=0;i< sortedVerifiedArray.length;i++){
				while(j<tableCollection.length){
					// here we need to check as per the fieldToCheck parameter but for time being i have done on basis of  Serialno
					if (tableCollection[j].suborder_id != sortedVerifiedArray[i].index){
						// console.log(tableCollection[j]) suborder_id
						newtableCollection.push(tableCollection[j])
					}
					else{
						removedOrderDetails ={}
						removedOrderDetails.order_id = tableCollection[i].suborder_id
						removedOrderDetails.verified = 'YES'
						if(sortedVerifiedArray[i].comment)
							removedOrderDetails.comment = sortedVerifiedArray[i].comment
						else 
							removedOrderDetails.comment = 'order verified'
						
						//tableCollection[j].Comments = sortedVerifiedArray[i].comment
					
						removedArray.push(removedOrderDetails)
						j=j+1;	
						break; 
					}
					j=j+1;		
				}
			}
		}
		
		// this IF is for Verify  new user tab
		if(field === 'mobile_no'){
			for(var i=0;i< sortedVerifiedArray.length;i++){
				//console.log("tableCollection")
				//console.log(tableCollection)
				while(j<tableCollection.length){
					// here we need to check as per the fieldToCheck parameter but for time being i have done on basis of  Serialno
					if (tableCollection[j].customer.mobile_no != sortedVerifiedArray[i].index){
						// console.log(tableCollection[j]) suborder_id
						newtableCollection.push(tableCollection[j])
					}
					else{
						removedOrderDetails ={}
						removedOrderDetails.user_id = tableCollection[i].user_id
						removedOrderDetails.verified = 'YES'
						if(sortedVerifiedArray[i].comment)
							removedOrderDetails.comment = sortedVerifiedArray[i].comment
						else 
							removedOrderDetails.comment = 'user verified'
						
						//tableCollection[j].Comments = sortedVerifiedArray[i].comment
					
						removedArray.push(removedOrderDetails)
						j=j+1;	
						break; 
					}
					j=j+1;		
				}
			}
		}
		 
		if(j< tableCollection.length){
			var remainingArray = tableCollection.slice(j,tableCollection.length);
			for(var i=0;i< remainingArray.length;i++)
				newtableCollection.push(remainingArray[i])
		}
		//console.log("verified Items")
		//console.log(removedArray)
		arrayForTrackingVerifiedOrder = []
		return {
			removedArray,
			newtableCollection,
			arrayForTrackingVerifiedOrder
		}
	}
	
	return {
		removeChecked : removeChecked 
	};
}])
// end of service for removing verified order from the table

app.factory('assignTransferTicketSrv',['$filter',function($filter){
	
	function ticketTransfer($scope,arrayForTrackingVerifiedOrder){
		
		arrayForTrackingVerifiedOrder = $filter('orderBy')(arrayForTrackingVerifiedOrder,'index.ticket_id')
		
		if($scope.transferTo)
			return transferOrAssign($scope,'transferTo',$scope.transferTo,arrayForTrackingVerifiedOrder)
		if($scope.assignTo)
			return transferOrAssign($scope,'assignTo',$scope.assignTo,arrayForTrackingVerifiedOrder)
		
	}
	
	function transferOrAssign($scope,tcktforwardType,whomTo,arrayForTrackingVerifiedOrder){    // either transfer or assign
			//console.log(arrayForTrackingVerifiedOrder)
			var remainingTicket = []
			var collectionOfticket = []
			// if ticket is to be Assigned to other person
			if($scope.master){    // master shows select all button is checked
				angular.forEach($scope.ticketdetails, function(value, key){
					ticketObj = value
					ticketObj[tcktforwardType] = whomTo;
					collectionOfticket.push(ticketObj);
				});
			}
			else{
				var j=0;
				angular.forEach(arrayForTrackingVerifiedOrder, function(value, key){
					while(j<$scope.ticketdetails.length){
						if (value.index == $scope.ticketdetails[j].ticketNo){
							ticketObj = $scope.ticketdetails[j];
							ticketObj[tcktforwardType] = whomTo;
							collectionOfticket.push(ticketObj);
							j=j+1;
							break;
						}
						else{
							remainingTicket.push($scope.ticketdetails[j])
							j=j+1;
						}
					}
				})
				if(j<$scope.ticketdetails.length){
						for(var i=j;i< $scope.ticketdetails.length;i++)
							remainingTicket.push($scope.ticketdetails[i])
				}
			}
			
        console.log("list of tickets to be transfered or assigned")
		//console.log(collectionOfticket)
		console.log("earlier ticket")
		//console.log($scope.ticketdetails)
		console.log("remainingTicket")
		//console.log(remainingTicket)
		//$scope.ticketdetails = remainingTicket
		return {'tickettobetransferOrAssign' : collectionOfticket, 'remainingticket' :remainingTicket}
		
	}
	
	return {
		ticketTransfer : ticketTransfer
	}
}])

// for storing the information of logged in user
app.service('userInfosvc', function () {
	this.userInfo = [{
					  "staff_id": null,
					  "username": null,
					  "pass": null,
					  "firstname": null,
					  "lastname": null,
					  "email": null,
					  "role": null
					}];
	
  this.setUserInfo = function (userdetail) {
	  this.userInfo[0].staff_id = userdetail.staff_id;
      this.userInfo[0].username = userdetail.username;
	  this.userInfo[0].firstname = userdetail.firstname;
      this.userInfo[0].lastname = userdetail.lastname;
	  this.userInfo[0].email = userdetail.email;
      if(!userdetail.role)
		  this.userInfo[0].role = "Agent";
	  else 
		  this.userInfo[0].role = userdetail.role;
  };
  
  this.setpass = function(value){
	  this.userInfo[0].pass = value
  }
  
  this.returnUserInfo = function (){
	  return this.userInfo
  }
  
  this.printUserInfo=function(){
	 //console.log(this.userInfo[0].nameOfUser)
	  //console.log(this.userInfo[0].role)
  };
  
  this.destroyUserInfo = function () {
    this.userInfo[0].nameOfUser = null;
    this.userInfo[0].role = null;
  };
})

app.service("errorcodesrv",function(){
	this.checkcode= function(errorcode){
		//Content = "Bad Gatevar msgContent = "";
		var msgContent = "";
		if(errorcode == 401){
			msgContent = "User Unauthorized";
		}else if(errorcode == 404){
			msgContent = "Page not Found";
		}else if(errorcode == 403){
			msgContent = "Forbidden";
		}else if(errorcode == 409){
			msgContent = "Conflict";
		}else if(errorcode == 405){
			msgContent = "Method Not Allowed";
		}else if(errorcode == 400){
			msgContent = "Bad Request";
		}else if(errorcode == 410){
			msgContent = "Gone";
		}else if(errorcode == 411){
			msgContent = "You must provide the Content-Length HTTP header. This error has no response body.";
		}else if(errorcode == 412){
			msgContent = "Precondition Failed";
		}else if(errorcode == 413){
			msgContent = "Payload Too Large";
		}else if(errorcode == 416){
			msgContent = "Requested Range Not Satisfiable";
		}else if(errorcode == 429){
			//A Cloud Storage JSON API usage limit was exceeded.
			msgContent = "Too Many Requests";
		}else if(errorcode == 500){
			//We encountered an internal error. Please try again using truncated exponential backoff.
			msgContent = "Internal Server Error";
		}else if(errorcode == 502){
			//This error is generated when there was difficulty reaching an internal service. It is not formatted with a JSON document. Please try again  //using truncated exponential backoff.
			//msgway";
			msgContent ="Error: Server Error The server encountered a temporary error and could not complete your request.<p>Please try again in 30 seconds";
		}else if(errorcode == 503 ){
			//We encountered an internal error. Please try again using truncated exponential backoff.
			msgContent = "Service Unavailable";
		}
		else if(errorcode == -1){
			msgContent = "Received data=null and Status = -1 From Server";
		}
		return msgContent;
	}
})

// factory containing function for authentication and authorization
app.factory("authenticationSvc", function($http, $q, $window,$localStorage, $sessionStorage,userInfosvc,errorcodesrv,magento_ConstantApi,fetchdatabase,Leykart_DatabaseConstant ) {
  //var userInfo =[];
  //$http.defaults.headers.post["Content-Type"] = "text/plain";
  // $http.defaults.headers.common['Access-Control-Allow-Origin'] = '*';
    var authToken='';
    // function getAuthToken(){
    //     var dataObj="";
	// 	fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, Leykart_DatabaseConstant.urlpath, 'getAuthToken', dataObj)
	// 		.then(function(response){
	// 			//console.log(response)
	// 			authToken="Bearer "+response.data.AuthToken;
	// 			//console.log(authToken);
	// 		},function(error){
	// 			$scope.loading = false
	// 			console.log("error in fetching auth token")
	// 		});    
    // }
    // getAuthToken();
  function login(urlMethod,api,urlpath,datas,header) {
		//console.log("called http method of login")
		
		// if(urlMethod=="POST")
		// {			
			/*jQuery.ajax({
			url:"https://shopqa.leykart.com/rest/V1/CcmOrder/ccviewallorder",
			data:'{"from_date":"10.11.2017","to_date":"10.11.2017"}',
			type:"POST",
			dataType: 'json',
			headers:{"Content-Type":"application/json"},
			success:function(resultData)
			{
				console.log(resultData);
			} });*/
			
		// }
		// else{			
            
			var deferred = $q.defer();
            var dataObj={'url':urlpath,'data':datas};
            //if(api.indexOf(magento_ConstantApi.Apiendpoint)>=0){
				//console.log("here")
				fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, Leykart_DatabaseConstant.urlpath, 'magentoCall', dataObj)
				.then(function(response){   
					//console.log(response)
					if(response.data.error == 'true')  
						  
						deferred.reject(response.data);    
					else
						deferred.resolve(response);   
							//alert(response)
                            //authToken="Bearer "+response.data.AuthToken;
							//console.log(authToken);
						},function(error){
							//$scope.loading = false
							//alert(error)
							console.log("error in data from magento server")
                            deferred.reject(error);
						});    
			//}
			// else{
				
				// $http({
				// 	method: urlMethod,
				// 	url: api+urlpath,
				// 	data: datas,
				// 	//type:urlMethod,
				// 	headers: header
				// }).then(function(response) {
				// 	//console.log("inside authenticationSvc success response received from os ticket    ")
				// 	//console.log(response.data)
				// 	if(response.data.error == 'true')  
				// 		  deferred.reject(response.data);
				// 	else
				// 		deferred.resolve(response);
				// }, function(error) {
				// 	//console.log("inside authenticationSvc. Error in login received from os ticket.. "  )
				// 	//console.log(errorcode.checkcode(error.status))
				// 	//console.log(error)
				// 	deferred.reject(error);  
				// });
			//}
			//return deferred.promise;
		//}
		
		// $http({
	// url:"https://shopqa.leykart.com/rest/V1/CcmOrder/ccviewallorder",
	// data:'{"from_date":"10.11.2017","to_date":"10.11.2017"}',
	// type:"POST",
	// dataType: 'json',
	// headers:{"Content-Type":"application/json"},
	// success:function(resultData)
	// {
		// console.log(resultData);
    // } }).then(function(response) {
			// //console.log("inside authenticationSvc success response received from os ticket    ")
			// //console.log(response.data)

		    // deferred.resolve(response);
		// }, function(error) {
			// //console.log("inside authenticationSvc. Error in login received from os ticket.. "  )
			// //console.log(errorcode.checkcode(error.status))
			// console.log(error)
			// deferred.reject(error);  
		// });
		
			// }).then(function(data, status, headers, config){
				// deferred.resolve(data);
			// }).catch(function(data, status, headers, config) {
				// console.log("inside authenticationSvc. Error in login received from os ticket.. "  )
				// console.log(data);
				// console.log(status);
				// console.log(headers);
				// //$ionicLoading.hide();
				// //$rootScope.msgPopupError(status);
				// console.log(config);
				// deferred.reject(data);
			// })
		return deferred.promise;
		
  }
  
  function getMethod(urlMethod,api,urlpath) {
		console.log("called http method of login")
		var deferred = $q.defer();
		$http({ 
			method: urlMethod,
			url: api+urlpath
		}).then(function(response) {
			console.log("inside authenticationSvc success response received from os ticket    ")
			//console.log(response.data)

		    deferred.resolve(response);
		}, function(error) {
			console.log("inside authenticationSvc. Error in login received from os ticket.. "  )
			console.log(error)
			deferred.reject(error);  
		});

		return deferred.promise;
  }
  
  // function getUserInfo() {
	  // if(this.isAuthenticated){
		  // console.log("getUserInfo"+this.userInfo )
		  // return this.userInfo;
	  // }
	  // //return this.userInfo;
  // }
  
  function logout() {
	  console.log("successfully logout")
	  userInfosvc.destroyUserInfo(); ;
	  //console.log("userInfo set to  null  "+userInfosvc.returnUserInfo())
	  $sessionStorage.userInfo = null;
	  $sessionStorage.somevalue = null
	  //$localStorage.userInfo = null;
  }
  
  function verifyuser(response,value) {
		var deferred = $q.defer();
		//if (response.staff_id != null)
		userInfosvc.setUserInfo(response[0]);
		userInfosvc.setpass(value);
		$sessionStorage.userInfo = userInfosvc.returnUserInfo();
		//$localStorage.userInfo = userInfosvc.returnUserInfo();
		if(response[0].role === "Leykart_Admin") 
			var SwitchToState = "admin.viewcancelrequest";
		else  
			var SwitchToState = "createnewticket" ;
		deferred.resolve(SwitchToState);
		return deferred.promise;
  }
  
  function isAuthenticated (){
	  return userInfosvc.returnUserInfo() != null ;
  };
  
 
  function isAuthorized (authorizedRoles) {
    if (!angular.isArray(authorizedRoles)) {
      authorizedRoles = [authorizedRoles];
    }
    return (this.isAuthenticated() &&
      authorizedRoles.indexOf(userInfosvc.userInfo[0].role) != -1);
  };
  
  return {
    login : login,
	verifyuser : verifyuser,
	isAuthenticated : isAuthenticated,
	isAuthorized : isAuthorized,
	logout : logout,
	getMethod : getMethod
  };
});


app.factory('AuthInterceptor', function ($rootScope, $q, AUTH_EVENTS) {
  return {
    responseError: function (response) { 
      $rootScope.$broadcast({
        401: AUTH_EVENTS.notAuthenticated,
        403: AUTH_EVENTS.notAuthorized,
        419: AUTH_EVENTS.sessionTimeout,
        440: AUTH_EVENTS.sessionTimeout
      }[response.status], response);
      return $q.reject(response);
    }
  };
})

// for extracting order no from ticket subject line 
app.service('extractOrdernoSrv',function(){
	
	this.extractorderno = function(arrayOfTickets){
		//console.log(arrayOfTickets)
		if(arrayOfTickets && arrayOfTickets !== 'null' && arrayOfTickets.length>0){
			for (var i = 0; i < arrayOfTickets.length; i++) {
				var orderNo = arrayOfTickets[i].subject.split("#")
				//console.log(orderNo[1])
				//console.log(orderNo[orderNo.length-1])
				if(isNaN(orderNo[orderNo.length-1]) == false )
					arrayOfTickets[i].self_added_orderno = orderNo[orderNo.length-1]
				else{
					//console.log("here")
					arrayOfTickets[i].self_added_orderno = "NA"
				}
				arrayOfTickets[i].self_added_issue_categ = orderNo[0]
				//arrayOfTickets[i].self_added_date_created = new Date(arrayOfTickets[i].created)
				
			}
			return arrayOfTickets
		}
	}
})


app.factory('focus', function($timeout, $window) {

    return function(id) {
      // timeout makes sure that is invoked after any other event has been triggered.
      // e.g. click events that need to run before the focus or
      // inputs elements that are in a disabled state but are enabled when those events
      // are triggered.
		$timeout(function() {
			var element = $window.document.getElementById(id);
			if(element)
			  element.focus();
		});
	};
})


app.factory('UploadFileService',function($http,fetchdatabase,Leykart_DatabaseConstant,authenticationSvc){
	
	function addfileinFilesArray($scope,file,indexInArray){
		//console.log($scope.files)
		var files2 = []
		var arrayLength = Math.max($scope.files.length-1,indexInArray)
		//console.log(arrayLength)
		for ( var i = 0; i <= arrayLength; i++){
			//console.log(i)
			if( i == indexInArray){
				file.id = indexInArray
				//file.name = file.name+'*'+indexInArray
				files2.push(file)
			}
			else if($scope.files[i] != null)
				files2.push($scope.files[i])
			else
				files2.push(null)
			//console.log($scope.files)
		}
		$scope.files = files2
		//console.log($scope.files)
	}
	
	function uploadfile($scope,files,indexOfFileToUpload,success,error){
 
		//var url = 'http://localhost:8083/LeyWhite_v3/data';
		//console.log(indexOfFileToUpload)
		for ( var j = 0; j < files.length; j++){
			//console.log("j  "+j)
			//console.log("index  "+indexOfFileToUpload)
			if(j == indexOfFileToUpload){
				var fd = new FormData();
				//files[i].idd = indexOfFileToUpload
				//console.log(files[j])
				var file = files[j]
				fd.append('file', files[j]);
				//fd.append('IdNo', indexOfFileToUpload);

				$http.post('/php/uploadFile.php',fd,{
					withCredentials : false,
					headers : {
						'Content-Type' : undefined
					},
					transformRequest : angular.identity
				})
				.then(function(response,header,config){
					//console.log(response.data);
					if( response.data === 'files uploaded successfully'){
						//console.log(files[i])
						var dataobj = {'id' : indexOfFileToUpload , 'filepath' : file.name }
						//console.log(dataobj)
						fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, Leykart_DatabaseConstant.urlpath, 'uploadFilePath', dataobj)
						.then(function(response){
							//console.log(response)
							if(response.data.indexOf("true")!=-1||response.data === "   true" ){
								$scope.loading = false
								console.log(" path is updated in database")
								//console.log("j  "+j)
								//console.log("index  "+indexOfFileToUpload)
								$scope.uploadSuccess[indexOfFileToUpload] = true
								//console.log($scope.uploadSuccess)
								j=0
							}
							else 
								$scope.loading = false
						},function(error){
							$scope.loading = false
							console.log("error in updating file path in database")
							console.log(error)
							$scope.uploadSuccess[indexOfFileToUpload] = false
						});
					}
					else{
						$scope.loading = false
						$scope.uploadSuccess[indexOfFileToUpload] = false
					}
						
				},
				function(response){
					$scope.loading = false;
					console.log("error in uploading file to server");
					console.log(response);
					$scope.uploadSuccess[indexOfFileToUpload] = false
				});
			}
			
		}
	}
	
	function viewUploadedFile($scope,indexOfFileToView){
		var dataobj = {'id' : indexOfFileToView}
		//console.log(dataobj)
		fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, Leykart_DatabaseConstant.urlpath, 'ViewFilePath', dataobj)
		.then(function(response){
			//console.log(response.data)
			
			if(response.data == '   "The file does not exist in Server"'){
				var popupdata = "File Is Not Available"
				$scope.popupopen('generalpopup',popupdata,$scope)
				$scope.loading = false
			}
			else if(response.data == '   "Error in getting file path from database"'){
				var popupdata = "Path Of File As Null Or Empty Received  From Leykart Server"
				$scope.popupopen('generalpopup',popupdata,$scope)
				$scope.loading = false
			}
			else{	
				var fileUrl = Leykart_DatabaseConstant.Apiendpoint+'/'+response.data[0].path 
				$scope.loading = false
				//console.log(fileUrl)
				window.open(fileUrl);
				// var header = {responseType: 'arraybuffer'}
				// authenticationSvc.login('GET','',fileUrl,null,header)
					// .then(function(res){
						// var file = new Blob([res.data], {type: 'application/pdf'});
						// var fileURL = URL.createObjectURL(file);
						// window.open(fileURL);
						// console.log(res)
						// $scope.loading = false
					// },function(error){
						// console.log(error)
						// $scope.loading = false
					// })
			}
			
		}
		,function(error){
			$scope.loading = false
			console.log("error in getting file path in database")
			console.log(error)
			var popupdata = "Path Of File Could Not Be ReceiVed From Leykart Server"
			$scope.popupopen('generalpopup',popupdata,$scope)
			
		});
	}
	
	function downloadFilefun($scope,indexOfFileToView){
		var dataobj = {'id' : indexOfFileToView}
		//console.log(dataobj)
		fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint, Leykart_DatabaseConstant.urlpath, 'ViewFilePath', dataobj)
		.then(function(response){
			//console.log(response)
			
			if(response.data.indexOf("The file does not exist in Server")!=-1||response.data == '   "The file does not exist in Server"'){
				var popupdata = "File Is Not Available"
				$scope.popupopen('generalpopup',popupdata,$scope)
				$scope.loading = false
			}
			else if(response.data.indexOf("Error in getting file path from database")!=-1||response.data == '   "Error in getting file path from database"'){
				var popupdata = "Path Of File As Null Or Empty Received  From Leykart Server"
				$scope.popupopen('generalpopup',popupdata,$scope)
				$scope.loading = false
			}
			else{
				var fileUrl = Leykart_DatabaseConstant.Apiendpoint+'/'+response.data[0].path; 
				var filename = response.data[0].path .split("/")[1]
				//$scope.loading = false
				//window.open(fileUrl);
				var header = {responseType: 'arraybuffer'}
				authenticationSvc.login('GET','',fileUrl,null,header)
					.then(function(res){
						var anchor = angular.element('<a/>');
                        if(fileUrl.indexOf('.doc')!=-1 || fileUrl.indexOf('.xls') || fileUrl.indexOf('.txt')){
                            anchor.attr({
							href: fileUrl,
							target: '_blank',
							download: filename
						})[0].click();
                        }
                        else{
						anchor.attr({
							href: 'data:attachment/csv;charset=utf-8,' + encodeURI(res.data),
							target: '_blank',
							download: filename
						})[0].click();
                        }
						$scope.loading = false
					},function(error){
						console.log(error)
						var popupdata = " File Could Not Be Found In Server"
						$scope.popupopen('generalpopup',popupdata,$scope)
						$scope.loading = false
					})
			}
			
		}
		,function(error){
			$scope.loading = false
			var popupdata = "Path Of File Could Not Be ReceiVed From Leykart Database Server"
			$scope.popupopen('generalpopup',popupdata,$scope)
			console.log("error in getting file path from leykart database")
			console.log(error)
			
		});
	}
	
	return {uploadfile :uploadfile,
			addfileinFilesArray : addfileinFilesArray,
			viewUploadedFile : viewUploadedFile,
			downloadFilefun : downloadFilefun
			}
})

app.service('ConvertJsonToCsvSrv',function(){
	
	this.ConvertToCSV = function(objArray) {
            var array = typeof objArray != 'object' ? JSON.parse(objArray) : objArray;
            var str = '';
			for (var ind in array[0]){
				str += ind+','
			}
			str+= '\n';
            for (var i = 0; i < array.length; i++) {
                var line = '';
                for (var index in array[i]) {
					if (line != '') 
						line += ','
                    if(array[i][index]!=null){
					var strWithoutcomma = array[i][index].toString().replace(/\,/g," ");
                    line += strWithoutcomma;}
                    else{
                        line+='NULL';
                    }
                }

                str += line + '\r\n';
            }

            return str;
        }
})

// for admin view cancellation request
app.factory('mergeOrder_Ticket', function($filter) {
    function merge($scope) {
		//console.log($scope.adminorderDetailsCopy)
		//console.log($scope.ticketWithOrderno)
		var sortedOrderdetails = $scope.adminorderDetailsCopy
		var sortedOrderdetails = $filter('orderBy')($scope.adminorderDetailsCopy,'suborder_id')
		var sortedTicketdetails = $filter('orderBy')($scope.ticketWithOrderno,'self_added_orderno')
		//console.log(sortedOrderdetails)
		//console.log(sortedTicketdetails)
		//console.log(sortedOrderdetails.length)
		//console.log(sortedTicketdetails.length)
		var i=0;var j=0;var mergedContent=[];var count = 0
		// if(sortedOrderdetails.length < sortedTicketdetails.length)
			// len1 = sortedOrderdetails.length
			// len2 = sortedTicketdetails.length
		// else
			// len2 = sortedOrderdetails.length
			// len1 = sortedTicketdetails.length
		if(sortedOrderdetails != null){
			for(i=0 ;i< sortedOrderdetails.length; i++){
				var flag=false
				//console.log("parse  "+ parseInt(sortedOrderdetails[i].suborder_id,10))
				for(j=0;j< sortedTicketdetails.length;j++){
					//console.log("  "+ sortedTicketdetails[j].self_added_orderno)
					//console.log("parse  "+ parseInt(sortedOrderdetails[i].suborder_id,10)+"  "+parseInt(sortedTicketdetails[j].self_added_orderno,10))
					//console.log(sortedTicketdetails[0])
					if((sortedOrderdetails[i].suborder_id == sortedTicketdetails[j].self_added_orderno) ||
					   (parseInt(sortedOrderdetails[i].suborder_id,10) == parseInt(sortedTicketdetails[j].self_added_orderno,10))){
						
						//Object.assign(sortedOrderdetails[i],sortedTicketdetails[j])
						sortedOrderdetails[i].ticket_no = sortedTicketdetails[j].ticket_number
						sortedOrderdetails[i].ticket_id = sortedTicketdetails[j].ticket_id
						sortedOrderdetails[i].self_added_reason = sortedTicketdetails[j].self_added_issue_categ
						sortedOrderdetails[i].tckt_detail = sortedTicketdetails[j]
						//console.log(sortedOrderdetails[i])
						mergedContent.push(sortedOrderdetails[i])
						flag=true
						break
					}
				}
				if(flag == false){
					count++
					//sortedOrderdetails[i].ticket_no = ""
					//sortedOrderdetails[i].self_added_reason =""
					//sortedOrderdetails[i].ticket_id ="" 
					//console.log(sortedOrderdetails[i])
					mergedContent.push(sortedOrderdetails[i])
				}
			}
		}
		
		// while(i < sortedOrderdetails.length && j < sortedTicketdetails.length){
			// //console.log("inside while")
			// if( sortedTicketdetails[j].self_added_orderno == ""){
				// console.log("blank  "+sortedTicketdetails[j].self_added_orderno +"   unsort   "+$scope.ticketWithOrderno[j].self_added_orderno)
				// j++
			// }
			// else if(sortedOrderdetails[i].suborder_id == sortedTicketdetails[j].self_added_orderno){
				// console.log("same  "+sortedTicketdetails[j].self_added_orderno+"   unsort   "+$scope.ticketWithOrderno[j].self_added_orderno)
				// sortedOrderdetails[i].ticket_no = sortedTicketdetails[j].ticket_number
				// mergedContent.push(sortedOrderdetails[i])
				// i++;j++
			// }
			// else{
				// //console.log("other  "+sortedTicketdetails[j].self_added_orderno)
				// if( sortedOrderdetails[i].suborder_id > sortedTicketdetails[j].self_added_orderno){
					// console.log("other  "+sortedTicketdetails[j].self_added_orderno+"   unsort   "+$scope.ticketWithOrderno[j].self_added_orderno)
					// j++
				// }
				// else{
					// console.log("push  "+sortedTicketdetails[j].self_added_orderno+"  unsort  "+$scope.ticketWithOrderno[j].self_added_orderno)
					// sortedOrderdetails[i].ticket_no = ''
					// mergedContent.push(sortedOrderdetails[i])
					// i++
				// }
			// }
			// //i++;j++
		// }
		
		// while(i < sortedOrderdetails.length){
			// sortedOrderdetails[i].ticket_no = ''
			// mergedContent.push(sortedOrderdetails[i])
			// i++
		// }
		//console.log(mergedContent)
		//console.log(count)
		$scope.admincancelrequestdata = mergedContent
	};
	
	return{
		merge : merge
	}
})



// for cancelling order and assigning ticket
app.factory('adminOrderCan_TicketAssignSrv',['$q','magento_ConstantApi','authenticationSvc','OSTicket_ConstantApi',
'userInfosvc','errorcodesrv','fetchdatabase','Leykart_DatabaseConstant',
	function($q,magento_ConstantApi,authenticationSvc,OSTicket_ConstantApi,userInfosvc,errorcodesrv,fetchdatabase,
	Leykart_DatabaseConstant) {
	
    function calledfromCntrlfunc(arrayForTrackingVerifiedOrder,$scope) {
		var deferred = $q.defer();
		// var orders=[]
		// var tickets =[]
		var count = 0
		// for(obj in arrayForTrackingVerifiedOrder[0].order){
			
			// console.log(arrayForTrackingVerifiedOrder[0].order[obj])
			
			// var orderid = arrayForTrackingVerifiedOrder[0].order[obj].orderid
			// var cancelreason = arrayForTrackingVerifiedOrder[0].order[obj].cancelreason
			// var cstatus = arrayForTrackingVerifiedOrder[0].order[obj].cstatus
			// var comment = arrayForTrackingVerifiedOrder[0].order[obj].comment
			
			// orders.push({"orderid":orderid,"cancelreason":cancelreason,"cstatus":cstatus,"comment":comment})
		    // tickets.push(arrayForTrackingVerifiedOrder[0].order[obj].tkt_detail)
			
			// cancelOrder(orders[obj])
			// .then(function(response){
				// count=count+1
				// console.log(obj)
				// console.log(count)
				// transferTicket(tickets[count-1])
				// .then(function(response){
					// console.log(obj)
					// if(count == arrayForTrackingVerifiedOrder[0].order.length){
						// $scope.loading = false
						// $scope.getcancelrequest()
						// deferred.resolve(true);
						// return deferred.promise;
					// }
					
				// },function(response){
					// console.log("error")
					// deferred.reject(false);
				// })
			// },function(response){
				// console.log("error")
				// deferred.reject(false);
			// })
		// }
		
		
		var obj = 0
		function iterateover(obj,$scope){
			
			var orders=[]
			var tickets =[]
			
			//console.log(arrayForTrackingVerifiedOrder[0].order[obj])
			
			var orderid = arrayForTrackingVerifiedOrder[0].order[obj].orderid
			var cancelreason = arrayForTrackingVerifiedOrder[0].order[obj].cancelreason
			var cstatus = arrayForTrackingVerifiedOrder[0].order[obj].cstatus
			var comment = arrayForTrackingVerifiedOrder[0].order[obj].comment
			
			orders.push({"orderid":orderid,"cancelreason":cancelreason,"cstatus":cstatus,"comment":comment})
		    tickets.push({'tckt':arrayForTrackingVerifiedOrder[0].order[obj].tkt_detail,'cmnt':arrayForTrackingVerifiedOrder[0].order[obj].comment})
			//console.log(tickets)
			cancelOrder(orders[0],$scope).then(function(response){
				changeTicketStatus (tickets[0].tckt,tickets[0].cmnt,$scope).then(function(){
					transferTicket(tickets[0].tckt,tickets[0].cmnt,$scope).then(function(response){
					obj++
					//console.log(obj)
					if(obj == arrayForTrackingVerifiedOrder[0].order.length){
						$scope.loading = false
						//$scope.getcancelrequest()
						deferred.resolve(true);
						
					}
					else if(obj < arrayForTrackingVerifiedOrder[0].order.length){
						iterateover(obj)
						
					}
					
					},function(response){
						console.log("error while ticket transfer")
						deferred.reject(false);
					})

				},function(){
					console.log("error while changing ticket status to Resolved")
					deferred.reject(false);
				})
				
			},function(response){
				console.log("error while order cancellation")
				deferred.reject(false);
			})
		}
		
		iterateover(obj,$scope)
		
		return deferred.promise;
	}
	
	
	function cancelOrder(oneorder,$scope){
		var deferred = $q.defer();
		var data = {}
		data.order = []
		data.order.push(oneorder) 
		//console.log(data)
		//var path = magento_ConstantApi.admininitiatecancelurlpath;
		var path = "admininitiatecancelurlpath";
		authenticationSvc.login('POST',magento_ConstantApi.Apiendpoint,path,data)
			.then(function(response){
				//$scope.loading = false
				//console.log(response.data[0])
				if(response.data[0][0].orderdetails.status && response.data[0][0].orderdetails.status =="error"){
					$scope.admincancelerrormsg = response.data[0][0].orderdetails.message.message;
					var popupdata = response.data[0][0].orderdetails.message.message
					//$scope.popupopen('generalpopup',popupdata,$scope)
					deferred.reject(false);
				}
				
				console.log("order approved or cancelled successfully ")
				//var popupdata = "Orders Cancellation Successfully Approved Or Rejected"
				//$scope.popupopen('generalpopup',popupdata,$scope)
				//$scope.ticketTransfer('assign',$scope)
				//$scope.getcancelrequest()
				deferred.resolve(true);
				
			},
			function(response){
				deferred.reject(false);
				//$scope.loading = false
				console.log("Error response received  while Appoving or rejecting orders in admin panel")
				// console.log(response)
				// var msg = errorcodesrv.checkcode(response.status)
				// if (msg !== "")
					// var popupdata = msg
				// else
					// var popupdata = 'Error Response Received  While Getting Ticket Details From Server'
				// $scope.popupopen('generalpopup',popupdata,$scope)
				
			})
		return deferred.promise;
	}
	
	function transferTicket(ticket,cmnt,$scope){
		
		console.log("called")
		var data ={};

		data = {
			"luser": userInfosvc.returnUserInfo()[0].username,
			"lpasswd": userInfosvc.returnUserInfo()[0].pass,
			"ticket_id": ticket.ticket_id,
			"update_type": "AssigntoStaff",
			"message": cmnt,
			"assignto": ticket.event_info[ticket.event_info.length-2].staff_id
		}

		//data.update_type = "AssigntoStaff";
		//data.assignto = ticket.event_info[ticket.event_info.length-2].staff_id;
		//data.message = cmnt;

		var deferred = $q.defer();
		//console.log($scope.ticketToTransferOrAssign)	
		//var count = 0
		//var path = OSTicket_ConstantApi.updateticketurlpath;
		//var header = OSTicket_ConstantApi.Header
		//for(var i=0; i< $scope.ticketToTransferOrAssign.length;i++){
			
		//data.luser = userInfosvc.returnUserInfo()[0].username;
		//data.lpasswd = userInfosvc.returnUserInfo()[0].pass;
		//data.ticket_id = ticket.ticket_id
		//console.log(data)
			//var count = 0
		//authenticationSvc.login('POST',OSTicket_ConstantApi.Apiendpoint,path,data,header)

		var path = Leykart_DatabaseConstant.osticketurl;
		//authenticationSvc.login('POST',OSTicket_ConstantApi.Apiendpoint,path,data,header)
		fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint,path, 'updateticketAssign', data)
			.then(function(response){
				if(response.data == 'true'){
					//console.log(response)
					console.log("Ticket Transfered Successfully ")
					//$scope.loading = false
					//count++;
					//$scope.ticketdetails = objct.remainingticket
					// console.log("Ticket assigned  or transfered successfully ")
					// if(calltype === "assign")
						// var popupdata = "Ticket Assigned Successfully "
					// else if(calltype === "transfer")
						// var popupdata = "Ticket Transfered Successfully "
					// $scope.popupopen('generalpopup',popupdata,$scope)
					//$scope.loading = false
					// here we need to update our local data base also by changing the raised by
					//if(count == $scope.ticketToTransferOrAssign.length)
					deferred.resolve(true);
					//$scope.loading = false
				}
			},
			function(response){
				//$scope.ticketdetails = objct.remainingticket
				//$scope.loading = false
				console.log("Error response received  while Assigning ticket  ")
				console.log(response)
				//var popupdata = response.statusText
				//$scope.popupopen('generalpopup',popupdata,$scope)
				deferred.reject(false);
		})
		
		//console.log(count)
		
		return deferred.promise;
	}

	// Start   this function is called when submit button of ticket popup is clicked  
	function changeTicketStatus (ticket,cmnt,$scope){
		//console.log(ticket)
		var deferred = $q.defer();
		var data = {}
		//$scope.loading = true
		//console.log("ticketResolved")
		data = {
			"luser": userInfosvc.returnUserInfo()[0].username,
			"lpasswd": userInfosvc.returnUserInfo()[0].pass,
			"ticket_id": ticket.ticket_id,
			"update_type": "Reply",
			"message": cmnt,
			//"status": "resolved",
			"status":"in-progress"
		}
		
		//var path = OSTicket_ConstantApi.updateticketurlpath ;
		//$scope.$broadcast('ticketsubmitEvent', {obj: 'please close the popup event!'}) // send whatever you want
		//$scope.popupclose()
		//$scope.popupclose()
		//console.log(data)
		//authenticationSvc.login('POST',OSTicket_ConstantApi.Apiendpoint, path, data, OSTicket_ConstantApi.Header)

		var path = Leykart_DatabaseConstant.osticketurl;
		//authenticationSvc.login('POST',OSTicket_ConstantApi.Apiendpoint, path, data, OSTicket_ConstantApi.Header)
		fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint,path, 'updateticketReply', data)
		.then(function(response){
			//console.log(response)
			if(response.status == 201)
				console.log("succesfully replied or noted for the ticket")
			//$scope.loading = false
			deferred.resolve(true);
			//$scope.ticketGo();
			//var popupdata = "Ticket Updated Successfully"
			//$scope.popupopen('generalpopup',popupdata,$scope)
		},function(response){
			console.log("Error response received  from os ticket while updating ticket  ")
			//console.log(response)
			var msg = errorcodesrv.checkcode(response.status)
			if (msg !== "")
				var popupdata = msg
			else
				var popupdata = "Error response received  from os ticket while updating ticket "
			$scope.popupopen('generalpopup',popupdata,$scope)
			deferred.resolve(false);
			// firing an event downwards ie to close model by calling popupcntrl  watch function
			//$scope.$broadcast('ticketsubmitEvent', {obj: 'please close the popup event!'})   // send whatever you want
			//$scope.loading = false
		})

		return deferred.promise;
		
	} // end of ticketSubmit for popup ticket
	
	return{
		calledfromCntrlfunc : calledfromCntrlfunc,
		cancelOrder : cancelOrder,
		transferTicket : transferTicket
	}
}])
