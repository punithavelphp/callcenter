var app = angular.module("LeyKartCallCentreApp", ['ui.router', 'ngAnimate', 'ngSanitize', 'ui.bootstrap', 'ngStorage',
    'angularUtils.directives.dirPagination'
]);

app.constant('Json_API', {
    Apiendpoint: 'data/callcentrejsondata.json'
})

app.constant('OSTicket_ConstantApi', {
    //Apiendpoint: 'http://35.194.228.9',
	//Apiendpoint: 'http://os-ticket-qa-leykart-api.leykart.com',
	//Apiendpoint: 'https://os-ticket-qa-leykart-api.leykart.com',
    //Apiendpoint: 'https://osticketapps.leykart.com',    // prod url
    //fetchdatabase.leykartDatabase('POST', Leykart_DatabaseConstant.Apiendpoint,path, 'login', data)
    //authenticationurlpath: '/api/http.php/authenticate.json',
    //createticketurlpath: '/api/http.php/tickets.json',
    //viewticketurlpath: '/api/http.php/viewticket.json',
    //assignticketurlpath: '/api/http.php/updateticket.json',
    //l1agenturlpath: '/api/http.php/masterdata.json',
    //updateticketurlpath: '/api/http.php/updateticket.json',
   // Header: {
		//'X-API-Key': 'BB37E8DBF3A6B898444EDD1F5BFD1708'     // prod api key for ip 107.167.178.228
        //'X-API-Key': '23F7982050EC7A016C86413B68489440'
    //}, // for local machine
    //Header : {'X-API-Key' : '5B43D003131DDAB2AFD63E7B43C3808E'}  // for server
    // 'Content-Type': 'application/json',
})

app.constant('OSTicket_IpForTicketCreation', {
    //ip: "125.22.193.148"
})

app.constant('magento_ConstantApi', {
    Headers: {
        //'Content-Type': 'text/plain',
		'Content-Type': 'application/json',
    },
    //Apiendpoint: 'https://104.199.242.16',    // dev server
    //Apiendpoint: 'https://107.167.178.228', // QA server
	//Apiendpoint: 'https://shopqa.leykart.com',
	//Apiendpoint: 'https://shop.leykart.com',  // prod server
    // orderdetailurlpath: '/rest/V1/CcmOrder/ccorderdetails/', //get    12
    // verifyneworderurlpath: '/rest/V1/CcmOrder/ccverifyneworder', //get   yes/no
    // viewallorderurlpath: '/rest/V1/CcmOrder/ccviewallorder', //post
    // verifyupdateneworderurlpath: '/rest/V1/CcmOrder/cc_update_verify_neworder', //post
    // getcancelreasonurlpath: '/rest/V1/cancelreason/getreason',
    // getcurntpastorderurlpath: '/rest/V1/CcmOrder/cc_orders',
    // getnewuserlisturlpath: '/rest/V1/CcmOrder/cc_list_newuser/',
    // updateverifyurlpath: '/rest/V1/CcmOrder/cc_update_verifyuser',
    // getpartcatalougeurlpath: '/rest/V1/partscatalog/partdetails/',
    // getcancelrequesturlpath: '/rest/V1/CcmOrder/ccverifyneworder',
    // initiatecancelurlpath: '/rest/V1/initiatecancel/initiate',
    // admininitiatecancelurlpath: '/rest/V1/initiatecancel/admininitiate',
	// pastorderurlpath : '/rest/V1/CcmOrder/cc_past_orders'

})

app.constant('Leykart_DatabaseConstant', {
    Apiendpoint: '',              // change the dbconfig file also /Ley  https://callcenterqa.leykart.com/ also in upload.php
    urlpath: '/php/uiToDb.php',
    osticketurl: '/php/intermediate.php',
    //osticketurl: '/s.php'

})

app.constant('DeliveryProvider', {
    Apiendpoint: '',
    //urlpath: 'https://www.google.co.in/',
	//urlpath: 'https://track.delhivery.com/accounts/login/?next=/',
	//urlpath: 'https://track.delhivery.com/p/list/1'
    urlpath:    'https://www.delhivery.com/track/package/'

})


app.constant('ProconnectPath', {
    Apiendpoint: '',
    urlpath:    'https://erp.proconnect.in/leykart/Default.aspx'

})

app.constant('AUTH_EVENTS', {
    loginSuccess: 'auth-login-success',
    loginFailed: 'auth-login-failed',
    logoutSuccess: 'auth-logout-success',
    sessionTimeout: 'auth-session-timeout',
    notAuthenticated: 'auth-not-authenticated',
    notAuthorized: 'auth-not-authorized'
})

app.constant('Database_fields', {
    serverApi: 'localhost',
    loginUsername: 'test2',
    loginPassword: 'test2',
    loginDatabase: 'leykartt'

})

app.constant('USER_ROLES', {
    all: '*',
    admin: "Leykart_Admin",
    agent: "Agent"
})

app.run(function($rootScope, AUTH_EVENTS, authenticationSvc, $localStorage, $sessionStorage, userInfosvc, $location,$state) {

    $rootScope.$on('$stateChangeStart', function(event, next) {
		if(next.name === "login")
			return
		//console.log(next)
        if (next.data.authorizedRoles != undefined)
            var authorizedRoles = next.data.authorizedRoles;
        //console.log("inside stateChangeStart")

        //setting name and role of user from $localStorage if user is not logged out
        if ((userInfosvc.userInfo[0].staff_id == null) && ($sessionStorage.userInfo != null)) {
            //console.log($sessionStorage.userInfo[0].username)
            //console.log($sessionStorage.userInfo[0].role)
            userInfosvc.setUserInfo($sessionStorage.userInfo[0])
            userInfosvc.setpass($sessionStorage.somevalue)
                //$sessionStorage.userInfo = $localStorage.userInfo
        }

        // checking the authorization of the user
        if (!authenticationSvc.isAuthorized(authorizedRoles)) {
            console.log("Please login to continue")
            event.preventDefault();
            $state.go("login")
            if (authenticationSvc.isAuthenticated()) {
                // user is not allowed
                $rootScope.$broadcast(AUTH_EVENTS.notAuthorized);
            } else {
                // user is not logged in
                $rootScope.$broadcast(AUTH_EVENTS.notAuthenticated);
            }
        }
    });

    // for preventing the user to go to login page if back button or url changes to login after successfully logged in 
    $rootScope.$on('$locationChangeStart', function(event, next, current) {
        // console.log("in run  " +next.split("/")[5])
        // if((userInfosvc.userInfo[0].nameOfUser == null) && (next.split("#").indexOf("/login") != -1)){
        // $rootScope.navShowValue = false
        // console.log("hr")
        // }
        if ((userInfosvc.userInfo[0].nameOfUser != null) && (next.split("#").indexOf("/login") != -1))
            event.preventDefault();


    });

    $rootScope.$on('$locationChangeSuccess', function() {
        //console.log("in run  " + $location.url().split("/")[1])

    });
})

app.config(function($httpProvider, $stateProvider, $urlRouterProvider, $locationProvider, USER_ROLES,$compileProvider) {

	 // $httpProvider.defaults.useXDomain = true;
	//delete $httpProvider.defaults.headers.common['X-Requested-With'];
	// ~$httpProvider.defaults.headers.post[' *﻿/﻿*'];
	
	// // to disable right click
	// $(document).bind("contextmenu",function(e) {
	 // e.preventDefault();
	// });
	// // to disable F12 button
	// $(document).keydown(function(e){
		// if(e.which === 123){
		   // return false;
		// }
	// });
	
	// // to disable console 
	// var DEBUG = false;
	// if(!DEBUG){
		// if(!window.console) window.console = {};
		// var methods = ["log", "debug", "warn", "info"];
		// for(var i=0;i<methods.length;i++){
			// console[methods[i]] = function(){};
		// }
	// }
	
	// //$compileProvider.debugInfoEnabled(false);
	// //window['console']['log'] = function() {};
	// window['network'] = function() {};
	// $httpProvider.defaults.headers.common = {};
	// $httpProvider.defaults.headers.post = {};
	// $httpProvider.defaults.headers.put = {};
	// $httpProvider.defaults.headers.patch = {};
  
	// $http.defaults.headers.post["Content-Type"] = "text/plain";
    $locationProvider.hashPrefix('');

    $httpProvider.interceptors.push(['$injector', function($injector) {
        return $injector.get('AuthInterceptor');
    }]);

    $stateProvider
        .state("login", {
            url: "/login",
            cache: false,
            templateUrl: "templates/login.html",
            controller: "signincntrl"
        })
        .state("home", {
            url: "/home",
            cache: false,
            templateUrl: "templates/home.html",
            controller: "homecntrl",
            data: {
                authorizedRoles: []
            }
        })
        .state("createnewticket", {
            url: "/createnewticket",
            cache: false,
            templateUrl: "templates/createnewticket.html",
            controller: "createnewticketcntrl",
            data: {
                authorizedRoles: [USER_ROLES.agent]
            }
        })

    .state("viewticket", {
        url: "/viewticket",
        cache: false,
        templateUrl: "templates/viewticket.html",
        controller: "viewticketcntrl",
        data: {
            authorizedRoles: [USER_ROLES.agent]
        }
    })

    .state("viewclosedticket", {
        url: "/viewclosedticket",
        cache: false,
        templateUrl: "templates/viewclosedticket.html",
        controller: "viewclosedticketcntrl",
        data: {
            authorizedRoles: [USER_ROLES.agent]
        }
    })

    .state("viewallorder", {

        url: "/viewallorder",
        cache: false,

        views: {
            '': {
                templateUrl: "templates/viewallorder.html",
                controller: "viewallordercntrl"
            },
            // 'datepick@viewallorder' : {
            // template : '<h1>Date</h1>',
            // //templateUrl : "templates/datepicker.html",
            // controller:"datepickercntrl"
            // }         
        },
        data: {
            authorizedRoles: [USER_ROLES.agent]
        }
    })


    .state("verifyneworder", {

        url: "/verifyneworder",
        cache: false,
        templateUrl: "templates/verifyneworder.html",
        controller: "verifynewordercntrl",
        data: {
            authorizedRoles: [USER_ROLES.agent]
        }
    })

    .state("listnewusers", {
            url: "/listnewusers",
            cache: false,
            templateUrl: "templates/listnewusers.html",
            controller: "listnewuserscntrl",
            data: {
                authorizedRoles: [USER_ROLES.agent]
            }
        })
        .state("getfeedback", {
            url: "/getfeedback",
            views: {
                '@': {
                    templateUrl: "templates/getfeedback.html",
                    controller: "getfeedbackcntrl"
                }
            },
            cache: false,
            data: {
                authorizedRoles: [USER_ROLES.agent]
            }
        })
        .state("getfeedback.regfeedback", {
            url: "/regfeedback",
            views: {
                'regularfeedback@getfeedback': {
                    templateUrl: "templates/regfeedback.html",
                    controller: "regularfeedbackcntrl"
                }
            },
            cache: false
        })
        .state("getfeedback.cancelfeedback", {
            url: "/cancelfeedback",
            views: {
                'cancelfeedback@getfeedback': {
                    templateUrl: "templates/feedbackforcancelation.html",
                    controller: "cancelfeedbackcntrl"
                }
            },
            cache: false
        })

    .state("admin", {
        url: "/admin",
        cache: false,
        templateUrl: "templates/admin.html",
        controller: "adminscreencntrl",
        data: {
            authorizedRoles: [USER_ROLES.admin]
        }
    })

    .state("admin.viewtickets", {
        url: "/viewtickets",
        views: {
            'view@admin': {
                templateUrl: "templates/adminviewticket.html",
                controller: "adminviewticketcntrl"
            }
        },
        cache: false
    })

    .state("admin.viewcancelrequest", {
        url: "/viewcancelrequest",
        views: {
            'view@admin': {
                templateUrl: "templates/adminviewcancelrequest.html",
                controller: "adminviewcancelrequestcntrl"
            }
        },
        cache: false
    })

    .state("admin.uploadmanual", {
        url: "/uploadmanual",
        views: {
            'view@admin': {
                templateUrl: "templates/adminuploadmanual.html",
                controller: "adminuploadmanualcntrl"
            }
        },
        cache: false
    })
	
	.state("admin.dwnldfeedback", {
        url: "/feedbackdwnld",
        views: {
            'view@admin': {
                templateUrl: "templates/admindwnldfeedback.html",
                controller: "admindwnldfeedbackcntrl"
            }
        },
        cache: false
    })

    .state("partscatalouge", {
            url: "/partscatalouge",
            cache: false,
            templateUrl: "templates/partscatalouge.html",
            controller: "partscatalougecntrl",
            data: {
                authorizedRoles: [USER_ROLES.agent]
            }
        })
        .state("instructionmanual", {
            url: "/instructionmanual",
            cache: false,
            templateUrl: "templates/instructionmanual.html",
            controller: "instructionmanualcntrl",
            data: {
                authorizedRoles: [USER_ROLES.agent]
            }
        })
        .state("viewpocdetail", {
            url: "/viewpocdetail",
            cache: false,
            templateUrl: "templates/viewpocdetail.html",
            controller: "viewpocdetailcntrl",
            data: {
                authorizedRoles: [USER_ROLES.agent]
            }
        })
        .state("orderdetails", {
            url: "/orderdetails",
            cache: false,
            templateUrl: "templates/orderdetails.html",
            controller: "orderdetailscntrl",
            data: {
                authorizedRoles: [USER_ROLES.agent]
            }
        })

    // .state("home.error", {
    // url:"/home/error",
    // views:{
    // "mycontentarea":{                                     
    // templateUrl : "pages/404.html",
    // }
    // }           
    // })




    $urlRouterProvider.otherwise('/login');
});


app.filter('myDateFilter', ['$filter', function($filter) {
    return function(date, format) {
        var convertedDate = new Date(date);
		//console.log($filter('date')(convertedDate,format))
        return $filter('date')(convertedDate,format) == 'Invalid Date' ? ' ' : $filter('date')(convertedDate,format);
    }

}])

app.filter('myStatusFilter', ['$filter', function($filter) {
    return function(data, format) {
        //var convertedDate = new Date(date);
		//console.log($filter('date')(convertedDate,format))
		var statu = data.toLowerCase()
		if( statu !== 'delivered' || statu !== 'refunded' || statu !== 'cancelled')
			return true
		else
			return false
		
        //return $filter('date')(convertedDate,format) == 'Invalid Date' ? ' ' : $filter('date')(convertedDate,format);
    }

}])
app.filter('filterbyorderidorticketno',['$filter',function($filter){
    return function(dataArray,filterText){
        //console.log('Filter text is :'+filterText);
         if (!dataArray) {
          return;
      }
      // If no search term exists, return the array unfiltered.
      else if (!filterText) {
          return dataArray;
      }
    else{
        var term=filterText.toLowerCase();
        var result=[];
        angular.forEach(dataArray,function(item){
            var inOrderId=item.self_added_orderno.toLowerCase().indexOf(term);
            var inTicketNo=item.ticket_number.toLowerCase().indexOf(term);
            if(inOrderId!=-1||inTicketNo!=-1){
                result.push(item);
            }
        })
        if(result.length>0){
        return result;
        }
        return dataArray;
        /*return dataArray.filter(function(item){
            var inOrderId=item.self_added_orderno.toLowerCase().indexOf(term);
            var inTicketNo=item.ticket_number.toLowerCase().indexOf(term);
            return inOrderId||inTicketNo;
        })*/
    }
    }
    
}])
app.filter('tickettypefilter', ['$filter', function($filter) {
    return function(data, tickettype) {
        //var convertedDate = new Date(date);
		//console.log(tickettype)
		var result =[]
		if(tickettype){
			angular.forEach(data, function(item) {
				//console.log(item.status.toLowerCase())
				 if(item.status.toLowerCase() == tickettype.toLowerCase())
					 result.push(item)
			});
			return result
		}
		else{
			return data
		}
		// var statu = data.toLowerCase()
		// if( statu !== 'delivered' || statu !== 'refunded' || statu !== 'cancelled')
			// return true
		// else
			// return false
		
        //return $filter('date')(convertedDate,format) == 'Invalid Date' ? ' ' : $filter('date')(convertedDate,format);
    }

}])

app.filter('removeorderno', ['$filter', function($filter) {
    return function(subject) {
        //var convertedDate = new Date(date);
        return subject.split("#")[0];
    }

}])


app.directive('loginDialog', function(AUTH_EVENTS) {
    return {
        restrict: 'A',
        template: '<div ng-if="visible" ng-include="templates/login.html">',
        link: function(scope) {
            var showDialog = function() {
                scope.visible = true;
            };

            scope.visible = false;
            scope.$on(AUTH_EVENTS.notAuthenticated, showDialog);
            //scope.$on(AUTH_EVENTS.sessionTimeout, showDialog)
        }
    };
})

app.directive('leftform', function() {
    return {
        restrict: 'EA',
        transclude: 'true',
        templateUrl: 'templates/leftform.html'
    }
})

app.directive('rightform', function() {
    return {
        restrict: 'EA',
        transclude: 'true',
        templateUrl: 'templates/rightform.html'
    }
})

app.directive('sidemenu', function() {
    return {
        restrict: 'EA',
        transclude: 'true',
        templateUrl: 'templates/sidebar.html'
    }
})

app.directive('customerdetail', function() {
    return {
        restrict: 'EA',
        transclude: 'true',
        templateUrl: 'templates/customerdetail.html'
    }
})

app.directive('tabledispaly', function() {
    return {
        restrict: 'EA',
        transclude: 'true',
        templateUrl: 'templates/tabledisplay.html',
        controller: "TableCtrl"
    }
})


app.directive('datepicker', function() {
    return {
        restrict: 'EA',
        transclude: 'true',
        // scope: true,
        templateUrl: 'templates/datepicker.html',
        controller: "datepickercntrl"
    }
})

app.directive('datepickerf', function() {
    return {
        restrict: 'EA',
        transclude: 'true',
        // scope: true,
        templateUrl: 'templates/datepickerfeedback.html',
        controller: "datepickercntrl"
    }
})

app.directive('fileexport', function() {
    return {
        restrict: 'EA',
        transclude: 'true',
        templateUrl: 'templates/fileexport.html'
            //            controller:"fileexport"
    }
})

app.directive('dirResource', function() {
    return {
        restrict: 'EA',
        transclude: 'true',
        templateUrl: 'templates/resource.html'
            //            controller:"fileexport"
    }
})

app.directive("restrictedLimitTo", [function() {
    return {
        require:'ngModel',
        restrict: "A",
        scope: {
            //limit: '@limit',
            type: '@typ'
        },
        link: function(scope, elem, attrs,ngModelCtrl) {
            var limit = parseInt(attrs.restrictedLimitTo);
            //var type = attrs.typ;
            //console.log(scope.type)
            if(scope.type)
                var re = new RegExp(scope.type);
            //console.log(elem);
            var reqElement=document.getElementById(elem[0].id);
            elem.on("keyup", function(e) {
                /*console.log(e.key+' : '+e.keyCode);*/
                var reqElement=document.getElementById(elem[0].id);
                //console.log(e)
                //console.log(this.value)
                console.log(ngModelCtrl);
                this.value=this.value.toString();
                if(this.value.length == 0)
                    var first=true;
                else
                    var first= false;
                //console.log("keypress"  re.test(this.value.toString())+"  "+this.value.length)
                //console.log(this.value)
                if (!first && (this.value.length < limit)) {
                    //first=false
                    if(e.keyCode==220||e.keyCode==221||e.keyCode==222||e.keyCode==191||e.keyCode==192||e.keyCode==49||e.keyCode==50||e.keyCode==51||e.keyCode==52||e.keyCode==53||e.keyCode==54||e.keyCode==55||e.keyCode==56||e.keyCode==57||e.keyCode==48||e.keyCode==189||e.keyCode==187||e.keyCode==219||e.keyCode==221||e.keyCode==186){
                    e.preventDefault();
                    //console.log(this.value.substring(0,this.value.length-1))
                    this.value = this.value.substring(0,this.value.length-1)
                    }
                }
                else if (!first && (this.value.length >= limit)) {
                    //first=false
                    var ctrlDown = false;
                    var ctrlKey = 17;
                    var vKey = 86;
                    var cKey = 67;
                    if (e.keyCode == ctrlKey) ctrlDown = true;
                    if ((ctrlDown && (e.keyCode != vKey || e.keyCode != cKey || e.keyCode!=65))||e.keyCode!=8){
                    e.preventDefault();
                    //console.log(this.value.substring(0,this.value.length-1))
                    while(this.value.length>limit){
                        if(this.value.length-1>=limit)
                            this.value = this.value.substring(0,this.value.length-1)
                        }
                    }
                }
                else{
                    //console.log(re)
                    //console.log(/^\d{1,10}$/.test(this.value))
                }
            });
        }
    }
}])

app.directive("limitTo", [function() {
    return {
        restrict: "A",
        scope: {
            //limit: '@limit',
            type: '@typ'
        },
        link: function(scope, elem, attrs) {
            var limit = parseInt(attrs.limitTo);
            //var type = attrs.typ;
            //console.log(scope.type)
            if(scope.type)
                var re = new RegExp(scope.type);
            var ctrlDown = false;
                var shiftDown=false;
                var ctrlKey = 17;
                var vKey = 86;
                var cKey = 67;
            angular.element(elem).on("keydown", function(e) {
                if (e.keyCode == ctrlKey) ctrlDown = true;
                else if(e.keyCode==16) shiftDown=true;
            })
            angular.element(elem).on("keyup", function(e) {
                //console.log(e)
                //console.log(this.value)
                if(e.keyCode==16){
                    shiftDown=false;
                }
                var reqElement=document.getElementById(elem[0].id);
                //this.value=this.value.toString();
                if(this.value.length == 0)
                    var first=true;
                else
                    var first= false;
                //console.log("keypress"  re.test(this.value.toString())+"  "+this.value.length)
                //console.log(this.value)
                if(first){
                    if(!shiftDown && e.keyCode >= 48 && e.keyCode <= 57){
                        return
                    }
                    else{
                        e.preventDefault();
                        shiftDown=false;
                        //console.log(this.value.substring(0,this.value.length-1))
                        this.value = this.value.substring(0,this.value.length-1)
                    }
                }
                else if (!first && (this.value.length < limit)) {
                    if((!shiftDown&&event.keyCode >= 48 && event.keyCode <= 57)||e.keyCode==8||e.keyCode==16||e.keyCode==17||e.keyCode==18||(ctrlDown && (e.keyCode != vKey || e.keyCode != cKey || e.keyCode!=65))){
                        return
                    }
                    else if(e.keyCode==190||e.keyCode==187||e.keyCode==189||e.keyCode==220||e.keyCode==221||e.keyCode==222||e.keyCode==191||e.keyCode==192||e.keyCode==49||e.keyCode==50||e.keyCode==51||e.keyCode==52||e.keyCode==53||e.keyCode==54||e.keyCode==55||e.keyCode==56||e.keyCode==57||e.keyCode==48||e.keyCode==189||e.keyCode==187||e.keyCode==219||e.keyCode==221||e.keyCode==186){
                        e.preventDefault();
                        shiftDown=false;
                        //console.log(this.value.substring(0,this.value.length-1))
                        this.value = this.value.substring(0,this.value.length-1)
                    }
                    else{
                        e.preventDefault();
                        //console.log(this.value.substring(0,this.value.length-1))
                        shiftDown=false;
                        this.value = this.value.substring(0,this.value.length-1)
                    }
                }
                else if (!first && (this.value.length >= limit)) {
                    //first=false
                    if ((ctrlDown && (e.keyCode != vKey || e.keyCode != cKey || e.keyCode!=65))||e.keyCode!=8||e.keyCode==16||e.keyCode==17||e.keyCode==18){
                    e.preventDefault();
                    //console.log(this.value.substring(0,this.value.length-1))
                    while(this.value.length>limit){
                        if(this.value.length-1>=limit)
                            this.value = this.value.substring(0,this.value.length-1)
                        }
                    }
                }
                else{
                    //console.log(re)
                    //console.log(/^\d{1,10}$/.test(this.value))
                }
            });
        }
    }
}])

app.directive('exportToCsv',function(){
  	return {
    	restrict: 'A',
    	link: function (scope, element, attrs) {
    		var el = element[0];
	        element.bind('click', function(e){
	        	var table = e.target.nextElementSibling;
	        	var csvString = '';
	        	for(var i=0; i<table.rows.length;i++){
	        		var rowData = table.rows[i].cells;
	        		for(var j=0; j<rowData.length;j++){
	        			csvString = csvString + rowData[j].innerHTML + ",";
	        		}
	        		csvString = csvString.substring(0,csvString.length - 1);
	        		csvString = csvString + "\n";
			    }
	         	csvString = csvString.substring(0, csvString.length - 1);
	         	var a = $('<a/>', {
		            style:'display:none',
		            href:'data:application/octet-stream;base64,'+btoa(csvString),
		            download:'emailStatistics.csv'
		        }).appendTo('body')
		        a[0].click()
		        a.remove();
	        });
    	}
  	}
})

app.directive('starRating', function() {
        return {
            restrict: 'EA',
            template: '<ul class="star-rating" ng-class="{readonly: readonly}">' +
                '  <li ng-repeat="star in stars" class="star" ng-class="{filled: star.filled}" ng-click="toggle($index)">' +
                '    <i class="fa fa-star" ng-click="setFeedback(question.qid,options.optno,true,rating1)"></i>' + // or &#9733
                '  </li>' +
                '</ul>',
            scope: {
                ratingValue: '=ngModel',
                max: '=?', // optional (default is 5)
                onRatingSelect: '&?',
                readonly: '=?'
            },
            link: function(scope, element, attributes) {
                if (scope.max == undefined) {
                    scope.max = 5;
                }

                function updateStars() {
                    scope.stars = [];
                    for (var i = 0; i < scope.max; i++) {
                        scope.stars.push({
                            filled: i < scope.ratingValue
                        });
                    }
                };
                scope.toggle = function(index) {
                    if (scope.readonly == undefined || scope.readonly === false) {
                        scope.ratingValue = index + 1;
                        /*scope.onRatingSelect({
              rating: index + 1
            });*/
                    }
                };
                scope.$watch('ratingValue', function(oldValue, newValue) {
                    if (newValue || newValue === 0) {
                        updateStars();
                    }
                });
            }
        };
    });

app.directive('fileModel', ['$parse', function($parse) {
    // return {
    // restrict: 'A',
    // link: function($scope, element, attrs) {
    // //var model = $parse(attrs.fileModel);
    // //var modelSetter = model.assign;

    // element.on('change', function(event){
    // // scope.$apply(function(){
    // // modelSetter(scope, element[0].files[0]);
    // // });
    // var files = event.target.files
    // console.log(files)
    // $parse(attrs.fileModel).assign($scope,element[0].files)
    // $scope.$apply()
    // });
    // }
    // };

    return {
        restrict: 'A',
        link: function(scope, element, attrs) {
            var model = $parse(attrs.fileModel);
            var modelSetter = model.assign;

            element.bind('change', function() {
                scope.$apply(function() {
                    modelSetter(scope, element[0].files);
                });
            });
        }
    };
}]);

function searchUtil(item, toSearch) {
    /* Search Text in all 3 fields */
    return (item.name.toLowerCase().indexOf(toSearch.toLowerCase()) > -1 || item.Email.toLowerCase().indexOf(toSearch.toLowerCase()) > -1 || item.EmpId == toSearch) ? true : false;
}
