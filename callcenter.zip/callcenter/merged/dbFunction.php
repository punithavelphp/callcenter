<?php  
require_once 'dbConnect.php';  
session_start();  
    class dbFunction {  
        //echo "hello"; 
        private $db;		
        function __construct() {  
              
            // connecting to database  
            $this->db = new dbConnect();
            //print_r($this->db->conn);			
               
        }  
        // destructor  
        function __destruct() {  
              
        }  
        // public function UserRegister($username, $emailid, $password){  
                // $password = md5($password);  
                // $qr = mysql_query("INSERT INTO users(username, emailid, password) values('".$username."','".$emailid."','".$password."')") or die(mysql_error());  
                // return $qr;  
               
        // }

	    public function createArray($res){
			$output = array();
			if(mysqli_num_rows($res) > 0){	   
					while($row= mysqli_fetch_assoc($res)){
						$output[]=$row;
					}
					//$jsonoutput = json_encode($output);
				
	            // $_SESSION['login'] = true;  
                // $_SESSION['uid'] = $user_data['id'];  
                // $_SESSION['username'] = $user_data['username'];  
                // $_SESSION['email'] = $user_data['emailid'];  
                //return TRUE;
                return  $output ;				
                				
            }  
            else  
            {  
                return $res;  
            } 
		}
        public function Login($username,$password){  
            //$res = mysql_query("SELECT * FROM users WHERE emailid = '".$emailid."' AND password = '".md5($password)."'"); 
            
			//$connect = mysqli_connect("localhost","test2","test2","leykart") or die("unable to connect DB");
			//print_r($connect);
			$query="SELECT r.name,r.notes,s.firstname FROM ostk_role r INNER JOIN ostk_staff s ON s.role_id = r.id  where s.username='".$username."'";
            $res = mysqli_query($this->db->getConnection(),$query);
			//print_r($res);
            //$user_data = mysqli_fetch_array($res);  
            //print_r($user_data);  
            //$no_rows = mysqli_num_rows($res);  
            
            return  $this->createArray($res);		
             
               
                   
        }
        
        public function viewFeedback(){
            $query="SELECT * FROM ostk_feedback_response";
            $res=mysqli_query($this->db->getConnection(),$query);
            $res=$this->createArray($res);
            print_r($res[0]);
            foreach($res->$key as $val->$key)
            $csvfile = fopen('feedback.csv', 'w+');
            /*$res=json_encode($res);
            $res=json_decode($res);
            $header=array();
            $csvfile = fopen('feedback.csv', 'w+');
            foreach ($res as $row) {
                $line = "" . join("\",\"", $row) . "\"\n";
                fputs($csvfile, $line);
            }
            fclose($csvfile);*/
        }


        public function caller(){  
			$query="SELECT * FROM idostk_caller_type";
            $res =mysqli_query($this->db->getConnection(),$query);   
            return  $this->createArray($res) ;         
        }
		
		public function issuetype(){  
			$query="SELECT * FROM ostk_issue_category";
            $res =mysqli_query($this->db->getConnection(),$query);   
            return  $this->createArray($res) ;         
        }
		
		public function actionToBeTaken($callerId,$issue){ 
            //print_r($caller);	
            // $query="SELECT id FROM idostk_caller_type where caller_type='".$caller."'";
			// $res =mysqli_query($this->db->getConnection(),$query); 
			// $callerId = $this->createArray($res)[0]['id'] ;
			//print_r($callerId );	
			$query = "SELECT action FROM ostk_action_taken where caller_type='".$callerId."' and issue_category='".$issue."'";
            $res =mysqli_query($this->db->getConnection(),$query); 
			//print_r($res);
			//return ($res);
            return  $this->createArray($res);         
        }
		
		
		public function createTicket($ticketno,$ticketid,$status,$orderno,$createdBy,$createdAt,$lastatendedby,$lastatendeddate,$isuuecateg){ 
			$query ="INSERT INTO ostk_view_ticket (ticketNo,ticketid,ticketStatus,orderNo,raisedBy,raisedDate,lastAttendedBy,LastAttendedDate,issueCategoryId) VALUES ('".$ticketno."','".$ticketid."','".$status."','".$orderno."','".$createdBy."','".$createdAt."','".$lastatendedby."','".$lastatendeddate."','".$isuuecateg."')";
			//$query="SELECT id FROM idostk_caller_type where caller_type='".$caller."'";
			$res=mysqli_query($this->db->getConnection(),$query);  
            return($res);         
        }
        
        public function sendFeedback($orderNo,$feedback_type,$feedbackoptid){
            $values="";
            foreach($orderNo as $suborderid){
            foreach($feedbackoptid as $val){
                $values.="('".$suborderid."','".$feedback_type."','".$val->qid."','".$val->optid."'),";
            }
            }
            $values=rtrim($values,", \t\n");
            $query="INSERT INTO ostk_feedback_response(order_number,feedback_type,feedback_question_id,feedback_option_id) VALUES".$values."";
            $res=mysqli_query($this->db->getConnection(),$query);
            return($res);
        }
        
        public function getFeedbackQuestions($feedbackType){
            $query="SELECT serialNo,questions,question_type from ostk_feedback_question where feedback_type=(select type_id from ostk_feedback_type where feedback_type='".$feedbackType."')";
            $res=mysqli_query($this->db->getConnection(),$query);
            return  $this->createArray($res);   
        }
		
        public function checkOrderId($orderId){
            $query="SELECT feedback_response_id FROM ostk_feedback_response WHERE order_number='".$orderId."'";
            $res=mysqli_query($this->db->getConnection(),$query);
            return  $this->createArray($res);
        }
        
        public function getFeedbackOptions($qid){
            $arr=[];
            foreach($qid as $value){
            $query="SELECT ostk_feedback_question.serialNo qno, ostk_feedback_option.serialNo optno, options FROM ostk_feedback_option,ostk_feedback_question WHERE feedback_question_id='".$value->serialNo."' and ostk_feedback_question.serialNo=feedback_question_id";
                $res=mysqli_query($this->db->getConnection(),$query);
            array_push($arr,$this->createArray($res));
            }
            return  $arr;
        }
		public function viewticket($agentId,$daterange){
			// print_r($agentId );
			// print_r($daterange->from_date );
			// print_r($daterange->to_date );
			$datefrom = $daterange->from_date;
			$dateto =  $daterange->to_date;
			
			$query = "SELECT * FROM ostk_view_ticket where raisedBy='".$agentId."' and cast(raisedDate as date) >='".$datefrom."' and cast(raisedDate as date) <='".$dateto."'";
            //print_r($query);
			$res = mysqli_query($this->db->getConnection(),$query);  
			//print_r($res);
            return  $this->createArray($res) ;         
        }
		
		public function pocdeatil(){  
			$query="SELECT * FROM ostk_poc_detail";
            $res =mysqli_query($this->db->getConnection(),$query);   
            return  $this->createArray($res) ;         
        }
		
		// public function ticketandorderno($datas){
			// //print_r($datas);
			// if(sizeof($datas) > 0){
				// foreach ($datas as $data) {
					// //echo $data->ticket_number;
					// //echo $data->self_added_orderno;
					// $query ="INSERT INTO ticket_with_order (orderid,ticketno) VALUES ('".$data->self_added_orderno."','".$data->ticket_number."')";
					// $res = mysqli_query($this->db->getConnection(),$query);  
					// //print_r($res);
				// }
				// return($res) ;
			// }
			// else{
				// return "There Is No Ticket Details Present In Input";
			// }
        // }
		
		// public function orderdetails($datas){
			// //print_r($datas);
			// if(sizeof($datas) > 0){
				// foreach ($datas as $data) {
					// //echo $data->ticket_number;
					// //echo $data->self_added_orderno;
					// $query ="INSERT INTO order_detail (orderid,status) VALUES ('".$data->suborder_id."','".$data->verified_status."')";
					// $res = mysqli_query($this->db->getConnection(),$query);  
					// //print_r($res);
				// }
				// return($res) ;
			// }
			// else{
				// return "There Is No Orders Present In Input";
			// }
        // }
		
		// public function orderAndTicketNoJoinQuery(){
			// //print_r($datas);
			// $query="SELECT * FROM order_detail NATURAL JOIN ticket_with_order;";
            // $res =mysqli_query($this->db->getConnection(),$query);
			// $query="truncate table order_detail ;";
            // $res1 =mysqli_query($this->db->getConnection(),$query);
			// //print_r($res1);
			// $query="truncate table ticket_with_order ;";
            // $res2 =mysqli_query($this->db->getConnection(),$query);
			// //print_r($res2);
            // return  $this->createArray($res) ;
        // }
		
		public function uploadFilePath($data){
			//print_r($data);
			$query="SELECT * FROM upload_files where id='".$data->id."'";
            $res =mysqli_query($this->db->getConnection(),$query);
			//print_r($res);
			if($res->num_rows == 0){
				//print_r("  here");
				$path = 'uploadedData/'.$data->filepath;
				$query ="INSERT INTO upload_files (id,path) VALUES ('".$data->id."','".$path."')";
				$res = mysqli_query($this->db->getConnection(),$query);
			}
			else{
				//print_r("  here2");
				$path = 'uploadedData/'.$data->filepath;
				$query ="update upload_files set path = '".$path."' where id = '".$data->id."'";
				$res = mysqli_query($this->db->getConnection(),$query);
			}
            return ($res) ;
        }
		
		public function ViewFilePath($data){
			//print_r($data);
			$query="SELECT path FROM upload_files where id = '".$data->id."'";
            $res =mysqli_query($this->db->getConnection(),$query);
			//return $res;
            return $this->createArray($res) ;
        }
		
		// public function actionToBeTaken($caller,$issue){  
            // //$res = mysql_query("SELECT * FROM users WHERE emailid = '".$emailid."' AND password = '".md5($password)."'"); 
            
			// //$connect = mysqli_connect("localhost","test2","test2","leykart") or die("unable to connect DB");
			// //print_r($connect);
			// $query="SELECT action FROM ostk_action_taken where caller_type='".$caller."' and issue_category='".$issue."'";
            // $res = 	 mysqli_query($this->db->getConnection(),$query);
            // // $user_data = mysqli_fetch_array($res);  
            // // print_r($user_data);  
            // // $no_rows = mysqli_num_rows($res);  
              
            // if(mysqli_num_rows($res) > 0){	   
					// while($row= mysqli_fetch_array($res)){
						// $output[]=$row;
					// }
					// //echo json_encode($output);
				
	            // // $_SESSION['login'] = true;  
                // // $_SESSION['uid'] = $user_data['id'];  
                // // $_SESSION['username'] = $user_data['username'];  
                // // $_SESSION['email'] = $user_data['emailid'];  
                // //return TRUE;
                // return $output;				
                				
            // }  
            // else  
            // {  
                // return FALSE;  
            // }  
               
                   
        // }

		
        public function isUserExist($emailid){  
            $qr = mysql_query("SELECT * FROM users WHERE emailid = '".$emailid."'");  
            echo $row = mysql_num_rows($qr);  
            if($row > 0){  
                return true;  
            } else {  
                return false;  
            }  
        }  
    }  
?>