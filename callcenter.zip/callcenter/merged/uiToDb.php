<?php  
    include_once('dbFunction.php');  
       
    $funObj = new dbFunction(); 

	//$funObj = new dbFunction();
    //echo("inside php login");
	$emailid = "leykart1";  
    $password ="leykart1"; 
    // $user = $funObj->Login($emailid, $password);
	// //$user = $funObj->caller();
	// //$user = $funObj->actionToBeTaken(2,"SAP issues");
	
        // // if ($user) {  
            // // // Registration Success  
           // // //header("location:home.php");
           // // print_r($user);		   
		   // // return ($user);
		   // //}
           
    // if($user){	   
		// // while($row= mysqli_fetch_array($user)){
			// // $output[]=$row;
		// // }
		// echo json_encode($user);
	// }else{  
            // // Registration Failed  
			// echo "<script>alert('Emailid / Password Not Match')</script>";  
    // }

		
    if(isset($_GET['login'])){  
        //$emailid = $_POST['emailid'];  
        //$password = $_POST['password'];  
        //$user = $funObj->Login($emailid, $password); 
		
        print_r($_GET['cred']);		
		//echo("inside if of login");
		$user = $funObj->Login($emailid, $password);
        if ($user) {  
            // Registration Success  
           //header("location:home.php");  
		   echo json_encode($user);
        } else {  
            // Registration Failed  
            echo "<script>alert('error in getting login ')</script>";  
        }  
    }

	if(isset($_GET['callerType'])){  
        //print_r($_GET['cred']);		
		//echo("inside if of login");
		$user = $funObj->caller();
        if ($user) {  
            // Registration Success  
           //header("location:home.php");  
		    
		   echo    json_encode($user );
		   //print_r($user);
		  
        } else {  
            // Registration Failed  
            echo "<script>alert('error in getting caller type')</script>";  
        }  
    }
	
	if(isset($_GET['IssueType'])){  
		$data = json_decode(file_get_contents("php://input"));
        //print_r($_GET['cred']);		
		//echo("inside if of login");
		$user = $funObj->issuetype($data);
        if ($user) {  
		   echo json_encode($user );
        } else {  
            echo "<script>alert('error in Storing Issue type in local database')</script>";  
        }  
    }
	
	if(isset($_GET['actionToBeTaken'])){ 
		$data = json_decode(file_get_contents("php://input"));
        //print_r($_GET['cred']);
        //print_r("action to be taken php called");		
		 $callerTypeId = $data->callertypeId ;
		 $issue = $data->isuuecateg ;
		 //$issueCateg = $data->isuuecateg->issue_category;
		//$callerType = (string)($data->callertype);
		//$issueCateg = (string)($data->isuuecateg);
		//print_r($callerTypeId);
		//print_r($issue);
		$user = $funObj->actionToBeTaken($callerTypeId,$issue);
        if ($user) {  
            // Registration Success  
           //header("location:home.php");  
		    
		   echo json_encode($user );
		   //print_r($user);
		  
        } else {  
            // Registration Failed  
            echo "<script>alert('error in getting action to be taken')</script>";  
        }  
    }
    if(isset($_GET['FeedbackQues'])){
        $data = json_decode(file_get_contents("php://input"));
//print_r($data);
        $feedbackQuestion=$funObj->getFeedbackQuestions($data->feedbackType);
        if($feedbackQuestion){
            echo(json_encode($feedbackQuestion));
        }
        else{
            echo "<script>alert('Something went wrong. Please contact your adminstrator.')</script>";
        }
    }
    if(isset($_GET['ViewFeedback'])){
        $funObj->viewFeedback();
    }
    if(isset($_GET['CheckOrderID'])){
        $data=json_decode(file_get_contents("php://input"));
        $present=$funObj->checkOrderId($data->orderID);
        if($present){
            echo(json_encode($present));
        }
        else{
            echo "<script>alert('Something went wrong. Please contact your adminstrator.')</script>";
        }
    }
    if(isset($_GET['FeedbackOptions'])){
        $data=json_decode(file_get_contents("php://input"));
        $feedbackOptions=$funObj->getFeedbackOptions($data->qid_array);
        if($feedbackOptions){
            echo(json_encode($feedbackOptions));
        }
        else{
            echo "<script>alert('Something went wrong. Please contact your adminstrator.')</script>";
        }
    }
    if(isset($_GET['sendfeedback'])){
        $data= json_decode(file_get_contents("php://input"));
        $orderno=$data->orderno;
        $feedbacktype=$data->feedbacktype;
        $feedbackoptions=$data->feedbackoptions;
        if($orderno!==0){
        $feedback=$funObj->sendFeedback($orderno,$feedbacktype,$feedbackoptions);}
        if($feedback){
            echo(json_encode($feedback));
        }
        else{
            echo "<script>alert('Something went wrong. Please contact your adminstrator.')</script>";
        }
    }
	if(isset($_GET['createticket'])){ 
		$data = json_decode(file_get_contents("php://input"));
		 $ticketid = $data->ticketid;
		 $ticketno = $data->ticketno;
		 $createdAt = $data->created;
		 $createdBy = $data->staff_id;
		 $status = $data->status;
		 $lastatendedby = $data->lastatendedby;
		 $lastatendeddate = $data->lastatendeddate;
		 $isuuecateg = $data->isuuecateg ;
		 $orderno = $data->orderno;
		 $agentId = $data->agentId;
		 $comment = $data->comment;
		 
		//$callerType = (string)($data->callertype);
		//$issueCateg = (string)($data->isuuecateg);
		$user=$funObj->createTicket($ticketno,$ticketid,$status,$orderno,$createdBy,$createdAt,$lastatendedby,$lastatendeddate,$isuuecateg);
        //print_r($user);
		if ($user) {  
            // Registration Success  
           //header("location:home.php");  
		    
		   echo(json_encode($user));
		   //print_r($user);
		  
        } else {  
            // Registration Failed  
            echo "<script>alert('error in getting create ticket')</script>";  
        }  
    }
	
	if(isset($_GET['viewticket'])){ 
		$data = json_decode(file_get_contents("php://input"));		
		$agentId = $data->Agent ;
		$daterange = $data->daterange ;
		$user = $funObj->viewticket($agentId,$daterange);
        if ($user) {  
            // Registration Success  
           //header("location:home.php");  
		    
		   echo json_encode($user );
		   //print_r($user);
		  
        } else {  
            // Registration Failed  
            echo ("<script>alert('error in getting view ticket')</script>");  
        }  
    }
	
	if(isset($_GET['PocDetail'])){ 
		// $data = json_decode(file_get_contents("php://input"));		
		// $agentId = $data->Agent ;
		// $daterange = $data->daterange ;
		$user = $funObj->pocdeatil();
        if ($user) {    
		   echo json_encode($user);
		   //print_r($user);	  
        } else {   
            echo ("<script>alert('error in getting poc detail')</script>");  
        }  
    }
	
	// if(isset($_GET['storeTicketDetail'])){ 
		// $data = json_decode(file_get_contents("php://input"));		
		// // $agentId = $data->Agent ;
		// // $daterange = $data->daterange ;
		// //print_r($data);
		// //echo($data)
		// $user = $funObj->ticketandorderno($data);
        // if ($user) {    
		   // echo json_encode($user);
		   // //print_r($user);	  
        // } else {   
            // echo ("<script>alert('error in storing data to ticket with order table')</script>");  
        // }  
    // }
	
	// if(isset($_GET['storeOrderDetail'])){
		// $data = json_decode(file_get_contents("php://input"));		
		// // $agentId = $data->Agent ;
		// // $daterange = $data->daterange ;
		// //print_r($data);
		// //echo($data)
		// $user = $funObj->orderdetails($data);
        // if ($user) {    
		   // echo json_encode($user);
		   // //print_r($user);	  
        // } else {   
            // echo ("<script>alert('error in storing data to order detail table')</script>");  
        // }  
    // }
	
	// if(isset($_GET['fetchorderandticketNo'])){ 
		// $data = json_decode(file_get_contents("php://input"));		
		// //print_r($data);
		// $user = $funObj->orderAndTicketNoJoinQuery();
        // if ($user) {    
		   // echo json_encode($user);
		   // //print_r($user);	  
        // } else {   
            // echo ("<script>alert('error in fetching details while using join query table to combine ticket no and order no')</script>");  
        // }  
    // }
	
	if(isset($_GET['uploadFilePath'])){ 
		$data = json_decode(file_get_contents("php://input"));		
		//print_r($data);
		$user = $funObj->uploadFilePath($data);
        if ($user) {    
		   echo json_encode($user);
		   //print_r($user);	  
        } else {   
            echo ("<script>alert('error in uploading file path in database')</script>");  
        }  
    }
	
	if(isset($_GET['ViewFilePath'])){ 
		$data = json_decode(file_get_contents("php://input"));		
		//print_r($data);
		$user = $funObj->ViewFilePath($data);
		//print_r($user[0]['path']);
        if ($user[0]['path']) {    
			$filename = $user[0]['path'];
			if (file_exists($filename)) {
				echo json_encode($user);
			} else {
				echo json_encode("The file does not exist in Server");
			}
		   //echo json_encode($user);
		   //print_r($user);	  
        } else {   
            echo json_encode("Error in getting file path from database");  
        }  
    }
	
	
    // if($_POST['register']){  
        // $username = $_POST['username'];  
        // $emailid = $_POST['emailid'];  
        // $password = $_POST['password'];  
        // $confirmPassword = $_POST['confirm_password'];  
        // if($password == $confirmPassword){  
            // $email = $funObj->isUserExist($emailid);  
            // if(!$email){  
                // $register = $funObj->UserRegister($username, $emailid, $password);  
                // if($register){  
                     // echo "<script>alert('Registration Successful')</script>";  
                // }else{  
                    // echo "<script>alert('Registration Not Successful')</script>";  
                // }  
            // } else {  
                // echo "<script>alert('Email Already Exist')</script>";  
            // }  
        // } else {  
            // echo "<script>alert('Password Not Match')</script>";  
          
        // }  
    // }  

?>