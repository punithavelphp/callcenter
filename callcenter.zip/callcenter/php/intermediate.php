<?php
require_once('config.php');
class intermediate {

	public function setconfigdataandexecute($requrl,$reqdata){

		// change base url, authorization key , proxy ip

		//echo $ipaddress = $_SERVER['REMOTE_ADDR']; exit;

		header('Access-Control-Allow-Origin:*');
		header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
		header('Access-Control-Max-Age: 1000');
		header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');

		// $headers = array(
        //     'Content-Type: application/json',
        //     // 'Authorization: Bearer '.AUTH_TOKEN
        // );



		function_exists('curl_version') or die('CURL support required');
		function_exists('json_encode') or die('JSON support required');

		#set timeout
		// set_time_limit(0);
		#curl post
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_POST, 0);
		curl_setopt($ch, CURLOPT_MAXREDIRS , 10);
		curl_setopt($ch, CURLOPT_TIMEOUT  , 180);
        //print_r($config['baseUrl'].$config['apiUrl']);
        //curl_setopt($ch, CURLOPT_URL, config_osticket_base_url.$config[$requrl]);
		curl_setopt($ch, CURLOPT_URL, config_osticket_base_url.ConfigOsTicketurl[$requrl]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		// curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array( 'Content-Type: application/json',
						'X-API-Key: '.config_osticket_key
						//'Content-Length: ' . strlen($reqdata)
						));
        // curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        //         'Content-Type: application/json',
        //         'X-API-Key: ' . $config['osticket_apikey'],
        //         'Content-Length: ' . strlen($data))
        // );
		curl_setopt($ch, CURLOPT_HTTPPROXYTUNNEL, 0);
        curl_setopt($ch, CURLOPT_PROXY, config_CURL_PROXY);   // localhost
		//curl_setopt($ch, CURLOPT_PROXY, '172.25.28.7:3128'); // prod
        //curl_setopt($ch, CURLOPT_PROXY, '172.25.26.3:3128'); // qa
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        if($reqdata!=null){
            curl_setopt($ch, CURLOPT_POSTFIELDS,json_encode($reqdata));
        }
        $server_output = curl_exec ($ch);

        $err = curl_error($ch);
        //print_r(curl_getinfo($ch));
        //print_r("\n");
        curl_close ($ch);

		
		if ($err) {
   			$errordata = array('error'      =>     'true',
				'message'     =>     $err
				);
            echo json_encode($errordata);
  		} 
		else {
	//echo 'iam in else';
		$response =  (is_string($server_output) && is_array(json_decode($server_output, true)) ? true : false);
		//echo isJson($server_output);
	//	die;
			//$result = json_decode($server_output);
			//echo $result;
			if ($server_output !== 'null' && $response == FALSE) {
				// JSON is invalid
				//echo 'iam in else if';
				$errordata = array('error'      =>     'true',
				'message'     =>     $server_output
				);
				echo json_encode($errordata);
			}
			else
				echo $server_output;
			//return $server_output;  
			die;
		}

	}
}

// creating object for intermediate class
$intermed =new intermediate();


if(isset($_GET['login'])){
//if($_SERVER["REQUEST_METHOD"] == "POST") {
	   
	$_POST = json_decode(file_get_contents('php://input'), true);
	$data = array(
		'luser'      =>     $_POST['luser'],
		'lpasswd'     =>     $_POST['lpasswd'],
                'depart_name'   =>  $_POST['depart_name']    
	);
	$output = $intermed->setconfigdataandexecute('authenticationurlpath',$data);
	return ;
	//return  is_string($output);
	//return $intermed->setconfigdataandexecute('authenticationurlpath',$data);
  
}

elseif(isset($_GET['createticket'])){
	   
	$_POST = json_decode(file_get_contents('php://input'), true);
	$data = array("name" => $_POST['name'],
					"email" => $_POST['email'], 
					"phone" => $_POST['phone'],
                                        "comment" => $_POST['comment'],
					"subject" => $_POST['subject'],
					"message"   => $_POST['message'],
					//"ip"  => $_POST['ip'],
					"topicId" => $_POST['topicId'],   // 27
					"laykartappsubcategory" => $_POST['laykartappsubcategory'],
					"TicketType" => $_POST['TicketType'],
					"priority"=> $_POST['priority']
	 );

	return $intermed->setconfigdataandexecute('createticketurlpath',$data);
  
}

elseif(isset($_GET['viewticket'])){
	   
	$_POST = json_decode(file_get_contents('php://input'), true);
	$data = array(
		"luser"=> $_POST['luser'],
		"lpasswd"=> $_POST['lpasswd'],
		"helptopic"=> $_POST['helptopic'], 
		"ticket_number"=> $_POST['ticket_number'],
		"status"=> $_POST['status'],
		"staff_id"=> $_POST['staff_id'],
		"from_date"=> $_POST['from_date'],
		"to_date"=> $_POST['to_date']
	);
	//print_r("inside viewticket");
	//print_r($intermed->setconfigdataandexecute('viewticketurlpath',$data));
	return ($intermed->setconfigdataandexecute('viewticketurlpath',$data));
  
}

elseif(isset($_GET['l1agentOnly'])){
	   
	$_POST = json_decode(file_get_contents('php://input'), true);
	$data = array(
		  "luser"=> $_POST['luser'],
		  "lpasswd"=> $_POST['lpasswd'],
		  "request_data"=> $_POST['request_data'],
                  "depart_name"=>$_POST['depart_name']
	);

	return $intermed->setconfigdataandexecute('l1agenturlpath',$data);
  
}

elseif(isset($_GET['l1agent'])){
	   
	$_POST = json_decode(file_get_contents('php://input'), true);
	$data = array(
		  "luser"=> $_POST['luser'],
		  "lpasswd"=> $_POST['lpasswd'],
		  "request_data"=> $_POST['request_data'],
		  "application_name"=> $_POST['application_name'],
                  "depart_name"=>$_POST['depart_name']
	);

	return $intermed->setconfigdataandexecute('l1agenturlpath',$data);
  
}

elseif(isset($_GET['updateticketNote'])){
	   
	$_POST = json_decode(file_get_contents('php://input'), true);
	$data = array(
		"luser"=> $_POST['luser'],
		"lpasswd"=> $_POST['lpasswd'],
		"ticket_id"=> $_POST['ticket_id'],
		"update_type"=> $_POST['update_type'],
		"title"=> $_POST['title'],
		"message"=> $_POST['message']
		
	);


	return $intermed->setconfigdataandexecute('updateticketurlpath',$data);
  
}

elseif(isset($_GET['updateticketReply'])){
	   
	$_POST = json_decode(file_get_contents('php://input'), true);
	$data = array(
		"luser"=> $_POST['luser'],
		"lpasswd"=> $_POST['lpasswd'],
		"ticket_id"=> $_POST['ticket_id'],
		"update_type"=> $_POST['update_type'],
		"message"=> $_POST['message'],
		"status"=> $_POST['status']
	);


	return $intermed->setconfigdataandexecute('updateticketurlpath',$data);
  
}

elseif(isset($_GET['updateticketUpdate'])){
	   
	$_POST = json_decode(file_get_contents('php://input'), true);
	$data = array(
		"luser"=> $_POST['luser'],
		"lpasswd"=> $_POST['lpasswd'],
		"ticket_id"=> $_POST['ticket_id'],
		"update_type"=> $_POST['update_type'],
		"topic_id"=> $_POST['topic_id'],
		"subcategory_id"=> $_POST['subcategory_id'],
		"subcategory_value"=> $_POST['subcategory_value'],
		"ticket_type"=> $_POST['ticket_type'],
		"priority"=> $_POST['priority']
	);


	return $intermed->setconfigdataandexecute('updateticketurlpath',$data);
  
}

elseif(isset($_GET['updateticketAssign'])){
	   
	$_POST = json_decode(file_get_contents('php://input'), true);
	$data = array(
		"luser"=> $_POST['luser'],
		"lpasswd"=> $_POST['lpasswd'],
		"ticket_id"=> $_POST['ticket_id'],
		"update_type"=> $_POST['update_type'],
		"message"=> $_POST['message'],
		"assignto"=> $_POST['assignto']
	);


	return $intermed->setconfigdataandexecute('updateticketurlpath',$data);
  
}

elseif(isset($_GET['updateticketTransfer'])){
	   
	$_POST = json_decode(file_get_contents('php://input'), true);
	$data = array(
		"luser"=> $_POST['luser'],
		"lpasswd"=> $_POST['lpasswd'],
		"ticket_id"=> $_POST['ticket_id'],
		"update_type"=> $_POST['update_type'],
		"target_dept"=> $_POST['target_dept']
	);


	return $intermed->setconfigdataandexecute('updateticketurlpath',$data);
  
}

?>
