<?php  

// database configuration
//    define("config_DB_HOST", 'localhost');   // localhost
//    define("config_DB_USER", 'test2');  
//    define("config_DB_PASSWORD", 'test2');  
//    define("config_DB_DATABSE", "leykart");  
	// define("config_DB_HOST", '127.0.0.1');  

	 //define("config_DB_HOST", '172.25.26.3');     // qa
     //define("config_DB_PORT", '3306');  
     //define("config_DB_USER", 'MagentoQA');  
     //define("config_DB_PASSWORD", 'Mag#17User');  
     //define("config_DB_DATABSE", "callcenter"); 
	
	
     define("config_DB_HOST", '172.25.28.7');     // prod
     define("config_DB_PORT", '3306');  
     define("config_DB_USER", 'magentouser');  
     define("config_DB_PASSWORD", 'ras13aEW_f');  
     define("config_DB_DATABSE", "callcenter");  


// os ticket configuration
    
    //define("config_CURL_PROXY", '10.68.248.102:80');   // localhost
    define('config_CURL_PROXY', '172.25.28.15:3128'); // prod
    //define('config_CURL_PROXY', '172.25.26.3:3128'); // qa
 

    //define("config_osticket_base_url",'https://os-ticket-qa-leykart-api.leykart.com');  // qa url
    define("config_osticket_base_url",'https://osticketapps.leykart.com');  // prod url

    //define("config_osticket_key", 'ADFA638D6EEB057D8AD20B2235CCBB59'); // local host
    define('config_osticket_key', '6E630B0319B0066112238E073DF5B9FE');  // prod server api key
    //define('config_osticket_key', '630C19018F1CF19D653FC87AA7225043'); // qa server api key

    define('ConfigOsTicketurl', array(
        'authenticationurlpath'=> '/api/http.php/authenticate.json',
        'createticketurlpath'=>'/api/http.php/tickets.json',
        'viewticketurlpath'=>'/api/http.php/viewticket.json',
        'assignticketurlpath'=>'/api/http.php/updateticket.json',
        'l1agenturlpath'=>'/api/http.php/masterdata.json',
        'updateticketurlpath'=>'/api/http.php/updateticket.json')
    );


    
// magento configuration

    //define('config_magento_base_url','https://shopqa.leykart.com'); //qa url
    define('config_magento_base_url','https://shop.leykart.com');  //prod url
    
  //  define("config_MAGENTO_AUTH_TOKEN", 'y4p2qktt61bym32mf88iajjyqi1l951x');  // qa server auth token
define("config_MAGENTO_AUTH_TOKEN",'6o2mrrvgb7pxere6fxiocuypjweehmkr');  // prod server  auth token

define('ConfigMagentourl', array(
    'orderdetailurlpath' => '/rest/V1/CcmOrder/ccorderdetails/',
    'verifyneworderurlpath' => '/rest/V1/CcmOrder/ccverifyneworder',
    'viewallorderurlpath' => '/rest/V1/CcmOrder/ccviewallorder',
    'verifyupdateneworderurlpath' => '/rest/V1/CcmOrder/cc_update_verify_neworder',
    'getcancelreasonurlpath' => '/rest/V1/cancelreason/getreason',
    'getcurntpastorderurlpath' => '/rest/V1/CcmOrder/cc_orders',
    'getnewuserlisturlpath' => '/rest/V1/CcmOrder/cc_list_newuser/',
    'updateverifyurlpath' => '/rest/V1/CcmOrder/cc_update_verifyuser',
    'getpartcatalougeurlpath' => '/rest/V1/partscatalog/partdetails/',
    'getcancelrequesturlpath' => '/rest/V1/CcmOrder/ccverifyneworder',
    'initiatecancelurlpath' => '/rest/V1/cancelorder/initiate/callcenter',
    'admininitiatecancelurlpath' => '/rest/V1/cancelorder/admininit',
    'pastorderurlpath' => '/rest/V1/CcmOrder/cc_past_orders',
    'getcancelcharges' => '/rest/V1/CcmOrder/getcancelcharges',
    'sendsmsforticket' => '/rest/V1/Sms/sendSmsFromCallcenter'
        )
);
?>
