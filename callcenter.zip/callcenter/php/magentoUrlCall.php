<?php
require_once('config.php');

class magentoToUrlCall{
    public function apiCallMagento($apiUrl,$postData){

        // change base url, authorization key , proxy ip
        
        $ch = curl_init();
        $headers = array(
            'Content-Type: application/json',
            'Authorization: Bearer '.config_MAGENTO_AUTH_TOKEN
            //'Authorization: Bearer y4p2qktt61bym32mf88iajjyqi1l951x'
        );

        // curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
        curl_setopt($ch, CURLOPT_MAXREDIRS , 10);
		curl_setopt($ch, CURLOPT_TIMEOUT  , 180);

        curl_setopt($ch, CURLOPT_POST, 0);
        //print_r($config['baseUrl'].$config['apiUrl']);
        //curl_setopt($ch, CURLOPT_URL,$apiUrl);

        //curl_setopt($ch, CURLOPT_URL, config_magento_base_url.$config[$apiUrl]);
        curl_setopt($ch, CURLOPT_URL, config_magento_base_url.ConfigMagentourl[$apiUrl]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_HTTPPROXYTUNNEL, 0);
        curl_setopt($ch, CURLOPT_PROXY, config_CURL_PROXY);   // localhost
        //curl_setopt($ch, CURLOPT_PROXY, '172.25.28.7:3128'); // prod
        //curl_setopt($ch, CURLOPT_PROXY, '172.25.26.3:3128'); // qa
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        if($postData!=null){
            curl_setopt($ch, CURLOPT_POSTFIELDS,json_encode($postData));
        }
        $server_output = curl_exec ($ch);
        $err = curl_error($ch);
        //print_r(curl_getinfo($ch));
        //print_r("\n");
        curl_close ($ch);
        if($server_output)
            return $server_output;
        else
            $postdata = array('error'      =>     'true',
				'message'     =>     $err
				);
            return json_encode($postdata);
        //return $server_output ;
    }
}

?>