<?php  

   //require_once('dbConfig.php');
   require_once('config.php');
    class dbConnect {  
	
	    private $conn;     
	
        function __construct() {  
              
            $this->conn = mysqli_connect(config_DB_HOST, config_DB_USER, config_DB_PASSWORD, config_DB_DATABSE);
            //echo("in db connect");			
            // print_r($conn);			
            //mysqli_select_db($conn,DB_DATABSE);
			//echo("connection string");
			//print_r($this->conn);
				// if(!$conn)// testing the connection  
				// {  
					// die ("Cannot connect to the database");  
				// }   
			//print_r($conn);
            //return $conn;  
        }  
		
		public function getConnection(){
			// require_once('dbConfig.php'); 
			// $conn = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_DATABSE) or die(mysqli_error($db));
			
			// var_dump($connection);
			
        return $this->conn;
        }
	
        public function Close(){  
            mysql_close();  
        }  
    }  
?>  