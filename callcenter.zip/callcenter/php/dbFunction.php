<?php

require_once 'dbConnect.php';
include_once('magentoUrlCall.php');
require_once('config.php');
date_default_timezone_set('Asia/Kolkata');
session_start();

class dbFunction {

    //echo "hello"; 
    private $db;

    function __construct() {

        // connecting to database  
        $this->db = new dbConnect();
        //print_r($this->db->conn);			
    }

    // destructor  
    function __destruct() {
        
    }

    // public function UserRegister($username, $emailid, $password){  
    // $password = md5($password);  
    // $qr = mysql_query("INSERT INTO users(username, emailid, password) values('".$username."','".$emailid."','".$password."')") or die(mysql_error());  
    // return $qr;  
    // }

    public function createArray($res) {
        $output = array();
        if (mysqli_num_rows($res) > 0) {
            while ($row = mysqli_fetch_assoc($res)) {
                $output[] = $row;
            }
            //$jsonoutput = json_encode($output);
            // $_SESSION['login'] = true;  
            // $_SESSION['uid'] = $user_data['id'];  
            // $_SESSION['username'] = $user_data['username'];  
            // $_SESSION['email'] = $user_data['emailid'];  
            //return TRUE;
            return $output;
        } else {
            return $res;
        }
    }

    public function sendSms($customer, $mod) {

        $user_id = "2000167351";
        $password = "u5fF5m";
        $proxy_ip = config_CURL_PROXY;

        //Retrieving the customer's mobile number.
        //$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        //$customerObj = $objectManager->create('Magento\Customer\Model\Customer')->load($customer_id);
        $message = "";
        $customer_mobile = $customer{"mobile_no"};
        $customer_name = $customer{"customer_name"};
        $order = $customer{"order"};
        if ($mod == 1) {
            $message = "Dear " . $customer_name . ", we tried reaching you. In case any queries regarding Leykart, please contact our Call center. Thank you";
            //$message="Dear ".$customer_name.", ".$order." is pending for Verification. Thank You";
        } else if ($mod == 2) {
            $message = "Dear " . $customer_name . ", Leykart tried to call you to get feedback about your recent order. Please contact our Call center in case of any concerns. Thank you";
        }
        //$message="Dear "", Kindly verify your order ".$order." and help us serve you better. Thank you.";
        //$message="Dear ".$customer_name.", Your order ".$order." is pending for payment. We will confirm your order once the payment is done. Thank you";
        //print_r($customer_mobile);
        if ($customer_mobile != "") {

            $request = ""; //initialise the request variable
            $param['method'] = "sendMessage";
            $param['send_to'] = $customer_mobile;
            $param['msg'] = $message;
            $param['userid'] = $user_id;
            $param['password'] = $password;
            $param['v'] = "1.1";
            $param['msg_type'] = "TEXT"; //Can be "FLASH�/"UNICODE_TEXT"/�BINARY�
            $param['auth_scheme'] = "PLAIN";
            $param['format'] = "TEXT";

            //Have to URL encode the values
            foreach ($param as $key => $val) {
                $request .= $key . "=" . urlencode($val); //we have to urlencode the values
                $request .= "&"; //append the ampersand (&) sign after each parameter/value pair
            }
            $request = substr($request, 0, strlen($request) - 1);
            $sms_url = "http://enterprise.smsgupshup.com/GatewayAPI/";
            $url = $sms_url . "rest?" . $request;
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            if ($proxy_ip != '') {
                curl_setopt($ch, CURLOPT_PROXY, $proxy_ip);
            }
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            $curl_scraped_page = curl_exec($ch);
            curl_close($ch);
            if (!$curl_scraped_page) {
                return "Error";
            } else {
                //print_r($url);
                return "Success";
            }
        } else {
            print "Ensure Mobile number is added";
        }
    }

    public function changeStatus($status, $userid) {
        if ($status == "Success") {
            $query = "update ostk_user_verify set sms_status=?,registered_date=registered_date where user_id=?";
            $con = $this->db->getConnection();
            $stmt = $con->prepare($query);
            $stmt->bind_param("si", $sms, $id);
            $sms = $status;
            $id = $userid;
            $stmt->execute();
            $stmt->close();
        }
    }

    public function Login($username, $password) {
        //$res = mysql_query("SELECT * FROM users WHERE emailid = '".$emailid."' AND password = '".md5($password)."'"); 
        //$connect = mysqli_connect("localhost","test2","test2","leykart") or die("unable to connect DB");
        //print_r($connect);
        $query = "SELECT r.name,r.notes,s.firstname FROM ostk_role r INNER JOIN ostk_staff s ON s.role_id = r.id  where s.username='" . $username . "'";
        $res = mysqli_query($this->db->getConnection(), $query);
        //print_r($res);
        //$user_data = mysqli_fetch_array($res);  
        //print_r($user_data);  
        //$no_rows = mysqli_num_rows($res);  

        return $this->createArray($res);
    }

    public function viewFeedback($from, $to) {
        $query = "select feedback_response_id,submitted_time,order_number,ostk_feedback_type.feedback_type,ostk_feedback_question.questions,ostk_feedback_option.options from ostk_feedback_response,ostk_feedback_type,ostk_feedback_question,ostk_feedback_option where ostk_feedback_type.type_id=ostk_feedback_response.feedback_type and ostk_feedback_response.feedback_question_id=ostk_feedback_question.serialNo and ostk_feedback_response.feedback_option_id=ostk_feedback_option.serialNo";
        $query = "CALL `viewFeedback`('" . $from . "','" . $to . "')";
        $res = mysqli_query($this->db->getConnection(), $query);
        if ($res) {
            $res = $this->createArray($res);
        }
        //print_r($res);
        $delimiter = ',';
        $enclosure = '"';
        /* $res=json_encode($res); */
        /* $res=json_decode($res); */
        /* print_r($res); */
        /* $file="feedback.csv";
          if(file_exists($file)){
          unlink($file);
          } */
        //$csvfile = fopen("feedback.csv", 'w+');
        $feedback = [];
        //$feedback_header=["Feedback Response Id","Submitted Time","Order Number","Feedback Type","Question","Option Value","Option Recorded"];
        //array_push($feedback,$feedback_header);
        /* fputcsv($csvfile,["Feedback Response Id","Submitted Time","Order Number","Feedback Type","Question","Option Value","Option Recorded"],$delimiter,$enclosure); */
        if ($res) {
            foreach ($res as $row) {
                /* fputcsv($csvfile, $row,$delimiter,$enclosure); */
                array_push($feedback, $row);
            }
        }
        //$feedback=fgetcsv($csvfile,$delimiter,$enclosure);
        //fclose($csvfile);
        //print_r(json_encode($feedback));
        return $feedback;
    }

    public function caller() {
        //$query="SELECT * FROM idostk_caller_type";
        $query = "CALL `caller`()";
        $res = mysqli_query($this->db->getConnection(), $query);
        return $this->createArray($res);
    }

    public function issuetype($data) {
        //$query="SELECT caller_type,issue_category FROM action_taken where caller_type='".$data->caller_id."'";
        //$query ="CALL `issuetype`($data->caller_id)"; // earlier code
        $caller = $data->caller_id;
        $query = "CALL `issuetype`($caller)";
        $res = mysqli_query($this->db->getConnection(), $query);
        return $this->createArray($res);
    }

    public function removeFileFromServer($filename) {
        if (file_exists($filename)) {
            unlink($filename);
            /* echo "file removed."; */
        }
    }

    public function actionToBeTaken($callerId, $issue) {
        //print_r($caller);	
        // $query="SELECT id FROM idostk_caller_type where caller_type='".$caller."'";
        // $res =mysqli_query($this->db->getConnection(),$query); 
        // $callerId = $this->createArray($res)[0]['id'] ;
        //print_r($callerId );
        //print_r($issue);
        // CALL `callcenter`.`actionToBeTaken`(1,'Cancel order');
        //$query = "SELECT action FROM action_taken where caller_type='".$callerId."' and issue_category='".$issue."'";
        //$issue='".$issue."';
        $query = "CALL `actionToBeTaken`($callerId,'" . $issue . "')";
        $res = mysqli_query($this->db->getConnection(), $query);
        return $this->createArray($res);
    }

    public function getIssuePriority($callerId, $issue) {
        $query = "SELECT priority_id FROM ostk_action_taken where caller_type=$callerId and issue_category = '" . $issue . "'";
        $res = mysqli_query($this->db->getConnection(), $query);
        return $this->createArray($res);
    }

    public function createTicket($ticketno, $ticketid, $status, $orderno, $createdBy, $createdAt, $lastatendedby, $lastatendeddate, $isuuecateg) {
        //$query ="INSERT INTO ostk_view_ticket (ticketNo,ticketid,ticketStatus,orderNo,raisedBy,raisedDate,lastAttendedBy,LastAttendedDate,issueCategoryId) VALUES ('".$ticketno."','".$ticketid."','".$status."','".$orderno."','".$createdBy."','".$createdAt."','".$lastatendedby."','".$lastatendeddate."','".$isuuecateg."')";
        $query = "CALL `createTicket`('" . $ticketno . "',$ticketid,'" . $status . "','" . $orderno . "','" . $createdBy . "','" . $createdAt . "','" . $lastatendedby . "','" . $lastatendeddate . "','" . $isuuecateg . "')";
        //$query="SELECT id FROM idostk_caller_type where caller_type='".$caller."'";
        $res = mysqli_query($this->db->getConnection(), $query);
        return($res);
    }

    public function insertFeedback($con, $mainorder_id, $order, $mobileno, $customername, $shippingaddress, $customertype, $feedback_type, $q_id, $opt_id, $comm) {
        if ($order->method == 'InsFB') {
            $query = "INSERT INTO ostk_feedback_response(mainorder_number,subOrder_number,call_count,call_status,sku_number,quantity,suborder_value,customer_name,mobile_no,shipping_address,customer_type,seller_id,seller_type,feedback_type,feedback_question_id,feedback_option_id,feedback_comment) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
            $stmt = $con->prepare($query);
            $stmt->bind_param("ssissddssssisiiis", $mainorderid, $orderid, $callcount, $callstatus, $skuno, $quantity, $suborder_value, $customer_name, $mobile_no, $shipping_address, $customer_type, $seller_id, $seller_type, $feedbacktype, $qid, $optid, $comment);
            $mainorderid = $mainorder_id;
            $callcount = $order->call_count;
            $callstatus = $order->call_status;
            $orderid = $order->suborder_id;
            $skuno = $order->sku_no;
            $quantity = $order->quantity;
            $suborder_value = $order->total;
            $customer_name = $customername;
            $mobile_no = $mobileno;
            $shipping_address = $shippingaddress;
            $customer_type = $customertype;
            $seller_id = $order->seller_id;
            $seller_type = $order->seller_type;
            $feedbacktype = $feedback_type;
            $qid = $q_id;
            $optid = $opt_id;
            $comment = $comm;
        } else if ($order->method == 'UpdFB') {
            $query = "INSERT INTO ostk_feedback_response(mainorder_number,subOrder_number,call_count,call_status,sku_number,quantity,suborder_value,customer_name,mobile_no,shipping_address,customer_type,seller_id,seller_type,feedback_type,feedback_question_id,feedback_option_id,feedback_comment) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
            $stmt = $con->prepare($query);
            $stmt->bind_param("ssissddssssisiiis", $mainorderid, $orderid, $callcount, $callstatus, $skuno, $quantity, $suborder_value, $customer_name, $mobile_no, $shipping_address, $customer_type, $seller_id, $seller_type, $feedbacktype, $qid, $optid, $comment);
            $mainorderid = $mainorder_id;
            $callcount = $order->call_count;
            $callstatus = $order->call_status;
            $orderid = $order->suborder_id;
            $skuno = $order->sku_no;
            $quantity = $order->quantity;
            $suborder_value = $order->total;
            $customer_name = $customername;
            $mobile_no = $mobileno;
            $shipping_address = $shippingaddress;
            $customer_type = $customertype;
            $seller_id = $order->seller_id;
            $seller_type = $order->seller_type;
            $feedbacktype = $feedback_type;
            $qid = $q_id;
            $optid = $opt_id;
            $comment = $comm;
        } else if ($order->method == 'Ins') {
            $query = "INSERT INTO ostk_feedback_response(mainorder_number,subOrder_number,call_count,call_status,sku_number,quantity,suborder_value,customer_name,mobile_no,shipping_address,customer_type,seller_id,seller_type,feedback_type,feedback_question_id,feedback_option_id,feedback_comment) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
            $stmt = $con->prepare($query);
            $stmt->bind_param("ssissddssssisiiis", $mainorderid, $orderid, $callcount, $callstatus, $skuno, $quantity, $suborder_value, $customer_name, $mobile_no, $shipping_address, $customer_type, $seller_id, $seller_type, $feedbacktype, $qid, $optid, $comment);
            $mainorderid = $mainorder_id;
            $callcount = $order->call_count;
            $callstatus = $order->call_status;
            $orderid = $order->suborder_id;
            $skuno = $order->sku_no;
            $quantity = $order->quantity;
            $suborder_value = $order->total;
            $customer_name = $customername;
            $mobile_no = $mobileno;
            $shipping_address = $shippingaddress;
            $customer_type = $customertype;
            $seller_id = $order->seller_id;
            $seller_type = $order->seller_type;
            $feedbacktype = $feedback_type;
            $qid = null;
            $optid = null;
            $comment = null;
        } else if ($order->method == 'Upd') {
            $query = "UPDATE ostk_feedback_response set call_count=?,call_status=? WHERE subOrder_number=?";
            $stmt = $con->prepare($query);
            $stmt->bind_param("iss", $callcount, $callstatus, $orderid);
            $callcount = $order->call_count;
            $callstatus = $order->call_status;
            $orderid = $order->suborder_id;
            if ($callcount == 5) {
                $cust = Array("customer_name" => $customername, "mobile_no" => $mobileno, "order" => $order->suborder_id);
                $this->sendSms($cust, 2);
            }
        }
        $stmt->execute();
        $stmt->close();
    }

    public function getCallStatus() {
        $query = "CALL `getCallStatus`()";
        $res = mysqli_query($this->db->getConnection(), $query);
        return $this->createArray($res);
    }

    public function getCustomerGroups() {
        $query = "CALL `getCustomerGroups`()";
        $res = mysqli_query($this->db->getConnection(), $query);
        return $this->createArray($res);
    }

    public function sendFeedback($mainorder, $order, $mobile_no, $customer_name, $shipping_address, $customer_type, $feedback_type, $feedbackoptid) {
        $values = "";
        $con = $this->db->getConnection();
        $stmt_array = [];
        foreach ($order as $suborder_item) {
            if ($suborder_item->method == 'UpdFB') {
                $query = "DELETE FROM ostk_feedback_response where subOrder_number=?";
                $stmt = $con->prepare($query);
                $stmt->bind_param("s", $orderid);
                $orderid = $suborder_item->suborder_id;
                $stmt->execute();
            }
            if ($feedbackoptid) {
                foreach ($feedbackoptid as $val) {
                    /* $values.="('".$suborderid."','".$feedback_type."','".$val->qid."','".$val->optid."','".$val->comment."'),"; */
                    /* $query ="CALL `sendFeedback`('".$suborderid."','".$feedback_type."','".$val->qid."','".$val->optid."','".$val->comment."')";
                      $res=mysqli_query($this->db->getConnection(),$query); */
                    //print_r($suborder_item);
                    //print_r("\n");
                    //print_r($suborder_item->suborder_id);
                    $this->insertFeedback($con, $mainorder, $suborder_item, $mobile_no, $customer_name, $shipping_address, $customer_type, $feedback_type, $val->qid, $val->optid, $val->comment);
                }
            } else {
                for ($x = 0; $x < $suborder_item->times; $x++) {
                    $this->insertFeedback($con, $mainorder, $suborder_item, $mobile_no, $customer_name, $shipping_address, $customer_type, $feedback_type, null, null, null);
                }
            }
        }
        /* $query="INSERT INTO ostk_feedback_response(order_number,feedback_type,feedback_question_id,feedback_option_id,feedback_comment) VALUES (?,?,?,?,?)"; */
        /* $values=rtrim($values,", \t\n");
          $query="INSERT INTO ostk_feedback_response(order_number,feedback_type,feedback_question_id,feedback_option_id,feedback_comment) VALUES".$values.""; */
        //$query ="CALL `sendFeedback`('".$suborderid."','".$feedback_type."','".$val->qid."','".$val->optid."','".$val->comment."')";
        $values = rtrim($values, ", \t\n");
        $query = "INSERT INTO ostk_feedback_response(order_number,feedback_type,feedback_question_id,feedback_option_id,feedback_comment) VALUES" . $values . "";
        $res = mysqli_query($this->db->getConnection(), $query);
        return($query);
        /* $res=mysqli_query($this->db->getConnection(),$query);
          return($res); */
        /* return($stmt_array); */
        /* return([$orderNo,$feedbackoptid]); */
    }

    public function getFeedbackQuestions($feedbackType) {
        //$query="SELECT serialNo,questions,question_type from ostk_feedback_question where feedback_type=(select type_id from ostk_feedback_type where feedback_type='".$feedbackType."')";
        //$query ="CALL `getFeedbackQuestions`('".$feedbackType."')";

        $query = "SELECT serialNo,questions,question_type from ostk_feedback_question where feedback_type=(select type_id from ostk_feedback_type where feedback_type='" . $feedbackType . "') and serialNo in (9, 10)";
        $res = mysqli_query($this->db->getConnection(), $query);
        return $this->createArray($res);
    }

    public function checkOrderId($orderId) {
        //$query="SELECT feedback_response_id FROM ostk_feedback_response WHERE order_number='".$orderId."'";
        $query = "CALL `checkOrderId`('" . $orderId . "')";
        $res = mysqli_query($this->db->getConnection(), $query);
        return $this->createArray($res);
    }

    public function getFeedbackOptions($qid) {
        $arr = [];
        foreach ($qid as $value) {
            $row1 = [];
            $con = $this->db->getConnection();
            $query = "SELECT ostk_feedback_question.serialNo qno, ostk_feedback_option.serialNo optno, options FROM ostk_feedback_option,ostk_feedback_question WHERE feedback_question_id=? and ostk_feedback_question.serialNo=feedback_question_id";
            $stmt = $con->prepare($query);
            $serialNo = $value->serialNo;
            $stmt->bind_param("i", $serialNo);
            $stmt->execute();
            $stmt->bind_result($qno, $optno, $opts);
            while ($stmt->fetch()) {
                $row = array('qno' => $qno, 'optno' => $optno, 'options' => $opts);
                array_push($row1, $row);
            }
            array_push($arr, $row1);
            $stmt->close();
            /* $query ="CALL `getFeedbackOptions`('".$value->serialNo."')"; */
            /* $res=mysqli_query($con,$query);
              while($row=mysqli_fetch_array($res)){
              array_push($row1,$row);
              } */
            /*                mysqli_close($con); */

            /* array_push($arr,$this->createArray($res)); */
        }
        return $arr;
    }

    public function viewticket($agentId, $daterange) {
        // print_r($agentId );
        // print_r($daterange->from_date );
        // print_r($daterange->to_date );
        $datefrom = $daterange->from_date;
        $dateto = $daterange->to_date;

        //$query = "SELECT * FROM ostk_view_ticket where raisedBy='".$agentId."' and cast(raisedDate as date) >='".$datefrom."' and cast(raisedDate as date) <='".$dateto."'";
        $query = "CALL `viewticket`('" . $agentId . "','" . $datefrom . "','" . $dateto . "')";
        //print_r($query);
        $res = mysqli_query($this->db->getConnection(), $query);
        //print_r($res);
        return $this->createArray($res);
    }

    public function pocdeatil() {
        //$query="SELECT * FROM ostk_poc_detail";
        $query = "CALL `pocdeatil`()";
        $res = mysqli_query($this->db->getConnection(), $query);
        return $this->createArray($res);
    }

    // public function ticketandorderno($datas){
    // //print_r($datas);
    // if(sizeof($datas) > 0){
    // foreach ($datas as $data) {
    // //echo $data->ticket_number;
    // //echo $data->self_added_orderno;
    // $query ="INSERT INTO ticket_with_order (orderid,ticketno) VALUES ('".$data->self_added_orderno."','".$data->ticket_number."')";
    // $res = mysqli_query($this->db->getConnection(),$query);  
    // //print_r($res);
    // }
    // return($res) ;
    // }
    // else{
    // return "There Is No Ticket Details Present In Input";
    // }
    // }
    // public function orderdetails($datas){
    // //print_r($datas);
    // if(sizeof($datas) > 0){
    // foreach ($datas as $data) {
    // //echo $data->ticket_number;
    // //echo $data->self_added_orderno;
    // $query ="INSERT INTO order_detail (orderid,status) VALUES ('".$data->suborder_id."','".$data->verified_status."')";
    // $res = mysqli_query($this->db->getConnection(),$query);  
    // //print_r($res);
    // }
    // return($res) ;
    // }
    // else{
    // return "There Is No Orders Present In Input";
    // }
    // }
    // public function orderAndTicketNoJoinQuery(){
    // //print_r($datas);
    // $query="SELECT * FROM order_detail NATURAL JOIN ticket_with_order;";
    // $res =mysqli_query($this->db->getConnection(),$query);
    // $query="truncate table order_detail ;";
    // $res1 =mysqli_query($this->db->getConnection(),$query);
    // //print_r($res1);
    // $query="truncate table ticket_with_order ;";
    // $res2 =mysqli_query($this->db->getConnection(),$query);
    // //print_r($res2);
    // return  $this->createArray($res) ;
    // }

    public function uploadFilePath($idd, $pat) {
        //print_r($data);
        //$query="SELECT * FROM upload_files where id='".$data->id."'";
        /* $idd=$data->id; */
        $con = $this->db->getConnection();
        $query = "CALL`uploadfile`('" . $idd . "')";
        $res = $con->query($query);
        //print_r($res->num_rows);
        if ($res->num_rows == 0) {
            $con->next_result();
            //print_r("  here");
            /* $pat = "uploadedData/".$data->filepath; */
            //print_r($idd);
            //$path1="$pat";
            //print_r($path1);
            //$queryy = "INSERT INTO ostk_upload_file(id,pat) VALUES ('$idd','$pat')";
            //$queryy ="INSERT INTO ostk_upload_file (id,path) VALUES(3,""comments.txt"")";
            //print_r($queryy);
            //print_r(mysqli_query($this->db->getConnection(),$queryy));
            //print_r("\nEntering insert region. . .");
            //print_r($idd);
            //print_r($pat);
            $queryy = "CALL `uploadFilePathInsert`('" . $idd . "','" . $pat . "')";
            //print_r("CALL `uploadFilePathInsert`('".$idd."','".$pat."')");
            //print_r("\nExecuting query. . .\n");
            /* $res1=mysqli_query($this->db->getConnection(),$queryy,MYSQLI_USE_RESULT); */
            $res1 = $con->query($queryy);
            //print_r($res1);
            // mysqli_query($this->db->getConnection(),$queryy);
            if (!$res1) {
                die("Error : " . mysqli_error($this->db->getConnection()));
            } else {
                //print_r($res1);
            }

            // exit;
            return ($res1);
        } else {
            //print_r("  here2");
            $con->next_result();
            /* $path = 'uploadedData/'.$data->filepath; */
            //print_r($path);
            //$query ="update upload_files set path = '".$pat."' where id = '".$idd."'";
            $query = "CALL`uploadFilePathupdate`('" . $pat . "','" . $idd . "')";
            //print_r($query);
            /* $res1 =mysqli_query($this->db->getConnection(),$query,MYSQLI_USE_RESULT); */
            $res1 = $con->query($query);
            //print_r($res1);
            return $res1;
        }
        //return ($res) ;
    }

    public function ViewFilePath($data) {
        //print_r($data);
        //$query="SELECT path FROM upload_files where id = '".$data->id."'";
        $query = "CALL `ViewFilePath`('" . $data->id . "')";
        $res = mysqli_query($this->db->getConnection(), $query);
        //return $res;
        return $this->createArray($res);
    }

    public function addPOCDetail($poc) {
        $query = "CALL `clearPOCDetails`()";
        $conn = $this->db->getConnection();
        $res = mysqli_query($conn, $query);
        $query = "CALL `resetAutoIncrementPOC`()";
        $res = mysqli_query($conn, $query);
        //mysqli_free_result($res);   
        //mysqli_next_result($conn);
        $poc = json_decode($poc);
        //print_r(json_decode($poc));
        //print_r("\n");
        foreach ($poc as $row) {
            //print_r($row);
            $query = "CALL `addPOCDetail`('" . $row->{'POC CATEGORY'} . "','" . $row->{'SELLER ID'} . "','" . $row->{'SELLER NAME'} . "','" . $row->{'POC NAME'} . "','" . $row->{'POC CONTACT NO'} . "','" . $row->{'POC EMAIL'} . "')";
            $res = mysqli_query($conn, $query);
            //mysqli_free_result($res);   
            //mysqli_next_result($conn);
        }
    }

    public function displayAddPOCDetail() {
        $query = "CALL `displayPOCDetail`()";
        $conn = $this->db->getConnection();
        $res = mysqli_query($conn, $query);
        if ($res->num_rows != null) {
            return $this->createArray($res);
        } else {
            return array('POC CATEGORY' => '', 'SELLER ID' => '', 'SELLER NAME' => '', 'POC NAME' => '', 'POC CONTACT NO' => '', 'POC EMAIL' => '');
        }
    }

    // public function actionToBeTaken($caller,$issue){  
    // //$res = mysql_query("SELECT * FROM users WHERE emailid = '".$emailid."' AND password = '".md5($password)."'"); 
    // //$connect = mysqli_connect("localhost","test2","test2","leykart") or die("unable to connect DB");
    // //print_r($connect);
    // $query="SELECT action FROM ostk_action_taken where caller_type='".$caller."' and issue_category='".$issue."'";
    // $res = 	 mysqli_query($this->db->getConnection(),$query);
    // // $user_data = mysqli_fetch_array($res);  
    // // print_r($user_data);  
    // // $no_rows = mysqli_num_rows($res);  
    // if(mysqli_num_rows($res) > 0){	   
    // while($row= mysqli_fetch_array($res)){
    // $output[]=$row;
    // }
    // //echo json_encode($output);
    // // $_SESSION['login'] = true;  
    // // $_SESSION['uid'] = $user_data['id'];  
    // // $_SESSION['username'] = $user_data['username'];  
    // // $_SESSION['email'] = $user_data['emailid'];  
    // //return TRUE;
    // return $output;				
    // }  
    // else  
    // {  
    // return FALSE;  
    // }  
    // }


    public function isUserExist($emailid) {
        $qr = mysql_query("SELECT * FROM users WHERE emailid = '" . $emailid . "'");
        echo $row = mysql_num_rows($qr);
        if ($row > 0) {
            return true;
        } else {
            return false;
        }
    }

    public function viewAllOrders($data) {
        $magentoCall = new magentoToUrlCall();
        date_default_timezone_set('Asia/Kolkata');
        //print_r($data);
        $incomingOrders = $magentoCall->apiCallMagento('viewallorderurlpath', $data);
        $err_status = strpos($incomingOrders, "<title>There has been an error processing your request</title>");
        if ($err_status == false) {
            //print_r($incomingOrders);
            $n = strpos($incomingOrders, "[");
            $response = substr_replace($incomingOrders, "", 0, $n);
            //$response = substr_replace($response, "" , -1,1);
            //print_r($incomingUnverifiedOrders);
            $array = json_decode($response);
            //print_r(json_encode(html_entity_decode($incomingUnverifiedOrders)),TRUE);
            //print_r($response[0]);
            //print_r($array);
            if ($array && isset($array->error) && $array->error == true) {
                
            } else {

                $query1 = "insert into ostk_all_orders(ref_incr_id,order_id,order_status,suborder_id,order_type,suborder_status,order_date,customer_name,customer_type,customer_mobile,customer_email,customer_address,main_parent_id,dp_name,expected_arrival,seller_id,seller_mobile,seller_name,ship_chrg_actual,ship_chrg_estimated,sku_name,sku_no,quantity,total,amount_paid,updated_at,call_count,call_status,city,state,comments) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) on duplicate key update suborder_status=?";
                $con = $this->db->getConnection();

                $stmt = $con->prepare($query1);
                $stmt->bind_param("ssssssssssssssssssddssdddsisssss", $ref_incr_id, $order_id, $order_status, $suborder_id, $order_type, $suborder_status, $order_date, $customer_name, $customer_type, $customer_mobile, $customer_email, $customer_address, $main_parent_id, $dp_name, $expected_arrival, $seller_id, $seller_mobile, $seller_name, $ship_chrg_actual, $ship_chrg_estimated, $sku_name, $sku_no, $quantity, $total, $amount_paid, $updated_at, $call_count, $call_status, $city, $state, $comments, $suborder_status);
                $count = $array[0]->count;
                $arrayData = $array[0]->data;

                // print_r($array);
                foreach ($arrayData as $order) {
                    $ref_incr_id = $order->ref_incr_id;
                    $comments = '';
                    $order_id = $order->order_id;
                    $order_status = $order->order_status;
                    $suborder_id = $order->suborder_id;
                    $order_type = $order->order_type;
                    $suborder_status = $order->suborder_status;
                    $order_date = new DateTime(date("Y-m-d g:i:s", strtotime($order->order_date)));
                    $order_date = (string) $order_date->format('Y-m-d H:i:s');
                    $customer_name = $order->customer_name;
                    $customer_type = $order->customer_type;
                    $customer_mobile = $order->customer_mobile;
                    $customer_email = $order->customer_email;
                    $customer_address = $order->customer_address;
                    $city = $order->customer_city;
                    $state = $order->customer_state;
                    $main_parent_id = $order->main_parent_id;
                    $dp_name = $order->dp_name;
                    $expected_arrival = $order->expected_arrival;
                    $seller_id = $order->seller_id;
                    $seller_mobile = $order->seller_mobile;
                    $seller_name = $order->seller_name;
                    $ship_chrg_actual = $order->ship_chrg_actual;
                    $ship_chrg_estimated = $order->ship_chrg_estimated;
                    $sku_name = $order->sku_name;
                    $sku_no = $order->sku_no;
                    $quantity = $order->quantity;
                    $total = $order->total;
                    $amount_paid = $order->amount_paid;
                    $updated_at = new DateTime(date("Y-m-d g:i:s", strtotime($order->updated_at)));
                    $updated_at = (string) $updated_at->format('Y-m-d H:i:s');
                    $call_count = 0;
                    $call_status = "";
                    $sub = $order->suborder_id;
                    //print_r($updated_at);
                    $stmt->execute();
                }
                $stmt->close();
            }
        }
        $query = "select * from ostk_all_orders where order_date>=? and order_date<=? order by order_id desc limit " . $data->page_num . ",20";



        //$total_rows = mysql_fetch_row($query);
        //$finalcount = $total_rows['num'];
        //print_r($query);    
        $con = $this->db->getConnection();
        $stmt = $con->prepare($query);
        //print_r($stmt);
        //$stmt->bind_param("ss",$from_date,$to_data);
        //print_r((string)$from_date);
        //print_r($to_date);
        $stmt->bind_param("ss", $from_date, $to_date);
        //$from_data=date("Y-m-d g:i:s",strtotime($data->from_date));
        //print_r($from_data);
        //$to_date=(string)$data->to_date;
        $stmt->execute();
        $result = $stmt->get_result();


        $a = array();


        while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
            //print_r($row);
            $a[] = $row;
        }
        //$a=$result->fetch_array(MYSQLI_ASSOC);
        //$stmt->bind_result($r1,$r2,$r3,$r4,$r5,$r6,$r7,$r8,$r9,$r10);
        //$stmt->bind_result($r1);
        //$incomingUnverifiedOrders=$stmt->fetch();
        /* while($stmt->fetch()){
          print_r($r1);
          print_r("\n");
          } */
        $stmt->close();
        //print_r($incomingUnverifiedOrders);
        if ($result->num_rows != 0) {
            //print_r($result);
            $data_out['count'] = $count;
            $data_out['data'] = $a;

            return json_encode([$data_out]);
        }
        $data_out['count'] = $count;
        $data_out['data'] = $arrayData;
//echo '<pre>';
//print_r($data_out);
        return json_encode([$data_out]);
        //return $response;
    }

    public function insUpdOrders($data, $max) {
        $magentoCall = new magentoToUrlCall();
        //print_r($data);
        $incomingUnverifiedOrders = $magentoCall->apiCallMagento('verifyneworderurlpath', $data);
        $err_status = strpos($incomingUnverifiedOrders, "<title>There has been an error processing your request</title>");
        if ($err_status != false) {
            
        }
        if ($err_status == false) {
            //print_r($incomingUnverifiedOrders);
            $n = strpos($incomingUnverifiedOrders, "[");
            $response = substr_replace($incomingUnverifiedOrders, "", 0, $n);
            //$response = substr_replace($incomingUnverifiedOrders, "" , -1,1);
            //print_r($incomingUnverifiedOrders);
            $array = json_decode($response)[0];
            //print_r(json_encode(html_entity_decode($incomingUnverifiedOrders)),TRUE);
            //print_r($array);
            if ($array) {
                $query1 = "insert into ostk_order_verify(ref_incr_id,suborder_id,order_status,customer_name,customer_mobile,date_ordered,verified_status,verify_comment,call_count,call_status,verified_datetime) values(?,?,?,?,?,?,?,?,?,?,?) on duplicate key update suborder_id=?,date_ordered=?";
                $con = $this->db->getConnection();
                $stmt = $con->prepare($query1);
                $stmt->bind_param("ssssssssissss", $ref_inc_id, $suborder_id, $order_status, $customer_name, $customer_mobile, $date_ordered, $verified_status, $verify_comment, $call_cocunt, $call_status, $verified_datetime, $sub_orderid, $dateord);
                foreach ($array as $order) {
                    $ref_inc_id = $order->ref_incr_id;
                    $suborder_id = $order->suborder_id;
                    $order_status = $order->order_status;
                    $customer_name = $order->customer_name;
                    $customer_mobile = $order->customer_mobile;
                    $date_ordered = $order->date_ordered;
                    $verified_status = $order->verified_status;
                    $verify_comment = $order->verify_comment;
                    $call_cocunt = 0;
                    $call_status = "";
                    $sub_orderid = $order->suborder_id;
                    $dateord = $order->date_ordered;
                    $verified_datetime = null;
                    $stmt->execute();
                }
                $stmt->close();
            }
        }
        $query = "select * from ostk_order_verify where date_ordered>=? and date_ordered<=? and verified_status='Not Verified'";
        $con = $this->db->getConnection();
        $stmt = $con->prepare($query);
        //$stmt->bind_param("ss",$from_date,$to_data);
        $from_date = new DateTime(date("Y-m-d g:i:s", strtotime($data->from_date)));
        $to_date = new DateTime(date("Y-m-d g:i:s", strtotime($data->to_date)));
        //print_r($from_date);
        //print_r($to_date);
        $from_date->setTime(00, 00, 00);
        $to_date->setTime(23, 59, 59);
        $from_date = (string) $from_date->format('Y-m-d H:i:s');
        $to_date = (string) $to_date->format('Y-m-d H:i:s');
        //print_r((string)$from_date);
        //print_r($to_date);
        $stmt->bind_param("ss", $from_date, $to_date);
        //$from_data=date("Y-m-d g:i:s",strtotime($data->from_date));
        //print_r($from_data);
        //$to_date=(string)$data->to_date;
        $stmt->execute();
        $result = $stmt->get_result();
        while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
            $a[] = $row;
        }
        //$a=$result->fetch_array(MYSQLI_ASSOC);
        //print_r($a);
        //$stmt->bind_result($r1,$r2,$r3,$r4,$r5,$r6,$r7,$r8,$r9,$r10);
        //$stmt->bind_result($r1);
        //$incomingUnverifiedOrders=$stmt->fetch();
        /* while($stmt->fetch()){
          print_r($r1);
          print_r("\n");
          } */
        $stmt->close();
        //print_r($incomingUnverifiedOrders);
        if ($result->num_rows != 0) {
            //print_r($result);
            return json_encode([$a]);
        }
        //return $response;
    }

    function setverifystatus($module, $data, $type, $magento, $cc) {
        if ($module == "verifyneworder") {
            if ($type == "upd") {
                $query = "";
                $con = $this->db->getConnection();
                //$stmt=$con->prepare($query);
                //$stmt->bind_param("ss",$from_date,$to_data);
                $call_count = $data->call_count + 1;
                if ($call_count == 5) {
                    //$cust=Array("customer_name"=>$data->customer_name,"mobile_no"=>$data->customer_mobile,"order"=>$data->ref_incr_id);
                    //$this->sendSms($cust);
                    $query = "update ostk_order_verify set date_ordered=date_ordered,call_count=?,call_status=?,verified_datetime=now() where ref_incr_id=?";
                } else {
                    $query = "update ostk_order_verify set date_ordered=date_ordered,call_count=?,call_status=?,verified_datetime=null where ref_incr_id=?";
                }
                $stmt = $con->prepare($query);
                $stmt->bind_param("iss", $call_count, $call_status, $id);
                $call_status = $data->call_status . "{" . $call_count . ":" . $data->selected_status->status_id . "}";
                $id = $data->ref_incr_id;
                $stmt->execute();
            } else if ($type == "ver") {
                $query = "update ostk_order_verify set date_ordered=date_ordered,call_count=?,call_status=?,verified_status='Verified',verify_comment=?,verified_datetime=now() where ref_incr_id=?";
                $con = $this->db->getConnection();
                $stmt = $con->prepare($query);
                //$stmt->bind_param("ss",$from_date,$to_data);
                $stmt->bind_param("isss", $call_count, $call_status, $verify_comment, $id);
                foreach ($cc as $ord) {
                    $call_count = $ord->call_count + 1;
                    $call_status = $ord->call_status . "{" . $call_count . ":5}";
                    //$status="Verified";
                    $verify_comment = $ord->verify_comment;
                    $id = $ord->ref_incr_id;
                    $stmt->execute();
                }
                $magentoCall = new magentoToUrlCall();
                $res = $magentoCall->apiCallMagento('verifyupdateneworderurlpath', $magento);
                print_r($res);
            }
        } else if ($module == "verifynewuser") {
            if ($type == "upd") {
                $query = "";
                $con = $this->db->getConnection();
                $call_count = $data->call_count + 1;
                if ($call_count == 5) {
                    $cust = Array("customer_name" => $data->name, "mobile_no" => $data->mobile_no, "order" => $data->user_id);
                    $resp = $this->sendSms($cust, 1);
                    if ($resp) {
                        $q1 = "update ostk_user_verify set sms_status=? where user_id=?";
                        $con1 = $this->db->getConnection();
                        $st = $con1->prepare($q1);
                        $st->bind_param("ss", $sms_status, $uid);
                        $sms_status = $resp;
                        $uid = $data->user_id;
                        $st->execute();
                        $st->close();
                    }
                    $query = "update ostk_user_verify set registered_date=registered_date,call_count=?,call_status=?,verified_datetime=now() where user_id=?";
                } else {
                    $query = "update ostk_user_verify set registered_date=registered_date,call_count=?,call_status=?,verified_datetime=null where user_id=?";
                }
                $stmt = $con->prepare($query);
                //$stmt->bind_param("ss",$from_date,$to_data);
                $stmt->bind_param("iss", $call_count, $call_status, $id);
                $call_status = $data->call_status . "{" . $call_count . ":" . $data->selected_status->status_id . "}";
                $id = $data->user_id;
                $stmt->execute();
            } else if ($type == "ver") {
                $query = "update ostk_user_verify set registered_date=registered_date,call_count=?,call_status=?,status='Verified',verified_datetime=now() where user_id=?";
                $con = $this->db->getConnection();
                $stmt = $con->prepare($query);
                //$stmt->bind_param("ss",$from_date,$to_data);
                $stmt->bind_param("iss", $call_count, $call_status, $id);
                foreach ($cc as $ord) {
                    $call_count = $ord->call_count + 1;
                    $call_status = $ord->call_status . "{" . $call_count . ":5}";
                    //$status="Verified";
                    //$verify_comment=$ord->verify_comment;
                    $id = $ord->user_id;
                    $stmt->execute();
                }
                $magentoCall = new magentoToUrlCall();
                $res = $magentoCall->apiCallMagento('updateverifyurlpath', $magento);
                print_r($res);
            }
        } else if ($module == "viewallorder") {
            if ($type == "upd") {
                $query = "update ostk_all_orders set order_date=order_date,updated_at=updated_at,call_count=?,call_status=?,comments=? where ref_incr_id=?";
                $con = $this->db->getConnection();
                $stmt = $con->prepare($query);
                //$stmt->bind_param("ss",$from_date,$to_data);
                $stmt->bind_param("isss", $call_count, $call_status, $comments, $id);
                $comments = $data->comments;
                $call_count = $data->call_count + 1;
                $call_status = $data->call_status . "{" . $call_count . ":" . $data->selected_status->status_id . "}";
                $id = $data->ref_incr_id;
                $stmt->execute();
            }
        }
    }

    public function getVerifyStatus() {
        $query = "CALL `getVerifyStatus`()";
        $res = mysqli_query($this->db->getConnection(), $query);
        return $this->createArray($res);
    }

    public function insUpdUsers($data, $max) {
        $magentoCall = new magentoToUrlCall();
        $incomingUnverifiedUsers = $magentoCall->apiCallMagento('getnewuserlisturlpath', $data);
        //print_r($incomingUnverifiedUsers);
        $err_status = strpos($incomingUnverifiedUsers, "<title>There has been an error processing your request</title>");
        if ($err_status == false) {
            $n = strpos($incomingUnverifiedUsers, "[");
            $response = substr_replace($incomingUnverifiedUsers, "", 0, $n);
            //$response = substr_replace($incomingUnverifiedOrders, "" , -1,1);
            $array = json_decode($response)[0]->customer;
            //print_r($array);
            //print_r(json_encode(html_entity_decode($incomingUnverifiedOrders)),TRUE);
            //print_r($array);
            if ($array) {
                $query1 = "insert into ostk_user_verify(user_id,name,user_role,customer_type,registered_date,status,mobile_no,email,address,call_count,call_status,verified_datetime) values(?,?,?,?,?,?,?,?,?,?,?,?) on duplicate key update address=?,registered_date=?";
                $con = $this->db->getConnection();
                $stmt = $con->prepare($query1);
                $stmt->bind_param("issssssssissss", $user_id, $name, $user_role, $customer_type, $registered_date, $status, $mobile_no, $email, $address, $call_cocunt, $call_status, $verified_datetime, $addr, $datereg);
                foreach ($array as $user) {
                    $user_id = $user->user_id;
                    $name = $user->name;
                    $user_role = $user->user_role;
                    $customer_type = $user->customer_type;
                    $registered_date = $user->registered_date;
                    $status = $user->status;
                    $mobile_no = $user->mobile_no;
                    $email = $user->email;
                    $address = $user->address;
                    $call_cocunt = 0;
                    $call_status = "";
                    $addr = $user->address;
                    $verified_datetime = null;
                    $datereg = $user->registered_date;
                    $stmt->execute();
                }
                $stmt->close();
            }
        }
        $query = "select * from ostk_user_verify where registered_date>=? and registered_date<=? and ((status='Not Verified' and call_count<?) or (status='Not Verified' and call_count=5 and sms_status='Error'))";
        $con = $this->db->getConnection();
        $stmt = $con->prepare($query);
        //$stmt->bind_param("ss",$from_date,$to_data);
        $from_date = new DateTime(date("Y-m-d g:i:s", strtotime($data->from_date)));
        $to_date = new DateTime(date("Y-m-d g:i:s", strtotime($data->to_date)));
        //print_r($from_date);
        //print_r($to_date);
        $from_date->setTime(00, 00, 00);
        $to_date->setTime(23, 59, 59);
        $from_date = (string) $from_date->format('Y-m-d H:i:s');
        $to_date = (string) $to_date->format('Y-m-d H:i:s');
        /* $from_date=new DateTime(date("Y-m-d g:i:s",strtotime($data->from_date)));
          $to_date=new DateTime(date("Y-m-d g:i:s",strtotime($data->to_date)));
          $to_date->setTime(23,59,59);
          $from_date=$from_date->format('Y-m-d H:i:s');
          $to_date=$to_date->format('Y-m-d H:i:s'); */
        $stmt->bind_param("ssi", $from_date, $to_date, $max);
        //$from_data=date("Y-m-d g:i:s",strtotime($data->from_date));
        //print_r($from_data);
        //$to_date=(string)$data->to_date;
        $stmt->execute();
        $result = $stmt->get_result();
        while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
            $a[] = $row;
        }
        //$a=$result->fetch_array(MYSQLI_ASSOC);
        //print_r($a);
        //$stmt->bind_result($r1,$r2,$r3,$r4,$r5,$r6,$r7,$r8,$r9,$r10);
        //$stmt->bind_result($r1);
        //$incomingUnverifiedOrders=$stmt->fetch();
        /* while($stmt->fetch()){
          print_r($r1);
          print_r("\n");
          } */
        $stmt->close();
        //print_r($incomingUnverifiedOrders);
        if ($result->num_rows != 0) {
            //print_r($response);
            return json_encode([$a]);
        }
    }

    public function insUpdVerifiedOrders($data) {
        $magentoCall = new magentoToUrlCall();
        $incomingUnverifiedOrders = $magentoCall->apiCallMagento('verifyneworderurlpath', $data);
        $err_status = strpos($incomingUnverifiedOrders, "<title>There has been an error processing your request</title>");
        if ($err_status == false) {
            $n = strpos($incomingUnverifiedOrders, "[");
            $response = substr_replace($incomingUnverifiedOrders, "", 0, $n);
            //$response = substr_replace($incomingUnverifiedOrders, "" , -1,1);
            //print_r($response);
            $array = json_decode($response)[0];
            //print_r(json_encode(html_entity_decode($incomingUnverifiedOrders)),TRUE);
            //print_r($array);
            if (sizeof($array) > 0) {
                $query1 = "insert into ostk_order_verify(ref_incr_id,suborder_id,order_status,customer_name,customer_mobile,date_ordered,verified_status,verify_comment,call_count,call_status,verified_datetime) values(?,?,?,?,?,?,?,?,?,?,?) on duplicate key update suborder_id=?,date_ordered=?";
                $con = $this->db->getConnection();
                $stmt = $con->prepare($query1);
                $stmt->bind_param("ssssssssissss", $ref_inc_id, $suborder_id, $order_status, $customer_name, $customer_mobile, $date_ordered, $verified_status, $verify_comment, $call_cocunt, $call_status, $verified_datetime, $sub_orderid, $dateord);
                foreach ($array as $order) {
                    $ref_inc_id = $order->ref_incr_id;
                    $suborder_id = $order->suborder_id;
                    $order_status = $order->order_status;
                    $customer_name = $order->customer_name;
                    $customer_mobile = $order->customer_mobile;
                    $date_ordered = $order->date_ordered;
                    $verified_status = $order->verified_status;
                    $verify_comment = $order->verify_comment;
                    $call_cocunt = 1;
                    $call_status = "{1:5}";
                    $verified_datetime = $order->date_ordered;
                    $sub_orderid = $order->suborder_id;
                    $dateord = $order->date_ordered;
                    $stat = $order->verified_status;
                    $stmt->execute();
                }
                $stmt->close();
            }
        }
        $query = "select * from ostk_order_verify where (verified_datetime>=? and verified_datetime<=? and verified_status='Verified') or (call_count=5 and verified_status='Not Verified' and verified_datetime>=? and verified_datetime<=?)";
        $con = $this->db->getConnection();
        $stmt = $con->prepare($query);
        //$stmt->bind_param("ss",$from_date,$to_data);
        $from_date = new DateTime(date("Y-m-d g:i:s", strtotime($data->from_date)));
        $to_date = new DateTime(date("Y-m-d g:i:s", strtotime($data->to_date)));
        //print_r($from_date);
        //print_r($to_date);
        $from_date->setTime(00, 00, 00);
        $to_date->setTime(23, 59, 59);
        $from_date = (string) $from_date->format('Y-m-d H:i:s');
        $to_date = (string) $to_date->format('Y-m-d H:i:s');
        /* $from_date=new DateTime(date("Y-m-d g:i:s",strtotime($data->from_date)));
          $to_date=new DateTime(date("Y-m-d g:i:s",strtotime($data->to_date)));
          $to_date->setTime(23,59,59);
          $from_date=$from_date->format('Y-m-d H:i:s');
          $to_date=$to_date->format('Y-m-d H:i:s'); */
        $stmt->bind_param("ssss", $from_date, $to_date, $from_date, $to_date);
        //$from_data=date("Y-m-d g:i:s",strtotime($data->from_date));
        //print_r($from_data);
        //$to_date=(string)$data->to_date;
        $stmt->execute();
        $result = $stmt->get_result();
        while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
            $a[] = $row;
        }
        //$a=$result->fetch_array(MYSQLI_ASSOC);
        //print_r($a);
        //$stmt->bind_result($r1,$r2,$r3,$r4,$r5,$r6,$r7,$r8,$r9,$r10);
        //$stmt->bind_result($r1);
        //$incomingUnverifiedOrders=$stmt->fetch();
        /* while($stmt->fetch()){
          print_r($r1);
          print_r("\n");
          } */
        $stmt->close();
        //print_r($incomingUnverifiedOrders);
        if ($result->num_rows != 0) {
            return json_encode([$a]);
        }
    }

    public function insUpdVerifiedUsers($data) {
        $magentoCall = new magentoToUrlCall();
        $incomingUnverifiedUsers = $magentoCall->apiCallMagento('getnewuserlisturlpath', $data);
        //print_r($data);
        $err_status = strpos($incomingUnverifiedUsers, "<title>There has been an error processing your request</title>");
        if ($err_status == false) {
            $n = strpos($incomingUnverifiedUsers, "[");
            $response = substr_replace($incomingUnverifiedUsers, "", 0, $n);
            //$response = substr_replace($incomingUnverifiedOrders, "" , -1,1);
            //print_r($response);
            $array = json_decode($response)[0]->customer;
            //print_r($array);
            //print_r(json_encode(html_entity_decode($incomingUnverifiedOrders)),TRUE);
            //print_r($response);
            //print_r(sizeof($array));
            if (sizeof($array) > 0) {
                $query1 = "insert into ostk_user_verify(user_id,name,user_role,customer_type,registered_date,status,mobile_no,email,address,call_count,call_status,verified_datetime) values(?,?,?,?,?,?,?,?,?,?,?,?) on duplicate key update registered_date=?";
                $con = $this->db->getConnection();
                $stmt = $con->prepare($query1);
                $stmt->bind_param("issssssssisss", $user_id, $name, $user_role, $customer_type, $registered_date, $status, $mobile_no, $email, $address, $call_cocunt, $call_status, $verified_datetime, $datereg);
                foreach ($array as $user) {
                    //print_r($user);
                    $user_id = $user->user_id;
                    $name = $user->name;
                    $user_role = $user->user_role;
                    $customer_type = $user->customer_type;
                    $registered_date = $user->registered_date;
                    $status = $user->status;
                    $mobile_no = $user->mobile_no;
                    $email = $user->email;
                    $address = $user->address;
                    $call_cocunt = 1;
                    $call_status = "{1:5}";
                    $verified_datetime = $user->registered_date;
                    $datereg = $user->registered_date;
                    $stmt->execute();
                }
                $stmt->close();
            }
        }
        $query = "select * from ostk_user_verify where (verified_datetime>=? and verified_datetime<=? and status='Verified') or (call_count=5 and status='Not Verified' and verified_datetime>=? and verified_datetime<=?)";
        $con = $this->db->getConnection();
        $stmt = $con->prepare($query);
        //echo("1");
        //$stmt->bind_param("ss",$from_date,$to_data);
        $from_date = new DateTime(date("Y-m-d g:i:s", strtotime($data->from_date)));
        $to_date = new DateTime(date("Y-m-d g:i:s", strtotime($data->to_date)));
        //print_r($from_date);
        //print_r($to_date);
        $from_date->setTime(00, 00, 00);
        $to_date->setTime(23, 59, 59);
        $from_date = (string) $from_date->format('Y-m-d H:i:s');
        $to_date = (string) $to_date->format('Y-m-d H:i:s');
        /* print_r($from_date);
          print_r($to_date); */
        /* $from_date=new DateTime(date("Y-m-d g:i:s",strtotime($data->from_date)));
          $to_date=new DateTime(date("Y-m-d g:i:s",strtotime($data->to_date)));
          $to_date->setTime(23,59,59);
          $from_date=$from_date->format('Y-m-d H:i:s');
          $to_date=$to_date->format('Y-m-d H:i:s'); */
        $stmt->bind_param("ssss", $from_date, $to_date, $from_date, $to_date);
        //$from_data=date("Y-m-d g:i:s",strtotime($data->from_date));
        //print_r($from_data);
        //$to_date=(string)$data->to_date;
        $stmt->execute();
        $result = $stmt->get_result();
        while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
            $a[] = $row;
        }
        //$a=$result->fetch_array(MYSQLI_ASSOC);
        //print_r($a);
        //$stmt->bind_result($r1,$r2,$r3,$r4,$r5,$r6,$r7,$r8,$r9,$r10);
        //$stmt->bind_result($r1);
        //$incomingUnverifiedOrders=$stmt->fetch();
        /* while($stmt->fetch()){
          print_r($r1);
          print_r("\n");
          } */
        $stmt->close();
        //print_r($incomingUnverifiedOrders);
        if ($result->num_rows != 0) {
            return json_encode([$a]);
        }
    }

}

?>
