<?php
	// $data = json_decode(file_get_contents("php://input"));		
	// print_r($data);
	if(!empty($_FILES)){
		//print_r($_FILES['file']);
		//$path = 'https://107.167.178.228/callcenterqa/uploadedData/'.$_FILES['file']['name'];
		$path = '../uploadedData/'.$_FILES['file']['name'];
		if(move_uploaded_file($_FILES['file']['tmp_name'],$path)){
			
			echo 'files uploaded successfully';
		}
		else echo 'error in uploading files';
	}
	else {echo 'some error while uploading files';}
?>