<?php

$connect =  mysqli_connect("localhost","test2","test2","leykart") or die ("cannot connect to database");
 

// echo json_encode($connect);

$output=array();
$query="SELECT * FROM ostk_issue_category";
$result=mysqli_query($connect,$query);
//echo json_encode($result);

if(mysqli_num_rows($result) > 0){
	while($row= mysqli_fetch_array($result))
	{
		$output[]=$row;
	}
	echo json_encode($output);
 }


?>