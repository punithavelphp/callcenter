<?php
//insert.php
$connect = mysqli_connect("localhost","test2","test2","leykart") or die("unable to connect DB");
$data = json_decode(file_get_contents("php://input"));
//$data=['firstname':"cool",'lastname':"sdfsdf"];

 // $first="hi";
 // $last="hello";
// $debug="0";



 

 if(count($data) > 0){
	 
	// echo ($data->username);
	
	$user = mysqli_real_escape_string($connect,$data->username);
	//$issue = mysqli_real_escape_string($connect,$data->credentials.password);
	// $query = "INSERT INTO  emp_detail VALUES ('$first_name','$last_name')";
	
	
	
	// if(mysqli_query($connect,$query)){
		// echo "data inserted";
		// die();
	// }
	// else{
		// echo "error";	
		// die();
	// }
	
	// if($debug=='1') {
       // print_r($data);
      // die();
    // }
	
	
	$output=array();
	//echo ($user);
	//echo($issue);
	$query="SELECT * FROM ostk_staff where username='".$user."'";
	$result=mysqli_query($connect,$query);
	//echo json_encode($result);

	if(!$result ||mysqli_num_rows($result) > 0){
		while($row= mysqli_fetch_array($result))
		{
			$output[]=$row;
		}
	echo json_encode($output);
	}
		
  }
  
  else{
		echo "error";	
		die();
	}


// $connect =  mysqli_connect("localhost","test2","test2","leykart") or die ("canot connect to database");
 

// // echo json_encode($connect);

// $output=array();
// $query="SELECT * FROM ostk_ticket";
// $result=mysqli_query($connect,$query);
// echo json_encode($result);

// if(mysqli_num_rows($result) > 0){
	// while($row= mysqli_fetch_array($result))
	// {
		// $output[]=$row;
	// }
	// echo json_encode($output);
// }


?>